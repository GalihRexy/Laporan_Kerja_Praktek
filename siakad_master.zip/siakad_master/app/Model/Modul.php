<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Modul extends Model
{
    protected $table = 'modul';
    protected $primaryKey = 'id_modul';
    public $incrementing = false;
    protected $fillable = [
    	'id_modul', 'nama', 'icon', 'logo', 'link', 'keterangan', 'aktif', 
    ];

    public function modul_group()
    {
        return $this->belongsTo('App\Model\ModulGroup', 'id_group_mdl', 'id_group_mdl');
    } 
}
