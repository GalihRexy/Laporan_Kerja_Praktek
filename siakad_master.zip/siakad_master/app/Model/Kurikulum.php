<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Kurikulum extends Model
{
    protected $table = 'kurikulum';
    protected $primaryKey = 'kode_kurikulum';
    public $incrementing = false;
    protected $fillable = [
        'kode_kurikulum', 'kode_prodi', 'tahun', 'nama', 'aktif',
    ];

     public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function matakuliah()
    {
    	return $this->hasMany('App\Model\Matakuliah', 'kode_kurikulum', 'kode_kurikulum');
    }
}
