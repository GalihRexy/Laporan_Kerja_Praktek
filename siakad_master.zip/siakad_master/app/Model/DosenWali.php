<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DosenWali extends Model
{
    protected $table = 'dosen_wali';
    protected $primaryKey = 'id_dosen_wali';
    public $incrementing = false;
    protected $fillable = [
    	'id_dosen_wali', 'nidn', 'nim', 'id_sk_dosen_wali',
    ];

    public function dosen()
    {
        return $this->belongsTo('App\Model\Dosen', 'nidn', 'nidn');
    }

    public function mahasiswa()
    {
        return $this->belongsTo('App\Model\Mahasiswa', 'nim', 'nim');
    }

    public function krs()
    {
        return $this->belongsTo('App\Model\Krs', 'nim', 'nim');
    }

    public function sk_dosen_wali()
    {
        return $this->belongsTo('App\Model\SkDosenWali', 'id_sk_dosen_wali', 'id_sk_dosen_wali');
    }
}
