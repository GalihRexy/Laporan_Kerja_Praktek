<?php

namespace App\Model;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Dosen extends Authenticatable
{
    use Notifiable;
    
    protected $table = 'dosen';
    protected $primaryKey = 'nidn';
    protected $guard = 'dosen';
    public $incrementing = false;
    protected $fillable = [
    	'nidn', 'username', 'password', 'nip_pns', 'nik', 'nama', 'tempat_lahir', 'tgl_lahir', 'jenis_kelamin', 'alamat', 'desa', 'kecamatan', 'kota', 'kodepos', 'provinsi', 'wni', 'handphone', 'email', 'kode_prodi', 'gelar', 'jenjang', 'keilmuan', 'lulusan_pt', 'institusi_induk', 'id_jabatan', 'id_klasifikasi_dosen', 'no_rek', 'foto', 'aktif',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function jabatan()
    {
    	return $this->belongsTo('App\Model\Jabatan', 'id_jabatan', 'id_jabatan');
    }

    public function range_nilai()
    {
        return $this->hasMany('App\Model\RangeNilai', 'nidn', 'nidn');
    }

    public function klasifikasi_dosen()
    {
        return $this->belongsTo('App\Model\KlasifikasiDosen', 'id_klasifikasi_dosen', 'id_klasifikasi_dosen');
    }

    public function dosen_wali()
    {
        return $this->hasMany('App\Model\DosenWali', 'id_dosen_wali', 'id_dosen_wali');
    }

    public function mahasiswa()
    {
        return $this->hasMany('App\Model\Mahasiswa', 'nim', 'nim');
    }
}
