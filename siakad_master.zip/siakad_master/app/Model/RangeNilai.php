<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class RangeNilai extends Model
{
    protected $table = 'range_nilai';
    protected $primaryKey = 'id_range';
    public $incrementing = false;
    protected $fillable = [
        'id_range', 'kode_mk', 'nidn', 'range_a', 'range_ab', 'range_b', 'range_bc', 'range_c', 'range_d', 'aktif',
    ];

    public function matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk');
    } 

    public function dosen()
    {
        return $this->belongsTo('App\Model\Dosen', 'nidn', 'nidn');
    } 

}
