<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Skpi extends Model
{
    protected $table = 'skpi';
    protected $primaryKey = 'kode_skpi';
    public $incrementing = false;
    protected $fillable = [
        'kode_skpi', 'deskripsi_skpi',
    ];

    public function study_outcomes()
    {
        return $this->hasMany('App\Model\StudyOutcomes', 'kode_so', 'kode_so');
    }
}
