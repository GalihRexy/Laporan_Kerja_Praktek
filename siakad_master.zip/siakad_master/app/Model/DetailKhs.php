<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DetailKhs extends Model
{
    protected $table = 'detail_khs';
    protected $primaryKey = 'id_detail_khs';
    public $incrementing = false;
    protected $fillable = [
    	'id_detail_khs', 'kode_khs', 'kode_mk', 'nilai', 'sks', 'nilai_mutu', 'status', 'ambil_ke', 'tahun', 'semester', 'pre_lulus', 'pre_tahun','keterangan', 
    ];

    public function khs() {
    	return $this->belongsTo('App\Model\Khs','id_khs', 'id_khs');
    }

    public function mata_kuliah() {
    	return $this->belongsTo('App\Model\Matakuliah','kode_mk', 'kode_mk');
    }

    public function matakuliah() {
        return $this->belongsTo('App\Model\Matakuliah','kode_mk', 'kode_mk');
    }
}
