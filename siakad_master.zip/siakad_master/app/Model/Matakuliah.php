<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Matakuliah extends Model
{
    protected $table = 'matakuliah';
    protected $primaryKey = 'kode_mk';
    public $incrementing = false;
    protected $fillable = [
        'kode_mk', 'nama', 'sks', 'kode_prodi', 'kode_jenis_mk', 'kode_kurikulum', 'rumpun', 'tgl_revisi', 'pengembangan_rps', 'nidn_pengembang_rps', 'nidn_ketua_kk', 'deskripsi', 'pustaka_utama', 'pustaka_pendukung', 'media_pembelajaran_sw', 'media_pembelajaran_hw', 'biaya_per_sks', 'aktif',
    ];

    public function prasyarat_matakuliah()
    {
        return $this->hasTo('App\Model\PrasyaratMataKuliah', 'kode_mk', 'kode_mk_prasyarat');
    }

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function jenis_matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_jenis_mk', 'kode_jenis_mk');
    }

    public function kurikulum()
    {
        return $this->belongsTo('App\Model\Kurikulum', 'kode_kurikulum', 'kode_kurikulum');
    }

    public function study_outcomes()
    {
        return $this->hasMany('App\Model\StudyOutcomes', 'kode_mk', 'kode_mk');
    }

    public function learning_outcomes()
    {
        return $this->hasMany('App\Model\LearningOutcomes', 'kode_mk', 'kode_mk');
    }

    public function range_nilai()
    {
        return $this->hasMany('App\Model\RangeNilai', 'kode_mk', 'kode_mk');
    }

    public function detail_krs()
    {
        return $this->hasMany('App\Model\DetailKrs', 'id_detail_krs', 'id_detail_krs');
    }


}
