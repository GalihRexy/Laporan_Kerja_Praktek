<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Nilai extends Model
{
    protected $table = 'nilai';
    protected $primaryKey = 'id_nilai';
    public $incrementing = false;
    protected $fillable = [
        'id_nilai', 'id_assessment', 'nim', 'nilai', 'tgl_assessment',
    ];

    public function assessment()
    {
    	return $this->belongsTo('App\Model\Assessment', 'id_assessment', 'id_assessment');
    }

    public function mahasiswa()
    {
    	return $this->belongsTo('App\Model\Mahasiswa', 'nim', 'nim');
    }
}
