<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class MatakuliahKurikulum extends Model
{
    protected $table = 'matakuliah_kurikulum';
    protected $primaryKey = 'id_matakuliah_kurikulum';
    public $incrementing = false;
    protected $fillable = [
        'kode_kurikulum', 'kode_mk', 'semester', 'ganjil', 
    ];

     public function kurikulum()
    {
        return $this->belongsTo('App\Model\Kurikulum', 'kode_kurikulum', 'kode_kurikulum');
    }

    public function matakuliah()
    {
    	return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk');
    }
}
