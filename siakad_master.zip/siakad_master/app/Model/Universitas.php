<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Universitas extends Model
{
    protected $table = 'universitas';
    public $incrementing = false;
    protected $fillable = [
    	'id_univ', 'nama', 'alamat', 'kota', 'provinsi', 'kodepos', 'telepon', 'fax', 'email', 'website', 'akta', 'tgl_akta', 'pengesahan', 'tgl_pengesahan', 'logo', 
    ];
}
