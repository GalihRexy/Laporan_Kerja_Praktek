<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ModulGroup extends Model
{
    protected $table = 'modul_group';
    protected $primaryKey = 'id_group_mdl';
    public $incrementing = false;
    protected $fillable = [
    	'id_group_mdl', 'nama', 'icon', 'logo', 'link', 'keterangan', 'aktif', 
    ];

    public function model()
    {
    	return $this->hasMany('App\Model\Modul', 'id_group_mdl', 'id_group_mdl');
    }
}
