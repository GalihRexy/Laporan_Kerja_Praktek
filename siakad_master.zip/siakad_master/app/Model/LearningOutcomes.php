<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class LearningOutcomes extends Model
{
    protected $table = 'learning_outcomes';
    protected $primaryKey = 'id_lo';
    public $incrementing = false;
    protected $fillable = [
        'id_lo', 'kode_so', 'kode_mk', 'deskripsi_lo', 'materi', 'metode_pembelajaran', 'total_bobot', 
    ];

    public function assessment()
    {
        return $this->hasMany('App\Model\Assessment', 'id_lo', 'id_lo');
    }

    public function study_outcomes()
    {
        return $this->belongsTo('App\Model\StudyOutcomes', 'id_so', 'id_so');
    }

    public function matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk');
    }
}
