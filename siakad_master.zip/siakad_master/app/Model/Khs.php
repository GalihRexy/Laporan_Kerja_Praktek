<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Khs extends Model
{
    protected $table = 'khs';
    protected $primaryKey = 'kode_khs';
    public $incrementing = false;
    protected $fillable = [
        'kode_khs', 'nim', 'tahun_semester','total_sks_sdh_diambil', 'total_sks_blm_diambil', 'tmt', 'tst',
    ];

    public function detail_khs()
    {
    	return $this->hasMany('App\Model\DetailKhs', 'id_detail_khs', 'id_detail_khs');
    }
}

