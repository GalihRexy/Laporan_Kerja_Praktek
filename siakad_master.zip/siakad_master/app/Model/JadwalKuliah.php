<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JadwalKuliah extends Model
{
    protected $table = 'jadwal_kuliah';
    protected $primaryKey = 'kode_jadwal_kuliah';
    public $incrementing = false;
    protected $fillable = [
        'kode_jadwal_kuliah', 'kode_prodi', 'kode_thn_akademik', 'kelas', 'nidn', 'semester', 'kode_mk', 'kode_ruang', 'aktif',
    ];

    public function detail_krs()
    {
        return $this->hasMany('App\Model\DetailKrs', 'kode_jadwal_kuliah', 'kode_jadwal_kuliah');
    }

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function tahun_akademik()
    {
        return $this->belongsTo('App\Model\TahunAkademik', 'kode_tahun_akademik', 'kode_tahun_akademik');
    }

    public function matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk');
    }

    public function ruang()
    {
        return $this->belongsTo('App\Model\Ruang', 'kode_ruang', 'kode_ruang');
    }
}
