<?php

namespace App\Model;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Super extends Authenticatable
{
    use Notifiable;

    protected $table = 'super_table';
    protected $primaryKey = 'username';
    protected $guard = 'super_user';
    protected $fillable = [
        'username', 'password', 'nama', 'handphone', 'email',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];
}
