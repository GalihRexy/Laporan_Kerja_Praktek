<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Prodi extends Model
{
    protected $table = 'prodi';
    protected $primaryKey = 'kode_prodi';
    public $incrementing = false;
    protected $fillable = [
        'kode_prodi', 'kode_fakultas', 'nama', 'jenjang', 'gelar', 'akreditasi', 'sk_dikti', 'tgl_sk_dikti', 'sk_ban', 'tgl_sk_ban', 'ketua_prodi', 'keterangan', 'aktif',
    ];

    public function fakultas()
    {
        return $this->belongsTo('App\Model\Fakultas', 'kode_fakultas', 'kode_fakultas');
    }

    public function ruang()
    {
        return $this->belongsTo('App\Model\Ruang', 'kode_ruang', 'kode_ruang');
    }

    public function mahasiswa()
    {
        return $this->hasMany('App\Model\Mahasiswa', 'kode_prodi', 'kode_prodi');
    }

    public function karyawan()
    {
        return $this->hasMany('App\Model\Karyawan', 'kode_prodi', 'kode_prodi');
    }

    public function dosen()
    {
        return $this->hasMany('App\Model\Dosen', 'kode_prodi', 'kode_prodi');
    }

    public function kurikulum()
    {
        return $this->hasMany('App\Model\Kurikulum', 'kode_prodi', 'kode_prodi');
    }

    public function jadwal_kuliah()
    {
        return $this->hasMany('App\Model\JadwalKuliah', 'kode_prodi', 'kode_prodi');
    }

    public function matakuliah()
    {
        return $this->hasMany('App\Model\Matakuliah', 'kode_prodi', 'kode_prodi');
    }

    public function jenis_matakuliah()
    {
        return $this->hasMany('App\Model\JenisMatakuliah', 'kode_prodi', 'kode_prodi');
    }

    public function tahun_akademik()
    {
        return $this->hasMany('App\Model\TahunAkademik', 'kode_prodi', 'kode_prodi');
    }

    public function study_outcomes()
    {
        return $this->hasMany('App\Model\StudyOutcomes', 'kode_so', 'kode_so');
    }

    public function sk_dosen_wali()
    {
        return $this->hasMany('App\Model\SkDosenWali', 'kode_prodi', 'kode_prodi');
    }
}
