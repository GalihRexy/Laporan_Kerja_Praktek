<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PrasyaratMatakuliah extends Model
{
    protected $table = 'prasyarat_matakuliah';
    protected $primaryKey = 'kode_prasyarat_mk';
    public $incrementing = false;
    protected $fillable = [
        'kode_prasyarat_mk', 'kode_mk', 'kode_mk_prasyarat',
    ];

    public function matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk_prasyarat');
    }
}
