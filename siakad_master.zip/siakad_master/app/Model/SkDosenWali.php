<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class SkDosenWali extends Model
{
    protected $table = 'sk_dosen_wali';
    protected $primaryKey = 'id_sk_dosen_wali';
    public $incrementing = false;
    protected $fillable = [
    	'id_sk_dosen_wali', 'nomor_sk_dosen_wali', 'tanggal_sk', 'kode_prodi', 
    ];

    public function dosen_wali()
    {
        return $this->hasMany('App\Model\DosenWali', 'id_sk_dosen_wali', 'id_sk_dosen_wali');
    }

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }
}
