<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class KlasifikasiDosen extends Model
{
    protected $table = 'klasifikasi_dosen';
    protected $primaryKey = 'id_klasifikasi_dosen';
    public $incrementing = false;
    protected $fillable = [
        'id_klasifikasi_dosen', 'nama',
    ];

    public function dosen()
    {
    	return $this->hasMany('App\Model\Dosen', 'id_klasifikasi_dosen', 'id_klasifikasi_dosen');
    }
}

