<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Fakultas extends Model
{
    protected $table = 'fakultas';
    protected $primaryKey = 'kode_fakultas';
    public $incrementing = false;
    protected $fillable = [
        'kode_fakultas', 'nama', 'alamat', 'kota', 'provinsi', 'kodepos', 'telepon', 'fax', 'email', 'website', 'logo', 'aktif',
    ];

    public function prodi()
    {
    	return $this->hasMany('App\Model\Prodi', 'kode_fakultas', 'kode_fakultas');
    }
}
