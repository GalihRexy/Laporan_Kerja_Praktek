<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Krs extends Model
{
    protected $table = 'krs';
    protected $primaryKey = 'id_krs';
    public $incrementing = false;
    protected $fillable = [
    	'id_krs', 'kode_thn_akademik', 'nim', 'tgl_perwalian', 'total_sks', 'total_biaya', 'status'
    ];

    public function tahun_akademik()
    {
        return $this->belongsTo('App\Model\TahunAkademik', 'kode_thn_akademik', 'kode_thn_akademik');
    }

    public function detail_krs()
    {
        return $this->hasMany('App\Model\DetailKrs', 'id_krs', 'id_krs');
    }

    public function mahasiswa()
    {
        return $this->belongsTo('App\Model\Mahasiswa', 'nim', 'nim');
    }

    public function dosen_wali()
    {
        return $this->hasMany('App\Model\DosenWali', 'id_dosen_wali', 'id_dosen_wali');
    }

}
