<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Ruang extends Model
{
    protected $table = 'ruang';
    protected $primaryKey = 'kode_ruang';
    public $incrementing = false;
    protected $fillable = [
    	'kode_ruang', 'kode_kampus', 'kode_prodi', 'nama', 'lantai', 'kapasitas', 'kapasitas_ujian', 'kolom_meja', 'keterangan', 'ruang_kuliah', 'ruang_usm', 'aktif', 
    ];

    public function kampus()
    {
    	return $this->belongsTo('App\Model\Kampus', 'kode_kampus', 'kode_kampus');
    } 

    public function prodi()
    {
    	return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    } 

    public function jadwal_kuliah()
    {
        return $this->hasMany('App\Model\JadwalKuliah', 'kode_ruang', 'kode_ruang');
    }

}
