<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class TahunAkademik extends Model
{
    protected $table = 'tahun_akademik';
    protected $primaryKey = 'kode_thn_akademik';
    public $incrementing = false;
    protected $fillable = [
        'kode_thn_akademik', 'nama', 'tgl_awal', 'tgl_akhir', 'kode_prodi', 'aktif',
    ];

    public function jadwal_kuliah()
    {
        return $this->hasMany('App\Model\JadwalKuliah', 'kode_thn_akademik', 'kode_thn_akademik');
    }

    public function krs()
    {
        return $this->hasMany('App\Model\Krs', 'kode_thn_akademik', 'kode_thn_akademik');
    }

     public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }
}
