<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DetailKrs extends Model
{
    protected $table = 'detail_krs';
    protected $primaryKey = 'id_detail_krs';
    public $incrementing = false;
    protected $fillable = [
    	'id_detail_krs', 'id_krs', 'kode_jadwal_kuliah', 'nilai', 'kode_mk', 'status'
    ];

    public function krs()
    {
        return $this->belongsTo('App\Model\Krs', 'id_krs', 'id_krs');
    }

    public function jadwal_kuliah()
    {
    	return $this->belongsTo('App\Model\JadwalKuliah', 'kode_jadwal_kuliah', 'kode_jadwal_kuliah');
    }

     public function mata_kuliah()
    {
    	return $this->belongsTo('App\Model\MataKuliah', 'kode_mk', 'kode_mk');
    }
}
