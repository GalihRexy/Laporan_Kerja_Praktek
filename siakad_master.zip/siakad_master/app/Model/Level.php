<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Level extends Model
{
    protected $table = 'level';
    protected $primaryKey = 'id_level';
    public $incrementing = false;
    protected $fillable = [
    	'id_level', 'nama', 'tingkat', 'hak_akses', 'keterangan', 'aktif', 
    ];

    public function karyawan()
    {
        return $this->hasMany('App\Model\Karyawan', 'id_level', 'id_level');
    }
}
