<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Registrasi extends Model
{
    
    protected $connection = 'mysql_registrasi';
    protected $table = 'mahasiswa';
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'nim', 'password', 'nik', 'nama', 'tempat_lahir', 'tgl_lahir', 'jenis_kelamin', 'alamat', 'desa', 'kecamatan', 'kota', 'kodepos', 'provinsi', 'wni', 'handphone', 'email', 'kode_prodi', 'foto', 'aktif', 'aktivasi_token', 'tahap',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}
