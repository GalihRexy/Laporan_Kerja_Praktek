<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Assessment extends Model
{
    protected $table = 'assessment';
    protected $primaryKey = 'id_assessment';
    // public $incrementing = false;
    protected $fillable = [
    	'id_assessment', 'id_lo', 'metode', 'bobot', 'kriteria_nilai', 'waktu_pelaksanaan', 'target_pencapaian', 'base_line', 
    ];

    public function nilai()
    {
        return $this->hasMany('App\Model\Nilai', 'id_assessment', 'id_assessment');
    }

    public function learning_outcomes()
    {
        return $this->belongsTo('App\Model\LearningOutcomes', 'id_lo', 'id_lo');
    }
}
