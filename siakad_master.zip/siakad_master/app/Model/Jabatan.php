<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Jabatan extends Model
{
    protected $table = 'jabatan';
    protected $primaryKey = 'id_jabatan';
    public $incrementing = false;
    protected $fillable = [
        'id_jabatan', 'nama',
    ];

    public function dosen()
    {
    	return $this->hasMany('App\Model\Dosen', 'id_jabatan', 'id_jabatan');
    }

    public function karyawan()
    {
        return $this->hasMany('App\Model\Karyawan', 'id_jabatan', 'id_jabatan');
    }
}
