<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class JenisMatakuliah extends Model
{
    protected $table = 'jenis_matakuliah';
    protected $primaryKey = 'kode_jenis_mk';
    public $incrementing = false;
    protected $fillable = [
    	'kode_jenis_mk', 'nama', 'wajib', 'kode_prodi', 
    ];

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    } 

    public function matakuliah()
    {
        return $this->hasTo('App\Model\Matakuliah', 'kode_jenis_mk', 'kode_jenis_mk');
    }

}
