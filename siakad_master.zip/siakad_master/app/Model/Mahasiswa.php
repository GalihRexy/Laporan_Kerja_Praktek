<?php

namespace App\Model;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Mahasiswa extends Authenticatable
{
    use Notifiable;

    protected $table = 'mahasiswa';
    protected $primaryKey = 'nim';
    public $incrementing = false;
    protected $fillable = [
        'nim', 'password', 'nik', 'nama', 'tempat_lahir', 'tgl_lahir', 'jenis_kelamin', 'alamat', 'desa', 'kecamatan', 'kota', 'kodepos', 'provinsi', 'wni', 'handphone', 'email', 'kode_prodi', 'foto', 'aktif',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function krs()
    {
        return $this->hasMany('App\Model\Krs', 'nim', 'nim');
    }

    public function nilai()
    {
        return $this->hasMany('App\Model\Nilai', 'nim', 'nim');
    }

    public function getFoto()
    {
        if (!$this->foto) {
            return asset('img/default.jpg');
        }
        return asset('img/' . $this->foto);
    }
}
