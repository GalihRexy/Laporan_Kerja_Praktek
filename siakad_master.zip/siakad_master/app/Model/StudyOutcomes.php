<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class StudyOutcomes extends Model
{
    protected $table = 'study_outcomes';
    protected $primaryKey = 'kode_so';
    public $incrementing = false;
    protected $fillable = [
    	'kode_so', 'kode_prodi', 'kode_skpi', 'deskripsi_so', 
    ];

    public function learning_outcomes()
    {
        return $this->hasMany('App\Model\LearningOutcomes', 'id_so', 'id_so');
    }

    public function matakuliah()
    {
        return $this->belongsTo('App\Model\Matakuliah', 'kode_mk', 'kode_mk');
    }

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }

    public function skpi()
    {
        return $this->belongsTo('App\Model\Skpi', 'kode_skpi', 'kode_skpi');
    }
}
