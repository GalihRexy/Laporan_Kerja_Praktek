<?php

namespace App\Model;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Karyawan extends Authenticatable
{
    use Notifiable;

    protected $table = 'karyawan';
    protected $primaryKey = 'nik';
    public $incrementing = false;
    protected $fillable = [
        'nik' ,'username', 'password', 'nama', 'id_jabatan', 'alamat', 'desa', 'kecamatan', 'kota', 'kodepos', 'provinsi', 'wni', 'handphone', 'email', 'id_level', 'kode_prodi', 'foto', 'aktif',
    ];
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function jabatan()
    {
    	return $this->belongsTo('App\Model\Jabatan', 'id_jabatan', 'id_jabatan');
    }

    public function level()
    {
        return $this->belongsTo('App\Model\Level', 'id_level', 'id_level');
    }

    public function prodi()
    {
        return $this->belongsTo('App\Model\Prodi', 'kode_prodi', 'kode_prodi');
    }
}
