<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Kampus extends Model
{
    protected $table = 'kampus';
    protected $primaryKey = 'kode_kampus';
    public $incrementing = false;
    protected $fillable = [
        'kode_kampus', 'nama', 'alamat', 'kota', 'kodepos', 'provinsi',
    ];

    public function ruang()
    {
    	return $this->hasMany('App\Model\Ruang', 'kode_kampus', 'kode_kampus');
    }
}
