<?php

namespace App\Http\Middleware;

use Closure;
use App\Model\Level as Level;
use App\Model\Modul as Modul;
use Illuminate\Support\Facades\Auth;

class UserRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        /**
        * Check User Role
        *
        * Get URL
        * $url = $request->url();
        * $url = $request->path();
        */

        if(!$request->user()){
            return redirect('/');
        } elseif ($request->user()->super_user == '1') {
            return $next($request);
        } elseif ($request->user()->id_level != null) {
            $level = Level::find($request->user()->id_level);
            $modul = Modul::all();
            $url = $request->url();
            $akses = false;

            foreach (explode('-', $level->hak_akses) as $hak_akses) {
                foreach ($modul as $dataModul) {
                    if ($dataModul->id_modul == $hak_akses) {
                        if (starts_with($url, url($dataModul->link))) {
                            $akses = true;
                        }
                    }
                }
            }

            if ($akses) {
                return $next($request);
            } else {
                return redirect('admin/401');
            }
        } else {
            // code redirect for auth dosen or mahasiswa
            return redirect('admin/401');
        }
    }
}
