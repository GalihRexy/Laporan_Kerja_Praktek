<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Kampus as Kampus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class KampusController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $kampus = Kampus::paginate('20');

        return view('karyawan.kampus.view', compact('kampus'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $kampus = Kampus::orWhere('kode_kampus', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $kampus->appends(['cari' => $cari])->links();
        
        return view('karyawan.kampus.view', compact('kampus'));
    }

    public function create()
    {
          return view('karyawan.kampus.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_kampus' => 'required|string|unique:kampus',
            'nama' => 'required|string',
            'alamat' => 'string',
            'kota' => 'string',
            'kodepos' => 'numeric',
            'provinsi' => 'string',
        ]);

        $data = new Kampus;
        $data->kode_kampus = $request->input('kode_kampus');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->save();

        return redirect('admin/kampus')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Kampus::find($id);

        return view('karyawan.kampus.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_kampus' => 'required|string|unique:kampus,kode_kampus,'.$id.',kode_kampus',
            'nama' => 'required|string',
            'alamat' => 'string',
            'kota' => 'string',
            'kodepos' => 'numeric',
            'provinsi' => 'string',
        ]);

        $data = Kampus::find($id);
        $data->kode_kampus = $request->input('kode_kampus');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->save();

        return redirect('admin/kampus')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Kampus::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
