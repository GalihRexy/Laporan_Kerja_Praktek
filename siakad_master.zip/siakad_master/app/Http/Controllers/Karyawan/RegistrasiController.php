<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Registrasi;
use App\Model\Fakultas;
use App\Model\Prodi;
use App\Model\Mahasiswa;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class RegistrasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null) {
            $mahasiswa = Registrasi::where('kode_prodi', '=', $pilih_prodi->kode_prodi)
                                    ->where('tahap', '=', '2')
                                    ->orderBy('nama', 'ASC')->paginate('20');
            $mahasiswa->appends(['prodi' => $pilih_prodi->kode_prodi])->links();
            $fakultas = Fakultas::all();
            $prodi = Prodi::all();

            return view('karyawan.mahasiswa.registrasi.view', compact('mahasiswa', 'fakultas', 'prodi', 'pilih_prodi'));
        } else {
            $fakultas = Fakultas::all();
            $prodi = Prodi::all();

            return view('karyawan.mahasiswa.registrasi.view', compact('fakultas', 'prodi'));
        }
    }

    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $mahasiswa = Registrasi::orWhere('nim', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->where('tahap', '=', '2')
                        ->paginate('20');
        $mahasiswa->appends(['cari' => $cari])->links();
        $fakultas = Fakultas::all();
        $prodi = Prodi::all();
       
        return view('karyawan.mahasiswa.registrasi.view', compact('mahasiswa', 'fakultas', 'prodi', 'cari'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Registrasi::find($id);
        $data_prodi = Prodi::find($data->kode_prodi);
        $fakultas = Fakultas::all();

        return view('karyawan.mahasiswa.registrasi.verifikasi', compact('data', 'data_prodi', 'fakultas'));
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function verifikasi($id)
    {
        $mahasiswa = Registrasi::find($id);

        $data = new Mahasiswa;
        $data->nim = $mahasiswa->nim;
        $data->password = $mahasiswa->password;
        $data->nik = $mahasiswa->nik;
        $data->nama = ucwords(strtolower($mahasiswa->nama));
        $data->tempat_lahir = ucwords(strtolower($mahasiswa->tempat_lahir));
        $data->tgl_lahir = date("Y/m/d", strtotime($mahasiswa->tgl_lahir));
        $data->jenis_kelamin = $mahasiswa->jenis_kelamin;
        $data->alamat = $mahasiswa->alamat;
        $data->desa = $mahasiswa->desa;
        $data->kecamatan = $mahasiswa->kecamatan;
        $data->kota = $mahasiswa->kota;
        $data->provinsi = $mahasiswa->provinsi;
        $data->kodepos = $mahasiswa->kodepos;
        $data->wni = $mahasiswa->wni;
        $data->handphone = $mahasiswa->handphone;
        $data->email = $mahasiswa->email;
        $data->kode_prodi = $mahasiswa->kode_prodi;
        $data->foto = copyRegistrasi($mahasiswa->foto);
        $data->aktif = true;
        $data->save();

        $mahasiswa->tahap = '3';
        $mahasiswa->save();

        return redirect()->back()->with('success', 'verifikasi');
    }
}
