<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\TahunAkademik as TahunAkademik;
use App\Model\Prodi as Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class TahunAkademikController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $tahun_akademik = TahunAkademik::paginate('20');
        $prodi = Prodi::all();
        return view('karyawan.tahun_akademik.view', compact('tahun_akademik', 'prodi'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $tahun_akademik = TahunAkademik::orWhere('kode_thn_akademik', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $tahun_akademik->appends(['cari' => $cari])->links();

        $prodi = Prodi::all();
        
        return view('karyawan.tahun_akademik.view', compact('tahun_akademik', 'prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $prodi = Prodi::all();
        return view('karyawan.tahun_akademik.create', compact('prodi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_thn_akademik' => 'required|string|unique:tahun_akademik',
            'nama' => 'required|string',
            'tgl_awal' => 'date',
            'tgl_akhir' => 'date',
            'kode_prodi' => 'string',
        ]);

        $data = new TahunAkademik;
        $data->kode_thn_akademik = $request->input('kode_thn_akademik');
        $data->nama = $request->input('nama');
        $data->tgl_awal = $request->input('tgl_awal');
        $data->tgl_akhir = $request->input('tgl_akhir');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/tahunakademik')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = TahunAkademik::find($id);
        $prodi = Prodi::all();

        return view('karyawan.tahun_akademik.edit', compact('data' ,'prodi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_thn_akademik' => 'required|string|unique:tahun_akademik,kode_thn_akademik,'.$id.',kode_thn_akademik',
            'nama' => 'required|string',
            'tgl_awal' => 'date',
            'tgl_akhir' => 'date',
            'kode_prodi' => 'string',
        ]);

        $data = TahunAkademik::find($id);
        $data->kode_thn_akademik = $request->input('kode_thn_akademik');
        $data->nama = $request->input('nama');
        $data->tgl_awal = $request->input('tgl_awal');
        $data->tgl_akhir = $request->input('tgl_akhir');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/tahunakademik')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             $hapus = TahunAkademik::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
