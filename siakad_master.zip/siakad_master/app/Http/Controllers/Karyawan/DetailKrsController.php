<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\DetailKrs as DetailKrs;
use App\Model\Krs as Krs;
use App\Model\JadwalKuliah as JadwalKuliah;
use App\Model\Matakuliah as Matakuliah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class DetailKrsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $krs_detail = DetailKrs::paginate('20');
        $krs= Krs::all();
        $jadwal_kuliah= JadwalKuliah::all();
        $mata_kuliah= Matakuliah::all();

        return view('karyawan.krs_detail.view', compact('krs_detail', 'krs', 'jadwal_kuliah', 'mata_kuliah'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $krs_detail = DetailKrs::orWhere('id_detail_krs', 'LIKE', '%'.$cari.'%')
                        ->orWhere('id_krs', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $krs_detail->appends(['cari' => $cari])->links();
        
        $krs= Krs::all();
        $jadwal_kuliah= JadwalKuliah::all();
        $mata_kuliah= Matakuliah::all();

        return view('karyawan.krs_detail.view', compact('krs_detail', 'krs', 'jadwal_kuliah', 'mata_kuliah'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $krs = Krs::all();
        $jadwal_kuliah = JadwalKuliah::all();
        $mata_kuliah = Matakuliah::all();

        return view('karyawan.krs_detail.create', compact('krs', 'jadwal_kuliah', 'mata_kuliah'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_detail_krs' => 'required|string|unique:detail_krs',
            'id_krs' => 'required|string',
            'kode_jadwal_kuliah' => 'string',
            'nilai' => 'string',
            'id_mk' => 'string',
        ]);

        $data = new DetailKrs;
        $data->id_detail_krs = $request->input('id_detail_krs');
        $data->id_krs = $request->input(
            'id_krs');
        $data->kode_jadwal_kuliah = $request->input('kode_jadwal_kuliah');
        $data->nilai = $request->input('nilai');
        $data->kode_mk = $request->input('kode_mk');
        $data->save();

        return redirect('admin/krs_detail')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = DetailKrs::find($id);
        $krs = Krs::all();
        $jadwal_kuliah= JadwalKuliah::all();
        $mata_kuliah= Matakuliah::all();

        return view('karyawan.krs_detail.edit', compact('data', 'krs', 'jadwal_kuliah', 'mata_kuliah'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_detail_krs' => 'required|string|unique:detail_krs,id_detail_krs,'.$id.',id_detail_krs',
            'id_krs' => 'required|string',
            'kode_jadwal_kuliah' => 'string',
            'nilai' => 'string',
            'kode_mk' => 'string',
        ]);

        $data = DetailKrs::find($id);
        $data->id_detail_krs = $request->input('id_detail_krs');
        $data->id_krs = $request->input(
            'id_krs');
        $data->kode_jadwal_kuliah = $request->input('kode_jadwal_kuliah');
        $data->nilai = $request->input('nilai');
        $data->kode_mk = $request->input('kode_mk');
        $data->save();

        return redirect('admin/krs_detail')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = DetailKrs::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


