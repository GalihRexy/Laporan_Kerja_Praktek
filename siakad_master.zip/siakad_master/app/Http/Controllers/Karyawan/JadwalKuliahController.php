<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\JadwalKuliah as JadwalKuliah;
use App\Model\Prodi as Prodi;
use App\Model\Matakuliah as Matakuliah;
use App\Model\TahunAkademik as TahunAkademik;
use App\Model\Ruang as Ruang;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class JadwalKuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $jadwal_kuliah = JadwalKuliah::paginate('20');
        $prodi = Prodi::all();
        $mata_kuliah = Matakuliah::all();
        $ruang = Ruang::all();
        $tahun_akademik = TahunAkademik::all();

        return view('karyawan.jadwal_kuliah.view', compact('jadwal_kuliah', 'prodi', 'mata_kuliah', 'ruang', 'tahun_akademik'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $jadwal_kuliah = JadwalKuliah::orWhere('kode_jadwal_kuliah', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $jadwal_kuliah->appends(['cari' => $cari])->links();
        
        $prodi = Prodi::all();
        $mata_kuliah = Matakuliah::all();
        $ruang = Ruang::all();
        $tahun_akademik = TahunAkademik::all();

        return view('karyawan.jadwal_kuliah.view', compact('jadwal_kuliah', 'prodi', 'mata_kuliah', 'ruang', 'tahun_akademik'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $prodi = Prodi::all();
        $mata_kuliah = Matakuliah::all();
        $ruang = Ruang::all();
        $tahun_akademik = TahunAkademik::all();

        return view('karyawan.jadwal_kuliah.create', compact('prodi', 'mata_kuliah', 'ruang', 'tahun_akademik'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_jadwal_kuliah' => 'required|string|unique:jadwal_kuliah',
            'kode_prodi' => 'string',
            'kode_thn_akademik' => 'string',
            'kelas' => 'string',
            'nidn' => 'string',
            'semester' => 'numeric',
            'kode_mk' => 'string',
            'kode_ruang' => 'string',
        ]);

        $data = new JadwalKuliah;
        $data->kode_jadwal_kuliah = $request->input('kode_jadwal_kuliah');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_thn_akademik = $request->input('kode_thn_akademik');
        $data->kelas = $request->input('kelas');
        $data->nidn = $request->input('nidn');
        $data->semester = $request->input('semester');
        $data->kode_mk = $request->input('kode_mk');
        $data->kode_ruang = $request->input('kode_ruang');
        $data->save();

        return redirect('admin/jadwalkuliah')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = JadwalKuliah::find($id);
        $prodi = Prodi::all();
        $mata_kuliah = Matakuliah::all();
        $ruang = Ruang::all();
        $tahun_akademik = TahunAkademik::all();

        return view('karyawan.jadwal_kuliah.edit', compact('data', 'prodi', 'mata_kuliah', 'ruang', 'tahun_akademik'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_jadwal_kuliah' => 'required|string|unique:jadwal_kuliah,kode_jadwal_kuliah,'.$id.',kode_jadwal_kuliah',
            'kode_prodi' => 'string',
            'kode_thn_akademik' => 'string',
            'kelas' => 'string',
            'nidn' => 'string',
            'semester' => 'numeric',
            'kode_mk' => 'string',
            'kode_ruang' => 'string',
        ]);

        $data = JadwalKuliah::find($id);
        $data->kode_jadwal_kuliah = $request->input('kode_jadwal_kuliah');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_thn_akademik = $request->input('kode_thn_akademik');
        $data->kelas = $request->input('kelas');
        $data->nidn = $request->input('nidn');
        $data->semester = $request->input('semester');
        $data->kode_mk = $request->input('kode_mk');
        $data->kode_ruang = $request->input('kode_ruang');
        $data->save();

        return redirect('admin/jadwalkuliah')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             $hapus = JadwalKuliah::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
