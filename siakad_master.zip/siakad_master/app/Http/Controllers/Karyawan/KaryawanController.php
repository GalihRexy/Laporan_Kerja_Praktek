<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Karyawan as Karyawan;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use App\Model\Level as Level;
use App\Model\Jabatan as Jabatan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class KaryawanController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }
    
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null && $pilih_fakultas == null) { return redirect('admin/karyawan'); }
        if ($pilih_fakultas != null && $pilih_prodi == null) {
            $karyawan = Karyawan::join('prodi', 'karyawan.kode_prodi', '=', 'prodi.kode_prodi')
                        ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                        ->where('fakultas.kode_fakultas', '=', $pilih_fakultas->kode_fakultas)
                        ->select('karyawan.*','prodi.kode_prodi','fakultas.kode_fakultas')
                        ->orderBy('prodi.kode_prodi', 'ASC')
                        ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } elseif ($pilih_prodi != null) {
            $karyawan = Karyawan::where('kode_prodi', '=', $pilih_prodi->kode_prodi)->orderBy('nama', 'ASC')->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } else {
            $karyawan = Karyawan::select('karyawan.*', 'prodi.kode_prodi', 'fakultas.kode_fakultas')
                                    ->join('prodi', 'karyawan.kode_prodi', '=', 'prodi.kode_prodi')
                                    ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                                    ->orderBy('fakultas.nama', 'ASC')
                                    ->orderBy('prodi.nama', 'ASC')
                                    ->orderBy('karyawan.nama', 'ASC')
                                    ->paginate('20');
            $prodi = Prodi::all();
        }
        $fakultas = Fakultas::all();
        $level = Level::all();
        $jabatan = Jabatan::all();

        return view('karyawan.karyawan.view', compact('karyawan', 'prodi', 'level', 'jabatan', 'fakultas', 'pilih_fakultas', 'pilih_prodi'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;
        
        $cari = $request->get('cari');
        $karyawan = Karyawan::orWhere('nik', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $karyawan->appends(['cari' => $cari])->links();
        $fakultas = Fakultas::all();
        $prodi = Prodi::all();
        $level = Level::all();
        $jabatan = Jabatan::all();
        
        return view('karyawan.karyawan.view', compact('karyawan', 'prodi', 'level', 'jabatan', 'fakultas', 'pilih_fakultas', 'pilih_prodi'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $prodi = Prodi::find($id);
        $level = Level::all();
        $jabatan = Jabatan::all();

        return view('karyawan.karyawan.create', compact('prodi', 'level', 'jabatan'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'nik' => 'required|numeric|unique:karyawan',
            'nama' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'provinsi' => 'string',
            'kodepos' => 'string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|numeric|unique:karyawan',
            'email' => 'nullable|string|unique:karyawan',
            'kode_prodi' => 'string',
            'id_jabatan' => 'string',
            'id_level' => 'numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = new Karyawan;
        $data->username = $request->input('nik');
        $data->password = bcrypt($request->input('nik'));
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->provinsi = $request->input('provinsi');
        $data->kodepos = $request->input('kodepos');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->id_jabatan = $request->input('id_jabatan');
        $data->id_level = $request->input('id_level');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'karyawan');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/karyawan?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Karyawan::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $level = Level::all();
        $jabatan = Jabatan::all();

        return view('karyawan.karyawan.info', compact('data', 'prodi', 'level', 'jabatan'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Karyawan::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $level = Level::all();
        $jabatan = Jabatan::all();

        return view('karyawan.karyawan.edit', compact('data', 'prodi', 'level', 'jabatan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'nik' => 'required|numeric|unique:karyawan,nik,'.$id.',nik',
            'nama' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'provinsi' => 'string',
            'kodepos' => 'nullable|string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|numeric|unique:karyawan,handphone,'.$id.',nik',
            'email' => 'nullable|string|unique:karyawan,email,'.$id.',nik',
            'id_jabatan' => 'string',
            'id_level' => 'numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
            'aktif' => 'required|numeric',
        ]);

        $data = Karyawan::find($id);
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->provinsi = $request->input('provinsi');
        $data->kodepos = $request->input('kodepos');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->id_jabatan = $request->input('id_jabatan');
        $data->id_level = $request->input('id_level');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'karyawan');
        $data->aktif = $request->input('aktif');
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/karyawan?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Karyawan::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
