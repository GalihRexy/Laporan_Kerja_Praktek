<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Matakuliah as Matakuliah;
use App\Model\Dosen as Dosen;
use App\Model\RangeNilai as RangeNilai;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class RangeNilaiController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $range_nilai = RangeNilai::paginate('20');
        $Matakuliah = Matakuliah::all();
        $Dosen = Dosen::all();

        return view('karyawan.range_nilai.view', compact('range_nilai', 'matakuliah', 'dosen'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request, $id)
    {
        $cari = $request->get('cari');
        $range_nilai = RangeNilai::orWhere('id_range', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_mk', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $range_nilai->appends(['cari' => $cari])->links();

        $matakuliah = Matakuliah::all();
        $dosen = Dosen::all();
        
        return view('karyawan.range_nilai.view', compact('range_nilai', 'matakuliah', 'dosen'));
    }

    public function create()
    {
        $matakuliah = Matakuliah::all();
        $dosen = Dosen::all();

        return view('karyawan.range_nilai.create', compact('matakuliah', 'dosen'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_range' => '
            required|string|unique:range_nilai',
            'kode_mk' => 'required|string',
            'nidn' => 'required|string',
            'range_a' => 'nullable|string',
            'range_ab' => 'nullable|string',
            'range_b' => 'nullable|string',
            'range_bc' => 'nullable|string',
            'range_c' => 'nullable|string',
            'range_d' => 'nullable|string',
            'aktif' => 'required|numeric',
        ]);

        $data = new RangeNilai;
        $data->id_range = $request->input('id_range');
        $data->kode_mk = $request->input('kode_mk');
        $data->nidn = $request->input('nidn');
        $data->range_a = $request->input('range_a');
        $data->range_ab = $request->input('range_ab');
        $data->range_b = $request->input('range_b');
        $data->range_bc = $request->input('range_bc');
        $data->range_c = $request->input('range_c');
        $data->range_d = $request->input('range_d');
        $data->aktif = $request->input('aktif');
        $data->save();

        return redirect('admin/range_nilai')->with('status', 'success');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = RangeNilai::find($id);
        $matakuliah = Matakuliah::all();
        $dosen = Dosen::all();

        return view('karyawan.range_nilai.info', compact('data', 'matakuliah', 'dosen'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = RangeNilai::find($id);
        $matakuliah = Matakuliah::all();
        $dosen = Dosen::all();

        return view('karyawan.range_nilai.edit', compact('data', 'matakuliah', 'dosen'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_range' => 'required|string|unique:range_nilai,id_range,'.$id.',id_range',
            'kode_mk' => 'required|string',
            'nidn' => 'required|string',
            'range_a' => 'nullable|string',
            'range_ab' => 'nullable|string',
            'range_b' => 'nullable|string',
            'range_bc' => 'nullable|string',
            'range_c' => 'nullable|string',
            'range_d' => 'nullable|string',
            'aktif' => 'required|numeric',
        ]);

        $data = RangeNilai::find($id);
        $data->id_range = $request->input('id_range');
        $data->kode_mk = $request->input('kode_mk');
        $data->nidn = $request->input('nidn');
        $data->range_a = $request->input('range_a');
        $data->range_ab = $request->input('range_ab');
        $data->range_b = $request->input('range_b');
        $data->range_bc = $request->input('range_bc');
        $data->range_c = $request->input('range_c');
        $data->range_d = $request->input('range_d');
        $data->aktif = $request->input('aktif');
        $data->save();

        return redirect('admin/range_nilai')->with('status', 'success');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hapus = RangeNilai::find($id)->delete();

        return redirect()->back()->with('status', 'success');
    }
}


