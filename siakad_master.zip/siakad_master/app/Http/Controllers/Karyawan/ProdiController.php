<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Prodi as Prodi;
use App\Model\Fakultas as Fakultas;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class ProdiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::findOrFail($request->input('fakultas')) : null;
        if ($pilih_fakultas != null) {
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->paginate('20');
        } else {
            $prodi = Prodi::orderBy('kode_fakultas')->orderBy('kode_prodi')->paginate('20');
        }
        $fakultas = Fakultas::all();

        return view('karyawan.prodi.view', compact('prodi', 'fakultas', 'pilih_fakultas'));
    }

    /**
     * Show the form for searching a resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $prodi = Prodi::orWhere('kode_prodi', 'LIKE', '%' . $cari . '%')
            ->orWhere('nama', 'LIKE', '%' . $cari . '%')
            ->paginate('20');
        $prodi->appends(['cari' => $cari])->links();
        $fakultas = Fakultas::all();

        return view('karyawan.prodi.view', compact('prodi', 'fakultas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $fakultas = Fakultas::find($id);

        return view('karyawan.prodi.create', compact('fakultas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_prodi' => 'required|string|unique:prodi',
            'kode_fakultas' => 'string',
            'nama' => 'required|string',
            'jenjang' => 'string',
            'gelar' => 'string',
            'akreditasi' => 'string',
            'sk_dikti' => 'nullable|string',
            'tgl_sk_dikti' => 'date',
            'sk_ban' => 'nullable|string',
            'tgl_sk_ban' => 'date',
            'ketua_prodi' => 'nullable|string',
            'keterangan' => 'nullable|string',
        ]);

        $data = new Prodi;
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_fakultas = $request->input('kode_fakultas');
        $data->nama = $request->input('nama');
        $data->jenjang = $request->input('jenjang');
        $data->gelar = $request->input('gelar');
        $data->akreditasi = $request->input('akreditasi');
        $data->sk_dikti = $request->input('sk_dikti');
        $data->tgl_sk_dikti = $request->input('tgl_sk_dikti');
        $data->sk_ban = $request->input('sk_ban');
        $data->tgl_sk_ban = $request->input('tgl_sk_ban');
        $data->ketua_prodi = $request->input('ketua_prodi');
        $data->keterangan = $request->input('keterangan');
        $data->save();

        return redirect('admin/prodi?fakultas=' . $data->kode_fakultas)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Prodi::find($id);
        $fakultas = Fakultas::all();

        return view('karyawan.prodi.info', compact('data', 'fakultas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Prodi::find($id);
        $fakultas = Fakultas::all();

        return view('karyawan.prodi.edit', compact('data', 'fakultas'));
    }

    public function aktif(Request $request, $id)
    {
        $data = Prodi::find($id);
        $data->aktif = $request->input('aktif');
        $data->save();

        return redirect()->back()->with('success', 'operation');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_prodi' => 'required|string|unique:prodi,kode_prodi,' . $id . ',kode_prodi',
            'kode_fakultas' => 'string',
            'nama' => 'required|string',
            'jenjang' => 'string',
            'gelar' => 'string',
            'akreditasi' => 'string',
            'sk_dikti' => 'nullable|string',
            'tgl_sk_dikti' => 'date',
            'sk_ban' => 'nullable|string',
            'tgl_sk_ban' => 'date',
            'ketua_prodi' => 'nullable|string',
            'keterangan' => 'nullable|string',
        ]);

        $data = Prodi::find($id);
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_fakultas = $request->input('kode_fakultas');
        $data->nama = $request->input('nama');
        $data->jenjang = $request->input('jenjang');
        $data->gelar = $request->input('gelar');
        $data->akreditasi = $request->input('akreditasi');
        $data->sk_dikti = $request->input('sk_dikti');
        $data->tgl_sk_dikti = $request->input('tgl_sk_dikti');
        $data->sk_ban = $request->input('sk_ban');
        $data->tgl_sk_ban = $request->input('tgl_sk_ban');
        $data->ketua_prodi = $request->input('ketua_prodi');
        $data->keterangan = $request->input('keterangan');
        $data->save();

        return redirect('admin/prodi?fakultas=' . $data->kode_fakultas)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Prodi::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
