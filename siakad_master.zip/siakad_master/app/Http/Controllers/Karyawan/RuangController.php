<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Ruang as Ruang;
use App\Model\Prodi as Prodi;
use App\Model\Kampus as Kampus;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class RuangController extends Controller
{
    /**
     * Display a listing choice of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function kampus()
    {
        $data_kampus = Kampus::all();

        return view('karyawan.ruang.view', compact('data_kampus'));
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index($id)
    {
        $ruang = Ruang::where('kode_kampus', '=', $id)->paginate('20');
        $data_kampus = Kampus::all();
        $kampus = Kampus::find($id);
        $prodi = Prodi::all();

        return view('karyawan.ruang.view', compact('ruang', 'data_kampus', 'kampus', 'prodi', 'id'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request, $id)
    {
        $cari = $request->get('cari');
        $ruang = Ruang::orWhere('kode_ruang', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $ruang->appends(['cari' => $cari])->links();

        $data_kampus = Kampus::all();
        $kampus = Kampus::find($id);
        $prodi = Prodi::all();
        
        return view('karyawan.ruang.view', compact('ruang', 'data_kampus', 'kampus', 'prodi', 'id'));
    }

    public function create($id)
    {
        $kampus = Kampus::find($id);
        $prodi = Prodi::all();

        return view('karyawan.ruang.create', compact('kampus', 'prodi', 'id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_ruang' => 'required|string|unique:ruang',
            'kode_kampus' => 'required|string',
            'kode_prodi' => 'required|string',
            'nama' => 'required|string',
            'lantai' => 'nullable|string',
            'kapasitas' => 'nullable|numeric',
            'kapasitas_ujian' => 'nullable|numeric',
            'kolom_meja' => 'nullable|numeric',
            'keterangan' => 'nullable|string',
            'ruang_kuliah' => 'numeric',
            'ruang_usm' => 'numeric',
        ]);

        $data = new Ruang;
        $data->kode_ruang = $request->input('kode_ruang');
        $data->kode_kampus = $request->input('kode_kampus');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->nama = $request->input('nama');
        $data->lantai = $request->input('lantai');
        $data->kapasitas = $request->input('kapasitas');
        $data->kapasitas_ujian = $request->input('kapasitas_ujian');
        $data->kolom_meja = $request->input('kolom_meja');
        $data->keterangan = $request->input('keterangan');
        $data->ruang_kuliah = $request->input('ruang_kuliah');
        $data->ruang_usm = $request->input('ruang_usm');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/ruang/'.$data->kode_kampus)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Ruang::find($id);
        $kampus = Kampus::all();
        $prodi = Prodi::all();

        return view('karyawan.ruang.info', compact('data', 'kampus', 'prodi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Ruang::find($id);
        $kampus = Kampus::all();
        $prodi = Prodi::all();

        return view('karyawan.ruang.edit', compact('data', 'kampus', 'prodi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_ruang' => 'required|string|unique:ruang,kode_ruang,'.$id.',kode_ruang',
            'kode_kampus' => 'required|string',
            'kode_prodi' => 'required|string',
            'nama' => 'required|string',
            'lantai' => 'nullable|string',
            'kapasitas' => 'nullable|numeric',
            'kapasitas_ujian' => 'nullable|numeric',
            'kolom_meja' => 'nullable|numeric',
            'keterangan' => 'nullable|string',
            'ruang_kuliah' => 'numeric',
            'ruang_usm' => 'numeric',
        ]);

        $data = Ruang::find($id);
        $data->kode_ruang = $request->input('kode_ruang');
        $data->kode_kampus = $request->input('kode_kampus');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->nama = $request->input('nama');
        $data->lantai = $request->input('lantai');
        $data->kapasitas = $request->input('kapasitas');
        $data->kapasitas_ujian = $request->input('kapasitas_ujian');
        $data->kolom_meja = $request->input('kolom_meja');
        $data->keterangan = $request->input('keterangan');
        $data->ruang_kuliah = $request->input('ruang_kuliah');
        $data->ruang_usm = $request->input('ruang_usm');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/ruang/'.$data->kode_kampus)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hapus = Ruang::find($id)->delete();

        return redirect()->back()->with('success', 'delete');
    }
}


