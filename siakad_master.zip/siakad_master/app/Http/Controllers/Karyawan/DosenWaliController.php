<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\DosenWali as DosenWali;
use App\Model\Dosen as Dosen;
use App\Model\Mahasiswa as Mahasiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class DosenWaliController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $dosen_wali = DosenWali::paginate('20');
        return view('karyawan.dosen_wali.view', compact('dosen_wali'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $dosen_wali = DosenWali::orWhere('id_dosen_wali', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nidn', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nim', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $skpi->appends(['cari' => $cari])->links();
        
        return view('karyawan.dosen_wali.view', compact('dosen_wali'));
    }

    public function create()
    {   
        $dosen = Dosen::all();
        $mahasiswa = Mahasiswa::all();

        return view('karyawan.dosen_wali.create', compact('dosen','mahasiswa'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_dosen_wali' => 'required|string|unique:dosen_wali',
            'nidn' => 'string',
            'nim' => 'string',
            'id_sk_dosen_wali' => 'string',
        ]);

        $data = new DosenWali;
        $data->id_dosen_wali = $request->input('id_dosen_wali');
        $data->nidn = $request->input('nidn');
        $data->nim = $request->input('nim');
        $data->id_sk_dosen_wali = $request->input('id_sk_dosen_wali');
        $data->save();

        return redirect('admin/dosen_wali')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = DosenWali::find($id);

        $dosen = Dosen::all();
        $mahasiswa = Mahasiswa::all();

        return view('karyawan.dosen_wali.edit', compact('data', 'dosen','mahasiswa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_dosen_wali' => 'required|string|unique:dosen_wali,id_dosen_wali,'.$id.',id_dosen_wali',
            'nidn' => 'string',
            'nim' => 'string',
            'id_sk_dosen_wali' => 'string',
        ]);

        $data = DosenWali::find($id);
        $data->id_dosen_wali = $request->input('id_dosen_wali');
        $data->nidn = $request->input('nidn');
        $data->nim = $request->input('nim');
        $data->id_sk_dosen_wali = $request->input('id_sk_dosen_wali');
        $data->save();

        return redirect('admin/dosen_wali')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = DosenWali::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
