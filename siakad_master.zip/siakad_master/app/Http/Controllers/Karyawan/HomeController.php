<?php

namespace App\Http\Controllers\Karyawan;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:admin,super_user');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('karyawan.home');
    }

    public function sidebar(Request $request, $id)
    {
        if ($id == 'true') {
            $request->session()->put('sidebar', 'true');
            $request->session()->put('sidebarMenu', 'false');
        } elseif ($id == 'false') {
            $request->session()->put('sidebar', 'false');
            if ($request->input('open') != null) {
                $request->session()->put('sidebarMenu', $request->input('open'));
            }
        }

        return response($id, 200);
    }
}
