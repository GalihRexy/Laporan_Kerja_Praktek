<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\LearningOutcomes as LearningOutcomes;
use App\Model\StudyOutcomes as StudyOutcomes;
use App\Model\Matakuliah as Matakuliah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class LearningOutcomesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $learning_outcomes = LearningOutcomes::paginate('20');
        $study_outcomes = StudyOutcomes::all();
        return view('karyawan.learning_outcomes.view', compact('learning_outcomes', 'study_outcomes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $learning_outcomes = LearningOutcomes::orWhere('id_lo', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_so', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $learning_outcomes->appends(['cari' => $cari])->links();

        $study_outcomes = StudyOutcomes::all();
        
        return view('karyawan.learning_outcomes.view', compact('learning_outcomes', 'study_outcomes'));
    }

    public function create()
    {
        $study_outcomes = StudyOutcomes::all();
        $matakuliah = Matakuliah::all();

        return view('karyawan.learning_outcomes.create', compact('study_outcomes', 'matakuliah'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_lo' => 'required|string|unique:learning_outcomes',
            'kode_so' => 'required|string',
            'kode_mk' => 'required|string',
            'deskripsi_lo' => 'string',
            'materi' => 'string',
            'metode_pembelajaran' => 'string',
            'total_bobot' => 'string',
        ]);

        $data = new LearningOutcomes;
        $data->id_lo = $request->input('id_lo');
        $data->kode_so = $request->input('kode_so');
        $data->kode_mk = $request->input('kode_mk');
        $data->deskripsi_lo = $request->input('deskripsi_lo');
        $data->materi = $request->input('materi');
        $data->metode_pembelajaran = $request->input('metode_pembelajaran');
        $data->total_bobot = $request->input('total_bobot');
        $data->save();

        return redirect('admin/learning_outcomes')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = LearningOutcomes::find($id);
        $study_outcomes = StudyOutcomes::all();
        $matakuliah = Matakuliah::all();

        return view('karyawan.learning_outcomes.edit', compact('data', 'study_outcomes', 'matakuliah'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */


    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_lo' => 'required|string|unique:learning_outcomes,id_lo,'.$id.',id_lo',
            'kode_so' => 'required|string',
            'kode_mk' => 'required|string',
            'deskripsi_lo' => 'string',
            'materi' => 'string',
            'metode_pembelajaran' => 'string',
             'total_bobot' => 'string',
        ]);

        $data = LearningOutcomes::find($id);
        $data->id_lo = $request->input('id_lo');
        $data->kode_so = $request->input(
            'kode_so');
        $data->kode_mk = $request->input('kode_mk');
        $data->deskripsi_lo = $request->input('deskripsi_lo');
        $data->materi = $request->input('materi');
        $data->metode_pembelajaran = $request->input('metode_pembelajaran');
        $data->total_bobot = $request->input('total_bobot');
        $data->save();

        return redirect('admin/learning_outcomes')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = LearningOutcomes::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


