<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\KlasifikasiDosen as KlasifikasiDosen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class KlasifikasiDosenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
         $klasifikasi_dosen = KlasifikasiDosen::paginate('20');

        return view('karyawan.klasifikasi_dosen.view', compact('klasifikasi_dosen'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $klasifikasi_dosen = KlasifikasiDosen::orWhere('id_klasifikasi_dosen', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $klasifikasi_dosen->appends(['cari' => $cari])->links();
        
        return view('karyawan.klasifikasi_dosen.view', compact('klasifikasi_dosen'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function create()
    {
        return view('karyawan.klasifikasi_dosen.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'nama' => 'required|string|unique:klasifikasi_dosen',
        ]);

        $data = new KlasifikasiDosen();
        $data->nama = $request->input('nama');
        $data->save();

        return redirect('admin/klasifikasi_dosen')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = KlasifikasiDosen::find($id);

        return view('karyawan.klasifikasi_dosen.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $validator = $this->validate($request, [
            'nama' => 'required|string|unique:klasifikasi_dosen,nama,'.$id.',id_klasifikasi_dosen',
        ]);

        $data = KlasifikasiDosen::find($id);
        $data->nama = $request->input('nama');
        $data->save();

        return redirect('admin/klasifikasi_dosen')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = KlasifikasiDosen::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }


        return redirect()->back()->with('success', 'delete');
    }
}
