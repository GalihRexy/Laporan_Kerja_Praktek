<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Kurikulum as Kurikulum;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class KurikulumController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null && $pilih_fakultas == null) { return redirect('admin/kurikulum'); }
        if ($pilih_fakultas != null && $pilih_prodi == null) {
            $kurikulum = Kurikulum::join('prodi', 'kurikulum.kode_prodi', '=', 'prodi.kode_prodi')
                        ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                        ->where('fakultas.kode_fakultas', '=', $pilih_fakultas->kode_fakultas)
                        ->select('kurikulum.*','fakultas.kode_fakultas')
                        ->orderBy('kode_prodi', 'ASC')
                        ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } elseif ($pilih_prodi != null) {
            $kurikulum = Kurikulum::where('kode_prodi', '=', $pilih_prodi->kode_prodi)->orderBy('nama', 'ASC')->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } else {
            $kurikulum = Kurikulum::select('kurikulum.*', 'prodi.kode_prodi', 'fakultas.kode_fakultas')
                                    ->join('prodi', 'kurikulum.kode_prodi', '=', 'prodi.kode_prodi')
                                    ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                                    ->orderBy('fakultas.nama', 'ASC')
                                    ->orderBy('prodi.nama', 'ASC')
                                    ->orderBy('kurikulum.nama', 'ASC')
                                    ->paginate('20');
            $prodi = Prodi::all();
        }
       $fakultas = Fakultas::all();
        

        return view('karyawan.kurikulum.view', compact('kurikulum', 'prodi', 'fakultas', 'pilih_fakultas', 'pilih_prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;
        $cari = $request->get('cari');
        $kurikulum = Kurikulum::orWhere('kode_kurikulum', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $kurikulum->appends(['cari' => $cari])->links();

        $fakultas = Fakultas::all();
        $prodi = Prodi::all();

        
        return view('karyawan.kurikulum.view', compact('kurikulum', 'prodi', 'fakultas'));
    }

    public function create($id)
    {
        $prodi = Prodi::find($id);

        return view('karyawan.kurikulum.create', compact('prodi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $validator = $this->validate($request, [
            'kode_kurikulum' => 'required|string|unique:kurikulum',
            'kode_prodi' => 'string',
            'tahun' => 'numeric',
            'nama' => 'required|string',
        ]);

        $data = new Kurikulum;
        $data->kode_kurikulum = $request->input('kode_kurikulum');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->tahun = $request->input('tahun');
        $data->nama = $request->input('nama');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/kurikulum?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Kurikulum::find($id);
        $prodi = Prodi::find($data->kode_prodi);

        return view('karyawan.kurikulum.info', compact('data', 'prodi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Kurikulum::find($id);
        $prodi = Prodi::find($data->kode_prodi);

        return view('karyawan.kurikulum.edit', compact('data', 'prodi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_kurikulum' => 'required|string|unique:kurikulum,kode_kurikulum,'.$id.',kode_kurikulum',
            'kode_prodi' => 'string',
            'tahun' => 'numeric',
            'nama' => 'required|string',
        ]);

        $data = Kurikulum::find($id);
        $data->kode_kurikulum = $request->input('kode_kurikulum');
        $data->tahun = $request->input('tahun');
        $data->nama = $request->input('nama');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/kurikulum?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Kurikulum::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
