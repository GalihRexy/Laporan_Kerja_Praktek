<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Nilai as Nilai;
use App\Model\Assessment as Assessment;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class NilaiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $nilai = Nilai::paginate('20');
        $assessment = Assessment::all();
        return view('karyawan.nilai.view', compact('nilai','assessment'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $nilai = Nilai::orWhere('id_nilai', 'LIKE', '%'.$cari.'%')
                        ->orWhere('id_assessment', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $nilai->appends(['cari' => $cari])->links();
        
        $assessment = Assessment::all();
        return view('karyawan.nilai.view', compact('nilai','assessment'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $assessment = Assessment::all();

        return view('karyawan.nilai.create', compact('assessment'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_nilai' => 'required|string|unique:nilai',
            'id_assessment' => 'string',
            'nim' => 'required|string',
            'nilai' => 'numeric',
            'tgl_assessment' => 'date',
        ]);

         $data = new Nilai;
        $data->id_nilai = $request->input('id_nilai');
        $data->id_assessment = $request->input('id_assessment');
        $data->nim = $request->input('nim');
        $data->nilai = $request->input('nilai');
        $data->tgl_assessment = $request->input('tgl_assessment');
        $data->save();

        return redirect('admin/nilai')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Nilai::find($id);
        $assessment = Assessment::all();

        return view('karyawan.nilai.edit', compact('data', 'assessment'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_nilai' => 'required|string|unique:nilai,id_nilai,'.$id.',id_nilai',
            'id_assessment' => 'string',
            'nim' => 'required|string',
            'nilai' => 'numeric',
            'tgl_assessment' => 'date',
        ]);

        $data = Nilai::find($id);
        $data->id_nilai = $request->input('id_nilai');
        $data->id_assessment = $request->input('id_assessment');
        $data->nim = $request->input('nim');
        $data->nilai = $request->input('nilai');
        $data->tgl_assessment = $request->input('tgl_assessment');
        $data->save();

        return redirect('admin/nilai')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Nilai::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
