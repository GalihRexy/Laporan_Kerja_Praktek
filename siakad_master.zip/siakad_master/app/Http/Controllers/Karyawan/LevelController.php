<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Level as Level;
use App\Model\Modul as Modul;
use App\Model\ModulGroup as ModulGroup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class LevelController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $level = Level::paginate('20');
        $modul = Modul::where('aktif', '=', '1')->get();
        $modul_group = ModulGroup::where('aktif', '=', '1')
                                ->where('super_only', '=', '0')
                                ->get();

        return view('karyawan.level.view', compact('level', 'modul', 'modul_group'));
    }

/**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $level = Level::orWhere('id_level', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $level->appends(['cari' => $cari])->links();
        $modul = Modul::all();
        $modul_group = ModulGroup::all();
        
        return view('karyawan.level.view', compact('level', 'modul', 'modul_group'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $modul = Modul::where('aktif', '=', '1')->get();
        $modul_group = ModulGroup::where('aktif', '=', '1')
                                ->where('super_only', '=', '0')
                                ->get();

        return view('karyawan.level.create', compact('modul', 'modul_group'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'nama' => 'required|string|unique:level',
            'hak_akses' => 'required|array',
            'hak_akses.*' => 'required|numeric',
            'keterangan' => 'nullable|string',
        ]);

        $data = new Level;
        $data->nama = $request->input('nama');
        $data->hak_akses = hakAkses($request->input('hak_akses'));
        $data->keterangan = $request->input('keterangan');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/level')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Level::find($id);
        $modul = Modul::where('aktif', '=', '1')->get();
        $modul_group = ModulGroup::where('aktif', '=', '1')
                                ->where('super_only', '=', '0')
                                ->get();

        return view('karyawan.level.edit', compact('data', 'modul', 'modul_group'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'nama' => 'required|string|unique:level,id_level,'.$id.',id_level',
            'hak_akses' => 'required|array',
            'hak_akses.*' => 'required|numeric',
            'keterangan' => 'nullable|string',
        ]);

        $data = Level::find($id);
        $data->nama = $request->input('nama');
        $data->hak_akses = hakAkses($request->input('hak_akses'));
        $data->keterangan = $request->input('keterangan');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/level')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Level::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


