<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\SkDosenWali as SkDosenWali;
use App\Model\Prodi as Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class SkDosenWaliController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       $sk_dosen_wali = SkDosenWali::paginate('20');
       return view('karyawan.sk_dosen_wali.view', compact('sk_dosen_wali')); 
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $sk_dosen_wali = SkDosenWali::orWhere('id_sk_dosen_wali', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nomor_sk_dosen_wali', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_prodi', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $skpi->appends(['cari' => $cari])->links();
        
        return view('karyawan.sk_dosen_wali.view', compact('id_sk_dosen_wali'));
    }

    public function create()
    {

        $prodi = Prodi::all();

        return view('karyawan.sk_dosen_wali.create', compact('prodi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_sk_dosen_wali' => 'required|string|unique:sk_dosen_wali',
            'nomor_sk_dosen_wali' => 'string',
            'tanggal_sk' => 'date',
            'kode_prodi' => 'string',
        ]);

        $data = new SkDosenWali;
        $data->id_sk_dosen_wali = $request->input('id_sk_dosen_wali');
        $data->nomor_sk_dosen_wali = $request->input('nomor_sk_dosen_wali');
        $data->tanggal_sk = $request->input('tanggal_sk');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->save();

        return redirect('admin/sk_dosen_wali')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = SkDosenWali::find($id);

        $prodi = Prodi::all();

        return view('karyawan.sk_dosen_wali.edit', compact('data', 'prodi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_sk_dosen_wali' => 'required|string|unique:sk_dosen_wali,id_sk_dosen_wali'.$id.'id_sk_dosen_wali',
            'nomor_sk_dosen_wali' => 'string',
            'tanggal_sk' => 'date',
            'kode_prodi' => 'string',
        ]);

        $data = SkDosenWali::find($id);
        $data->id_sk_dosen_wali = $request->input('id_sk_dosen_wali');
        $data->nomor_sk_dosen_wali = $request->input('nomor_sk_dosen_wali');
        $data->tanggal_sk = $request->input('tanggal_sk');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->save();

        return redirect('admin/sk_dosen_wali')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = SkDosenWali::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
