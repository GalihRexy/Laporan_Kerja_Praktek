<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Khs as Khs;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class KhsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $khs = Khs::paginate('20');

        return view('karyawan.khs.view', compact('khs'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $khs = Khs::orWhere('kode_khs', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nim', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $khs->appends(['cari' => $cari])->links();
        
        return view('karyawan.khs.view', compact('khs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('karyawan.khs.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_khs' => 'required|string|unique:khs',
            'nim' => 'required|string|unique:khs',
            'tahun_semester' => 'string',
            'total_sks_sdh_diambil' => 'numeric',
            'total_sks_blm_diambil' => 'numeric',
            'tmt' => 'string',
            'tst' => 'string',
        ]);

        $data = new Khs;
        $data->kode_khs = $request->input('kode_khs');
        $data->nim = $request->input('nim');
        $data->tahun_semester = $request->input('tahun_semester');
        $data->total_sks_sdh_diambil = $request->input('total_sks_sdh_diambil');
        $data->total_sks_blm_diambil = $request->input('total_sks_blm_diambil');
        $data->tmt = $request->input('tmt');
        $data->tst = $request->input('tst');
        $data->save();

        return redirect('admin/khs')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
         $data = Khs::find($id);

        return view('karyawan.khs.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_khs' => 'required|string|unique:khs,kode_khs,'.$id.',kode_khs',
            'nim' => 'required|string|unique:khs,kode_khs,'.$id.',kode_khs',
            'tahun_semester' => 'string',
            'total_sks_sdh_diambil' => 'numeric',
            'total_sks_blm_diambil' => 'numeric',
            'tmt' => 'string',
            'tst' => 'string',
        ]);

        $data = Khs::find($id);
        $data->kode_khs = $request->input('kode_khs');
        $data->nim = $request->input('nim');
        $data->tahun_semester = $request->input('tahun_semester');
        $data->total_sks_sdh_diambil = $request->input('total_sks_sdh_diambil');
        $data->total_sks_blm_diambil = $request->input('total_sks_blm_diambil');
        $data->tmt = $request->input('tmt');
        $data->tst = $request->input('tst');
        $data->save();

        return redirect('admin/khs')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Khs::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
