<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\PrasyaratMatakuliah as PrasyaratMatakuliah;
use App\Model\Matakuliah as Matakuliah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class PrasyaratMatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $prasyarat_matakuliah = PrasyaratMatakuliah::paginate('20');
        $matakuliah = Matakuliah::all();

        return view('karyawan.prasyarat_matakuliah.view', compact('prasyarat_matakuliah', 'matakuliah'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $prasyarat_matakuliah = PrasyaratMatakuliah::orWhere('kode_prasyarat_mk', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_mk', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $prasyarat_matakuliah->appends(['cari' => $cari])->links();

        $matakuliah = Matakuliah::all();

        
        return view('karyawan.prasyarat_matakuliah.view', compact('prasyarat_matakuliah', 'matakuliah'));
    }

    public function create()
    {
        $matakuliah = Matakuliah::all();

        return view('karyawan.prasyarat_matakuliah.create', compact('matakuliah'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_prasyarat_mk' => 'required|string|unique:prasyarat_matakuliah',
            'kode_mk' => 'string',
            'kode_mk_prasyarat' => 'string',
        ]);

        $data = new PrasyaratMatakuliah;
        $data->kode_prasyarat_mk = $request->input('kode_prasyarat_mk');
        $data->kode_mk = $request->input('kode_mk');
        $data->kode_mk_prasyarat = $request->input('kode_mk_prasyarat');
        $data->save();

        return redirect('admin/prasyaratmatakuliah')->with('success', 'create');
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = PrasyaratMatakuliah::find($id);
        $matakuliah = Matakuliah::all();

        return view('karyawan.prasyarat_matakuliah.edit', compact('data', 'matakuliah'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_prasyarat_mk' => 'required|string|unique:prasyarat_matakuliah,kode_prasyarat_mk,'.$id.',kode_prasyarat_mk',
            'kode_mk' => 'string',
            'kode_mk_prasyarat' => 'string',
        ]);

        $data = PrasyaratMatakuliah::find($id);
        $data->kode_prasyarat_mk = $request->input('kode_prasyarat_mk');
        $data->kode_mk = $request->input('kode_mk');
        $data->kode_mk_prasyarat = $request->input('kode_mk_prasyarat');
        $data->save();

        return redirect('admin/prasyaratmatakuliah')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = PrasyaratMatakuliah::find($id)->delete();  
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
