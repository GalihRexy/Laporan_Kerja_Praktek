<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Dosen as Dosen;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use App\Model\Jabatan as Jabatan;
use App\Model\KlasifikasiDosen as KlasifikasiDosen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller as Controller;

class DosenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null && $pilih_fakultas == null) { return redirect('/dosen'); }
        if ($pilih_fakultas != null && $pilih_prodi == null) {
            $dosen = Dosen::select('dosen.*','prodi.kode_prodi','fakultas.kode_fakultas')
                        ->join('prodi', 'dosen.kode_prodi', '=', 'prodi.kode_prodi')
                        ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                        ->where('fakultas.kode_fakultas', '=', $pilih_fakultas->kode_fakultas)
                        ->orderBy('prodi.nama', 'asc')
                        ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } elseif ($pilih_prodi != null) {
            $dosen = Dosen::where('kode_prodi', '=', $pilih_prodi->kode_prodi)
                        ->orderBy('dosen.nama', 'asc')
                        ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } else {
            $dosen = Dosen::select('dosen.*','prodi.kode_prodi','fakultas.kode_fakultas')
                        ->join('prodi', 'dosen.kode_prodi', '=', 'prodi.kode_prodi')
                        ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                        ->orderBy('fakultas.nama', 'asc')
                        ->orderBy('prodi.nama', 'asc')
                        ->orderBy('dosen.nama', 'asc')
                        ->paginate('20');
            $prodi = Prodi::all();
        }
        $fakultas = Fakultas::all();
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        return view('karyawan.dosen.view', compact('dosen', 'prodi', 'jabatan', 'klasifikasi_dosen','fakultas', 'pilih_fakultas', 'pilih_prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;
        
        $cari = $request->get('cari');
        $dosen = Dosen::orWhere('nidn', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $dosen->appends(['cari' => $cari])->links();

        $fakultas = Fakultas::all();
        $prodi = Prodi::all();
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        
        return view('karyawan.dosen.view', compact('dosen', 'prodi', 'jabatan', 'klasifikasi_dosen', 'fakultas', 'pilih_fakultas', 'pilih_prodi'));
    }

    public function create($id)
    {
        $prodi = Prodi::find($id);
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        return view('karyawan.dosen.create', compact('prodi', 'jabatan', 'klasifikasi_dosen'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'nidn' => 'required|string|unique:dosen',
            'nip_pns' => 'nullable|string',
            'nik' => 'required|string',
            'nama' => 'required|string',
            'tempat_lahir' => 'required|string',
            'tgl_lahir' => 'required|date',
            'jenis_kelamin' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'kodepos' => 'nullable|string',
            'provinsi' => 'string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|string',
            'email' => 'nullable|string',
            'gelar' => 'nullable|string',
            'jenjang' => 'nullable|string',
            'keilmuan' => 'nullable|string',
            'lulusan_pt' => 'nullable|string',
            'kode_prodi' => 'string',
            'institusi_induk' => 'nullable|string',
            'id_jabatan' => 'numeric',
            'id_klasifikasi_dosen' => 'numeric',
            'no_rek' => 'nullable|numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = new Dosen;
        $data->nidn = $request->input('nidn');
        $data->username = $request->input('nidn');
        $data->password = bcrypt($request->input('nidn'));
        $data->nip_pns = $request->input('nip_pns');
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->tempat_lahir = $request->input('tempat_lahir');
        $data->tgl_lahir = $request->input('tgl_lahir');
        $data->jenis_kelamin = $request->input('jenis_kelamin');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->gelar = $request->input('gelar');
        $data->jenjang = $request->input('jenjang');
        $data->keilmuan = $request->input('keilmuan');
        $data->lulusan_pt = $request->input('lulusan_pt');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->institusi_induk = $request->input('institusi_induk');
        $data->id_jabatan = $request->input('id_jabatan');
        $data->id_klasifikasi_dosen = $request->input('id_klasifikasi_dosen');
        $data->no_rek = $request->input('no_rek');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'dosen');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/dosen?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Dosen::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        return view('karyawan.dosen.info', compact('data', 'prodi', 'jabatan', 'klasifikasi_dosen'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Dosen::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        return view('karyawan.dosen.edit', compact('data', 'prodi', 'jabatan', 'klasifikasi_dosen'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'nidn' => 'required|string|unique:dosen,nidn,'.$id.',nidn',
            'nip_pns' => 'nullable|string',
            'nik' => 'required|string',
            'nama' => 'required|string',
            'tempat_lahir' => 'required|string',
            'tgl_lahir' => 'required|date',
            'jenis_kelamin' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'kodepos' => 'nullable|string',
            'provinsi' => 'string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|string',
            'email' => 'nullable|string',
            'gelar' => 'nullable|string',
            'jenjang' => 'nullable|string',
            'keilmuan' => 'nullable|string',
            'lulusan_pt' => 'nullable|string',
            'institusi_induk' => 'nullable|string',
            'id_jabatan' => 'numeric',
            'id_klasifikasi_dosen' => 'numeric',
            'no_rek' => 'nullable|numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
            'aktif' => 'required|numeric',
        ]);

        $data = Dosen::find($id);
        $data->nidn = $request->input('nidn');
        $data->nip_pns = $request->input('nip_pns');
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->tempat_lahir = $request->input('tempat_lahir');
        $data->tgl_lahir = $request->input('tgl_lahir');
        $data->jenis_kelamin = $request->input('jenis_kelamin');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->gelar = $request->input('gelar');
        $data->jenjang = $request->input('jenjang');
        $data->keilmuan = $request->input('keilmuan');
        $data->lulusan_pt = $request->input('lulusan_pt');
        $data->institusi_induk = $request->input('institusi_induk');
        $data->id_jabatan = $request->input('id_jabatan');
        $data->id_klasifikasi_dosen = $request->input('id_klasifikasi_dosen');
        $data->no_rek = $request->input('no_rek');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'dosen');
        $data->aktif = $request->input('aktif');
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/dosen?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   
        try{
            $hapus = Dosen::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


