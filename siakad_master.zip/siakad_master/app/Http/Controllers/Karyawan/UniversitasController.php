<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Universitas;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class UniversitasController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $universitas = Universitas::find('data');

        return view('karyawan.universitas.view', compact('universitas'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        $data = Universitas::find('data');

        return view('karyawan.universitas.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $validator = $this->validate($request, [
            'id_univ' => 'required|string',
            'nama' => 'required|string',
            'alamat' => 'string',
            'kota' => 'string',
            'kodepos' => 'numeric',
            'provinsi' => 'string',
            'telepon' => 'string|unique:universitas,telepon,data',
            'fax' => 'string|unique:universitas,fax,data',
            'email' => 'string|unique:universitas,email,data',
            'website' => 'string|unique:universitas,website,data',
            'akta' => 'string',
            'tgl_akta' => 'date',
            'pengesahan' => 'string',
            'tgl_pengesahan' => 'date',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = Universitas::find('data');
        $data->id_univ = $request->input('id_univ');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->telepon = $request->input('telepon');
        $data->fax = $request->input('fax');
        $data->email = $request->input('email');
        $data->website = $request->input('website');
        $data->akta = $request->input('akta');
        $data->tgl_akta = $request->input('tgl_akta');
        $data->pengesahan = $request->input('pengesahan');
        $data->tgl_pengesahan = $request->input('tgl_pengesahan');
        $data->logo = checkFile($data->logo, $request->file('logo'), 'logo', 'universitas');
        $data->save();

        return redirect('admin/universitas')->with('success', 'edit');
    }
}


