<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Matakuliah as Matakuliah;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use App\Model\Kurikulum as Kurikulum;
use App\Model\JenisMatakuliah as JenisMatakuliah;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class MatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null && $pilih_fakultas == null) { return redirect('admin/matakuliah'); }
        if ($pilih_fakultas != null && $pilih_prodi == null) {
            $matakuliah = Matakuliah::join('prodi', 'matakuliah.kode_prodi', '=', 'prodi.kode_prodi')
                        ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                        ->where('fakultas.kode_fakultas', '=', $pilih_fakultas->kode_fakultas)
                        ->select('matakuliah.*','fakultas.kode_fakultas')
                        ->orderBy('kode_prodi', 'ASC')
                        ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } elseif ($pilih_prodi != null) {
            $matakuliah = Matakuliah::where('kode_prodi', '=', $pilih_prodi->kode_prodi)->orderBy('nama', 'ASC')->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } else {
            $matakuliah = Matakuliah::select('matakuliah.*', 'prodi.kode_prodi', 'fakultas.kode_fakultas')
                                    ->join('prodi', 'matakuliah.kode_prodi', '=', 'prodi.kode_prodi')
                                    ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                                    ->orderBy('fakultas.nama', 'ASC')
                                    ->orderBy('prodi.nama', 'ASC')
                                    ->orderBy('matakuliah.nama', 'ASC')
                                    ->paginate('20');
            $prodi = Prodi::all();
        }
        $fakultas = Fakultas::all();
        $kurikulum = Kurikulum::all();
        $jenis_matakuliah = JenisMatakuliah::all();

        return view('karyawan.matakuliah.view', compact('matakuliah', 'fakultas', 'prodi', 'kurikulum', 'jenis_matakuliah', 'pilih_fakultas', 'pilih_prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        $cari = $request->get('cari');
        $matakuliah = Matakuliah::orWhere('kode_mk', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $matakuliah->appends(['cari' => $cari])->links();

        $prodi = Prodi::all();
        $kurikulum = Kurikulum::all();
        $jenis_matakuliah = JenisMatakuliah::all();
        $fakultas = Fakultas::all();
        
        return view('karyawan.matakuliah.view', compact('matakuliah', 'prodi', 'kurikulum', 'jenis_matakuliah', 'fakultas'));
    }
    public function create($id)
    {
        $prodi = Prodi::find($id);
        $kurikulum = Kurikulum::all();
        $jenis_matakuliah = JenisMatakuliah::all();

        return view('karyawan.matakuliah.create', compact('prodi', 'kurikulum', 'jenis_matakuliah', 'id'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_mk' => 'required|string|unique:matakuliah',
            'nama' => 'required|string',
            'sks' => 'numeric',
            'kode_prodi' => 'string',
            'kode_jenis_mk' => 'string',
            'kode_kurikulum' => 'string',
            'rumpun' => 'string',
            'tgl_revisi' => 'date',
            'pengembangan_rps' => 'string',
            'nidn_pengembang_rps' => 'string',
            'nidn_ketua_kk' => 'string',
            'deskripsi' => 'string',
            'pustaka_utama' => 'string',
            'pengembangan_rps' => 'string',
            'pustaka_pendukung' => 'string',
            'media_pembelajaran_sw' => 'string',
            'media_pembelajaran_hw' => 'string',
            'biaya_per_sks' => 'numeric',
        ]);

        $data = new Matakuliah;
        $data->kode_mk = $request->input('kode_mk');
        $data->nama = $request->input('nama');
        $data->sks = $request->input('sks');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_jenis_mk = $request->input('kode_jenis_mk');
        $data->kode_kurikulum = $request->input('kode_kurikulum');
        $data->rumpun = $request->input('rumpun');
        $data->tgl_revisi = $request->input('tgl_revisi');
        $data->pengembangan_rps = $request->input('pengembangan_rps');
        $data->nidn_pengembang_rps = $request->input('nidn_pengembang_rps');
        $data->nidn_ketua_kk = $request->input('nidn_ketua_kk');
        $data->deskripsi = $request->input('deskripsi');
        $data->pustaka_utama = $request->input('pustaka_utama');
        $data->pustaka_pendukung = $request->input('pustaka_pendukung');
        $data->media_pembelajaran_sw = $request->input('media_pembelajaran_sw');
        $data->media_pembelajaran_hw = $request->input('media_pembelajaran_hw');
        $data->biaya_per_sks = $request->input('biaya_per_sks');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/matakuliah?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Matakuliah::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $kurikulum = Kurikulum::all();
        $jenis_matakuliah = JenisMatakuliah::all();

        return view('karyawan.matakuliah.info', compact('data', 'prodi', 'kurikulum','jenis_matakuliah'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Matakuliah::find($id);
        $prodi = Prodi::find($data->kode_prodi);
        $kurikulum = Kurikulum::all();
        $jenis_matakuliah = JenisMatakuliah::all();

        return view('karyawan.matakuliah.edit', compact('data', 'prodi', 'kurikulum', 'jenis_matakuliah'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_mk' => 'required|string|unique:matakuliah,kode_mk,'.$id.',kode_mk',
            'nama' => 'required|string',
            'sks' => 'numeric',
            'kode_jenis_mk' => 'string',
            'kode_kurikulum' => 'string',
            'rumpun' => 'string',
            'tgl_revisi' => 'date',
            'pengembangan_rps' => 'string',
            'nidn_pengembang_rps' => 'string',
            'nidn_ketua_kk' => 'string',
            'deskripsi' => 'string',
            'pustaka_utama' => 'string',
            'pengembangan_rps' => 'string',
            'pustaka_pendukung' => 'string',
            'media_pembelajaran_sw' => 'string',
            'media_pembelajaran_hw' => 'string',
            'biaya_per_sks' => 'numeric',
        ]);

        $data = Matakuliah::find($id);
        $data->kode_mk = $request->input('kode_mk');
        $data->nama = $request->input('nama');
        $data->sks = $request->input('sks');
        $data->kode_jenis_mk = $request->input('kode_jenis_mk');
        $data->kode_kurikulum = $request->input('kode_kurikulum');
        $data->rumpun = $request->input('rumpun');
        $data->tgl_revisi = $request->input('tgl_revisi');
        $data->pengembangan_rps = $request->input('pengembangan_rps');
        $data->nidn_pengembang_rps = $request->input('nidn_pengembang_rps');
        $data->nidn_ketua_kk = $request->input('nidn_ketua_kk');
        $data->deskripsi = $request->input('deskripsi');
        $data->pustaka_utama = $request->input('pustaka_utama');
        $data->pustaka_pendukung = $request->input('pustaka_pendukung');
        $data->media_pembelajaran_sw = $request->input('media_pembelajaran_sw');
        $data->media_pembelajaran_hw = $request->input('media_pembelajaran_hw');
        $data->biaya_per_sks = $request->input('biaya_per_sks');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/matakuliah?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             $hapus = Matakuliah::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
