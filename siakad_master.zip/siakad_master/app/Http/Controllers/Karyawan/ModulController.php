<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Modul as Modul;
use App\Model\ModulGroup as ModulGroup;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class ModulController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $modul = Modul::paginate('20');
        $modul_group = ModulGroup::all();

        return view('karyawan.modul.view', compact('modul', 'modul_group'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $modul = Modul::orWhere('id_modul', 'LIKE', '%'.$cari.'%')
                        ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $modul->appends(['cari' => $cari])->links();
        $modul_group = ModulGroup::all();
        
        return view('karyawan.modul.view', compact('modul', 'modul_group'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $modul_group = ModulGroup::all();

        return view('karyawan.modul.create', compact('modul_group'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_group_mdl' => 'required|numeric',
            'nama' => 'required|string',
            'icon' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
            'link' => 'nullable|string',
            'keterangan' => 'nullable|string',
        ]);

        $data = new Modul;
        $data->id_group_mdl = $request->input('id_group_mdl');
        $data->nama = $request->input('nama');
        $data->icon = $request->input('icon');
        $data->logo = checkFile($data->logo, $request->file('logo'), 'menu', 'modul_'.$data->nama);
        $data->link = $request->input('link');
        $data->keterangan = $request->input('keterangan');
        $data->aktif = '1';
        $data->save();

        return redirect('admin/modul')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Modul::find($id);
        $modul_group = ModulGroup::all();

        return view('karyawan.modul.edit', compact('data', 'modul_group'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_group_mdl' => 'required|numeric',
            'nama' => 'required|string',
            'icon' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
            'link' => 'nullable|string',
            'keterangan' => 'nullable|string',
            'aktif' => 'required|numeric',
        ]);

        $data = Modul::find($id);
        $data->id_group_mdl = $request->input('id_group_mdl');
        $data->nama = $request->input('nama');
        $data->icon = $request->input('icon');
        $data->logo = checkFile($data->logo, $request->file('logo'), 'menu', 'modul_'.$data->nama);
        $data->link = $request->input('link');
        $data->keterangan = $request->input('keterangan');
        $data->aktif = $request->input('aktif');
        $data->save();

        return redirect('admin/modul')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Modul::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


