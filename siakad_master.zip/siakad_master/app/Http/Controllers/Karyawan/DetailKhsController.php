<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\DetailKhs as DetailKhs;
use App\Model\Matakuliah as Matakuliah;
use App\Model\Khs as Khs;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class DetailKhsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $khs_detail = DetailKhs::paginate('20');
        $khs = Khs::all();
        $mata_kuliah= Matakuliah::all();

        return view('karyawan.khs_detail.view', compact('khs_detail', 'khs', 'mata_kuliah'));
    }

    /**
     * Display a searching data of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $khs_detail = DetailKhs::orWhere('id_detail_khs', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_khs', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $khs_detail->appends(['cari' => $cari])->links();
        
        return view('karyawan.khs_detail.view', compact('khs_detail'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $khs = Khs::all();
        $mata_kuliah = Matakuliah::all();

        return view('karyawan.khs_detail.create', compact('khs', 'mata_kuliah'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_detail_khs' => 'required|string|unique:detail_khs',
            'kode_khs' => 'required|string',
            'kode_mk' => 'required|string',
            'nilai' => 'string',
            'sks' => 'numeric',
            'nilai_mutu' => 'string',
            'status' => 'string',
            'ambil_ke' => 'string',
            'tahun' => 'numeric',
            'semester' => 'string',
            'pre_lulus' => 'string',
            'pre_tahun' => 'string',
            'keterangan' => 'string',
        ]);

        $data = new Detailkhs;
        $data->id_detail_khs = $request->input('id_detail_khs');
        $data->kode_khs = $request->input('kode_khs');
        $data->kode_mk = $request->input('kode_mk');
        $data->nilai = $request->input('nilai');
        $data->sks = $request->input('sks');
        $data->nilai_mutu = $request->input('nilai_mutu');
        $data->status = $request->input('status');
        $data->ambil_ke = $request->input('ambil_ke');
        $data->tahun = $request->input('tahun');
        $data->semester = $request->input('semester');
        $data->pre_lulus = $request->input('pre_lulus');
        $data->pre_tahun = $request->input('pre_tahun');
        $data->keterangan = $request->input('keterangan');
        $data->save();

        return redirect('admin/khs_detail')->with('success', 'create');
    }
    

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = DetailKhs::find($id);
        $khs = Khs::all();
        $mata_kuliah = Matakuliah::all();

        return view('karyawan.khs_detail.edit', compact('data', 'khs', 'mata_kuliah'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $validator = $this->validate($request, [
            'id_detail_khs' => 'required|string|unique:detail_khs,id_detail_khs,'.$id.',id_detail_khs',
            'kode_khs' => 'required|string',
            'kode_mk' => 'required|string',
            'nilai' => 'string',
            'sks' => 'numeric',
            'nilai_mutu' => 'string',
            'status' => 'string',
            'ambil_ke' => 'string',
            'tahun' => 'numeric',
            'semester' => 'string',
            'pre_lulus' => 'string',
            'pre_tahun' => 'string',
            'keterangan' => 'string',
        ]);

        $data = DetailKhs::find($id);
        $data->id_detail_khs = $request->input('id_detail_khs');
        $data->kode_khs = $request->input('kode_khs');
        $data->kode_mk = $request->input('kode_mk');
        $data->nilai = $request->input('nilai');
        $data->sks = $request->input('sks');
        $data->nilai_mutu = $request->input('nilai_mutu');
        $data->status = $request->input('status');
        $data->ambil_ke = $request->input('ambil_ke');
        $data->tahun = $request->input('tahun');
        $data->semester = $request->input('semester');
        $data->pre_lulus = $request->input('pre_lulus');
        $data->pre_tahun = $request->input('pre_tahun');
        $data->keterangan = $request->input('keterangan');
        $data->save();

        return redirect('admin/khs_detail')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = DetailKhs::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
