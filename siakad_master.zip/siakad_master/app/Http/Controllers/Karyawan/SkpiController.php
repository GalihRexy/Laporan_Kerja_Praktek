<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Skpi as Skpi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class SkpiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $skpi = Skpi::paginate('20');
        return view('karyawan.skpi.view', compact('skpi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $skpi = Skpi::orWhere('kode_skpi', 'LIKE', '%'.$cari.'%')
                        ->orWhere('deskripsi_skpi', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $skpi->appends(['cari' => $cari])->links();
        
        return view('karyawan.skpi.view', compact('skpi'));
    }

    public function create()
    {
        return view('karyawan.skpi.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_skpi' => 'required|string|unique:skpi',
            'deskripsi_skpi' => 'string',
        ]);

        $data = new Skpi;
        $data->kode_skpi = $request->input('kode_skpi');
        $data->deskripsi_skpi = $request->input('deskripsi_skpi');
        $data->save();

        return redirect('admin/skpi')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Skpi::find($id);

        return view('karyawan.skpi.edit', compact('data'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_skpi' => 'required|string|unique:skpi,kode_skpi,'.$id.',kode_skpi',
            'deskripsi_skpi' => 'string',
        ]);

        $data = Skpi::find($id);
        $data->kode_skpi = $request->input('kode_skpi');
        $data->deskripsi_skpi = $request->input('deskripsi_skpi');
        $data->save();

        return redirect('admin/skpi')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Skpi::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
