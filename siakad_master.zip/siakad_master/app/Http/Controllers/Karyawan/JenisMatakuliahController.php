<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\JenisMatakuliah;
use App\Model\Fakultas;
use App\Model\Prodi;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class JenisMatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::find($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::find($request->input('prodi')) : null;

        if ($pilih_prodi != null && $pilih_fakultas == null) {
            return redirect('/dosen');
        }
        if ($pilih_fakultas != null && $pilih_prodi == null) {
            $jenis_matakuliah = JenisMatakuliah::select('jenis_matakuliah.*', 'prodi.kode_prodi', 'fakultas.kode_fakultas')
                ->join('prodi', 'jenis_matakuliah.kode_prodi', '=', 'prodi.kode_prodi')
                ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                ->where('fakultas.kode_fakultas', '=', $pilih_fakultas->kode_fakultas)
                ->orderBy('prodi.nama', 'asc')
                ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } elseif ($pilih_prodi != null) {
            $jenis_matakuliah = JenisMatakuliah::where('kode_prodi', '=', $pilih_prodi->kode_prodi)
                ->orderBy('jenis_matakuliah.nama', 'asc')
                ->paginate('20');
            $prodi = Prodi::where('kode_fakultas', '=', $pilih_fakultas->kode_fakultas)->get();
        } else {
            $jenis_matakuliah = JenisMatakuliah::select('jenis_matakuliah.*', 'prodi.kode_prodi', 'fakultas.kode_fakultas')
                ->join('prodi', 'jenis_matakuliah.kode_prodi', '=', 'prodi.kode_prodi')
                ->join('fakultas', 'prodi.kode_fakultas', '=', 'fakultas.kode_fakultas')
                ->orderBy('fakultas.nama', 'asc')
                ->orderBy('prodi.nama', 'asc')
                ->orderBy('jenis_matakuliah.nama', 'asc')
                ->paginate('20');
            $prodi = Prodi::all();
        }
        $fakultas = Fakultas::all();

        return view('karyawan.jenis_matakuliah.view', compact('jenis_matakuliah', 'fakultas', 'prodi', 'pilih_fakultas', 'pilih_prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $pilih_fakultas = $request->input('fakultas') ? Fakultas::findOrFail($request->input('fakultas')) : null;
        $pilih_prodi = $request->input('prodi') ? Prodi::findOrFail($request->input('prodi')) : null;

        $cari = $request->get('cari');
        $jenis_matakuliah = JenisMatakuliah::orWhere('kode_jenis_mk', 'LIKE', '%' . $cari . '%')
            ->orWhere('nama', 'LIKE', '%' . $cari . '%')
            ->paginate('20');
        $jenis_matakuliah->appends(['cari' => $cari])->links();
        $fakultas = Fakultas::all();
        $prodi = Prodi::all();

        return view('karyawan.jenis_matakuliah.view', compact('jenis_matakuliah', 'fakultas', 'prodi'));
    }

    public function create($id)
    {
        $fakultas = Fakultas::all();
        $prodi = Prodi::findOrFail($id);

        return view('karyawan.jenis_matakuliah.create', compact('fakultas', 'prodi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_jenis_mk' => 'required|string|unique:jenis_matakuliah',
            'nama' => 'required|string',
            'wajib' => 'numeric',
            'kode_prodi' => 'string',
        ]);

        $data = new JenisMatakuliah;
        $data->kode_jenis_mk = $request->input('kode_jenis_mk');
        $data->nama = $request->input('nama');
        $data->wajib = $request->input('wajib');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->save();

        return redirect('admin/jenis_matakuliah?fakultas=' . $data->kode_fakultas . '&prodi=' . $prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = JenisMatakuliah::find($id);
        $prodi = Prodi::all();

        return view('karyawan.jenis_matakuliah.info', compact('data', 'prodi'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = JenisMatakuliah::find($id);
        $prodi = Prodi::find($data->kode_prodi);

        return view('karyawan.jenis_matakuliah.edit', compact('data', 'prodi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_jenis_mk' => 'required|string|unique:jenis_matakuliah,kode_jenis_mk,' . $id . ',kode_jenis_mk',
            'nama' => 'required|string',
            'wajib' => 'numeric',
        ]);

        $data = JenisMatakuliah::find($id);
        $data->kode_jenis_mk = $request->input('kode_jenis_mk');
        $data->nama = $request->input('nama');
        $data->wajib = $request->input('wajib');
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/jenis_matakuliah?fakultas=' . $prodi->kode_fakultas . '&prodi=' . $prodi->kode_prodi)->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = JenisMatakuliah::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


