<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Assessment as Assessment;
use App\Model\LearningOutcomes as LearningOutcomes;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class AssessmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $assessment = Assessment::paginate('20');
        $learning_outcomes = LearningOutcomes::all();
        return view('karyawan.assessment.view', compact('assessment', 'learning_outcomes'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
     public function search(Request $request)
    {
        $cari = $request->get('cari');
        $assessment = Assessment::orWhere('id_assessment', 'LIKE', '%'.$cari.'%')
                        ->orWhere('id_lo', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $assessment->appends(['cari' => $cari])->links();

        $learning_outcomes = LearningOutcomes::all();
        
        return view('karyawan.assessment.view', compact('assessment', 'learning_outcomes'));
    }

    public function create()
    {
        $learning_outcomes = LearningOutcomes::all();

        return view('karyawan.assessment.create', compact('learning_outcomes'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'id_assessment' => 'required|string|unique:assessment',
            'id_lo' => 'string',
            'metode' => 'string',
            'bobot' => 'string',
            'kriteria_nilai' => 'string',
            'waktu_pelaksanaan' => 'string',
            'target_pencapaian' => 'string',
            'base_line' => 'string',
        ]);

        $data = new Assessment;
        $data->id_assessment = $request->input('id_assessment');
        $data->id_lo = $request->input(
            'id_lo');
        $data->metode = $request->input('metode');
        $data->bobot = $request->input('bobot');
        $data->kriteria_nilai = $request->input('kriteria_nilai');
        $data->waktu_pelaksanaan = $request->input('waktu_pelaksanaan');
        $data->target_pencapaian = $request->input('target_pencapaian');
        $data->base_line = $request->input('base_line');
        $data->save();

        return redirect('admin/assessment')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Assessment::find($id);
        $learning_outcomes = LearningOutcomes::all();

        return view('karyawan.assessment.edit', compact('data', 'learning_outcomes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'id_assessment' => 'required|string|unique:assessment,id_assessment,'.$id.',id_assessment',
            'id_lo' => 'string',
            'metode' => 'string',
            'bobot' => 'string',
            'kriteria_nilai' => 'string',
            'waktu_pelaksanaan' => 'string',
            'target_pencapaian' => 'string',
            'base_line' => 'string',
        ]);

        $data = Assessment::find($id);
        $data->id_assessment = $request->input('id_assessment');
        $data->id_lo = $request->input(
            'id_lo');
        $data->metode = $request->input('metode');
        $data->bobot = $request->input('bobot');
        $data->kriteria_nilai = $request->input('kriteria_nilai');
        $data->waktu_pelaksanaan = $request->input('waktu_pelaksanaan');
        $data->target_pencapaian = $request->input('target_pencapaian');
        $data->base_line = $request->input('base_line');
        $data->save();

        return redirect('admin/assessment')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = Assessment::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}


