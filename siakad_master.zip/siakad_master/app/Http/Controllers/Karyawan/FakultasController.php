<?php

namespace App\Http\Controllers\Karyawan;

use App\Model\Fakultas;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller as Controller;

class FakultasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $fakultas = Fakultas::paginate('20');

        return view('karyawan.fakultas.view', compact('fakultas'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $fakultas = Fakultas::orWhere('kode_fakultas', 'LIKE', '%'.$cari.'%')
                              ->orWhere('nama', 'LIKE', '%'.$cari.'%')
                              ->paginate('20');
        $fakultas->appends(['cari' => $cari])->links();
        
        return view('karyawan.fakultas.view', compact('fakultas'));                      
    }

    public function create()
    {
        return view('karyawan.fakultas.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'kode_fakultas' => 'required|string|unique:fakultas',
            'nama' => 'required|string',
            'alamat' => 'string',
            'kota' => 'string',
            'provinsi' => 'string',
            'kodepos' => 'nullable|numeric',
            'telepon' => 'nullable|string|unique:fakultas',
            'fax' => 'nullable|string|unique:fakultas',
            'email' => 'nullable|string|unique:fakultas',
            'website' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = new Fakultas;
        $data->kode_fakultas = $request->input('kode_fakultas');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->telepon = $request->input('telepon');
        $data->fax = $request->input('fax');
        $data->email = $request->input('email');
        $data->website = $request->input('website');
        $data->logo = checkFile($data->logo, $request->file('logo'), 'logo', $data->kode_fakultas);
        $data->save();

        return redirect('admin/fakultas')->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $data = Fakultas::find($id);

        return view('karyawan.fakultas.info', compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = Fakultas::find($id);

        return view('karyawan.fakultas.edit', compact('data'));
    }

    public function aktif(Request $request, $id)
    {
        $data = Fakultas::find($id);
        $data->aktif = $request->input('aktif');
        $data->save();

        return redirect()->back()->with('success', 'operation');
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_fakultas' => 'required|string|unique:fakultas,kode_fakultas,'.$id.',kode_fakultas',
            'nama' => 'required|string',
            'alamat' => 'string',
            'kota' => 'string',
            'provinsi' => 'string',
            'kodepos' => 'nullable|numeric',
            'telepon' => 'nullable|string|unique:fakultas,telepon,'.$id.',kode_fakultas',
            'fax' => 'nullable|string|unique:fakultas,fax,'.$id.',kode_fakultas',
            'email' => 'nullable|string|unique:fakultas,email,'.$id.',kode_fakultas',
            'website' => 'nullable|string',
            'logo' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = Fakultas::find($id);
        $data->kode_fakultas = $request->input('kode_fakultas');
        $data->nama = $request->input('nama');
        $data->alamat = $request->input('alamat');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->telepon = $request->input('telepon');
        $data->fax = $request->input('fax');
        $data->email = $request->input('email');
        $data->website = $request->input('website');
        $data->logo = checkFile($data->logo, $request->file('logo'), 'logo', $data->id_fakultas);
        $data->save();

        return redirect('admin/fakultas')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $hapus = Fakultas::find($id);
        $logo = $hapus->logo;
        try {
            $hapus->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }
        $imgDel = deleteFile($logo, 'logo');

        return redirect()->back()->with('success', 'delete');
    }
}
