<?php

namespace App\Http\Controllers\Dosen;

use App\Model\StudyOutcomes as StudyOutcomes;
use App\Model\Prodi as Prodi;
use App\Model\Skpi as Skpi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller as Controller;

class StudyOutcomesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $study_outcomes = StudyOutcomes::paginate('20');
        $prodi = Prodi::all();
        return view('dosen.study_outcomes.view', compact('study_outcomes', 'prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function search(Request $request)
    {
        $cari = $request->get('cari');
        $study_outcomes = StudyOutcomes::orWhere('kode_so', 'LIKE', '%'.$cari.'%')
                        ->orWhere('kode_prodi', 'LIKE', '%'.$cari.'%')
                        ->paginate('20');
        $study_outcomes->appends(['cari' => $cari])->links();
        
        return view('dosen.study_outcomes.view', compact('study_outcomes'));
    }

    public function create()
    {
        $prodi = Prodi::all();
        $skpi = Skpi::all();

        return view('dosen.study_outcomes.create', compact('prodi', 'skpi'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validate = $this->validate($request, [
            'kode_so' => 'required|string|unique:study_outcomes',
            'kode_prodi' => 'string',
            'kode_skpi' => 'string',
            'deskripsi_so' => 'string',
        ]);

        $data = new StudyOutcomes;
        $data->kode_so = $request->input('kode_so');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_skpi = $request->input('kode_skpi');
        $data->deskripsi_so = $request->input('deskripsi_so');
        $data->save();

        return redirect('dosen/study_outcomes')->with('success', 'create');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data = StudyOutcomes::find($id);
        $prodi = Prodi::all();
        $skpi = Skpi::all();

        return view('dosen.study_outcomes.edit', compact('data', 'prodi', 'skpi'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validator = $this->validate($request, [
            'kode_so' => 'required|string|unique:study_outcomes,kode_so,'.$id.',kode_so',
            'kode_prodi' => 'string',
            'kode_skpi' => 'string',
            'deskripsi_so' => 'string',
        ]);

        $data = StudyOutcomes::find($id);
        $data->kode_so = $request->input('kode_so');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->kode_skpi = $request->input('kode_skpi');
        $data->deskripsi_so = $request->input('deskripsi_so');
        $data->save();

        return redirect('dosen/study_outcomes')->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
            $hapus = StudyOutcomes::find($id)->delete();
        } catch (\Illuminate\Database\QueryException $e) {
            if ($e->getCode() == "23000") {
                $error = "database";
            } else {
                $error = "unknown";
            }
            return redirect()->back()->with('error', $error);
        }

        return redirect()->back()->with('success', 'delete');
    }
}
