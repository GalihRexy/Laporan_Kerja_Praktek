<?php

namespace App\Http\Controllers\Dosen;

use App\Model\Dosen as Dosen;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use App\Model\Jabatan as Jabatan;
use App\Model\KlasifikasiDosen as KlasifikasiDosen;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller as Controller;

class DosenController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function create($id)
    {
        $prodi = Prodi::find($id);
        $jabatan = Jabatan::all();
        $klasifikasi_dosen = KlasifikasiDosen::all();

        return view('karyawan.dosen.create', compact('prodi', 'jabatan', 'klasifikasi_dosen'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validator = $this->validate($request, [
            'nidn' => 'required|string|unique:dosen',
            'nip_pns' => 'nullable|string',
            'nik' => 'required|string',
            'nama' => 'required|string',
            'tempat_lahir' => 'required|string',
            'tgl_lahir' => 'required|date',
            'jenis_kelamin' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'kodepos' => 'nullable|string',
            'provinsi' => 'string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|string',
            'email' => 'nullable|string',
            'gelar' => 'nullable|string',
            'jenjang' => 'nullable|string',
            'keilmuan' => 'nullable|string',
            'lulusan_pt' => 'nullable|string',
            'kode_prodi' => 'string',
            'institusi_induk' => 'nullable|string',
            'id_jabatan' => 'numeric',
            'id_klasifikasi_dosen' => 'numeric',
            'no_rek' => 'nullable|numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);

        $data = new Dosen;
        $data->nidn = $request->input('nidn');
        $data->username = $request->input('nidn');
        $data->password = bcrypt($request->input('nidn'));
        $data->nip_pns = $request->input('nip_pns');
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->tempat_lahir = $request->input('tempat_lahir');
        $data->tgl_lahir = $request->input('tgl_lahir');
        $data->jenis_kelamin = $request->input('jenis_kelamin');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->gelar = $request->input('gelar');
        $data->jenjang = $request->input('jenjang');
        $data->keilmuan = $request->input('keilmuan');
        $data->lulusan_pt = $request->input('lulusan_pt');
        $data->kode_prodi = $request->input('kode_prodi');
        $data->institusi_induk = $request->input('institusi_induk');
        $data->id_jabatan = $request->input('id_jabatan');
        $data->id_klasifikasi_dosen = $request->input('id_klasifikasi_dosen');
        $data->no_rek = $request->input('no_rek');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'dosen');
        $data->aktif = '1';
        $data->save();

        $prodi = Prodi::find($data->kode_prodi);

        return redirect('admin/dosen?fakultas='.$prodi->kode_fakultas.'&prodi='.$prodi->kode_prodi)->with('success', 'create');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        $auth = Auth::user()->nidn;
        $dosen = Dosen::find($auth);


        return view('dosen.layouts.profile', compact('dosen'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
 
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $validator = $this->validate($request, [
            'nip_pns' => 'nullable|string',
            'nik' => 'required|string',
            'nama' => 'required|string',
            'tempat_lahir' => 'required|string',
            'tgl_lahir' => 'required|date',
            'jenis_kelamin' => 'required|string',
            'alamat' => 'nullable|string',
            'desa' => 'string',
            'kecamatan' => 'string',
            'kota' => 'string',
            'kodepos' => 'nullable|string',
            'provinsi' => 'string',
            'wni' => 'required|numeric',
            'handphone' => 'nullable|string',
            'email' => 'nullable|string',
            'gelar' => 'nullable|string',
            'jenjang' => 'nullable|string',
            'keilmuan' => 'nullable|string',
            'lulusan_pt' => 'nullable|string',
            'institusi_induk' => 'nullable|string',
            'no_rek' => 'nullable|numeric',
            'foto' => 'nullable|image|mimes:jpeg,png,jpg,gif,svg|max:2000',
        ]);
        
        $auth = Auth::user()->nidn;
        $data = Dosen::find($auth);
        $data->nip_pns = $request->input('nip_pns');
        $data->nik = $request->input('nik');
        $data->nama = $request->input('nama');
        $data->tempat_lahir = $request->input('tempat_lahir');
        $data->tgl_lahir = $request->input('tgl_lahir');
        $data->jenis_kelamin = $request->input('jenis_kelamin');
        $data->alamat = $request->input('alamat');
        $data->desa = $request->input('desa');
        $data->kecamatan = $request->input('kecamatan');
        $data->kota = $request->input('kota');
        $data->kodepos = $request->input('kodepos');
        $data->provinsi = $request->input('provinsi');
        $data->wni = $request->input('wni');
        $data->handphone = $request->input('handphone');
        $data->email = $request->input('email');
        $data->gelar = $request->input('gelar');
        $data->jenjang = $request->input('jenjang');
        $data->keilmuan = $request->input('keilmuan');
        $data->lulusan_pt = $request->input('lulusan_pt');
        $data->institusi_induk = $request->input('institusi_induk');
        $data->no_rek = $request->input('no_rek');
        $data->foto = checkFile($data->foto, $request->file('foto'), 'foto', 'dosen');
        $data->save();


        return redirect()->back()->with('success', 'edit');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {   

    }
}


