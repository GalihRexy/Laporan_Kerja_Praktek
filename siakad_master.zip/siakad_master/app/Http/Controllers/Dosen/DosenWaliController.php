<?php

namespace App\Http\Controllers\dosen;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Dosen;
use App\Model\DosenWali;
use App\Model\Mahasiswa;
use App\Model\TahunAkademik;
use App\Model\DetailKrs;
use App\Model\Krs;
use Auth;

class DosenWaliController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $dosen = Auth::user()->nidn;
        // $dosen_wali = DosenWali::select([
        //     'dosen_wali.*',
        // ])->join('krs', 'dosen_wali.nim' ,'=', 'krs.nim')
        //   ->where('nidn', $dosen)
        //   ->where('krs.status', 0)
        //   ->get();
        $krs = Krs::select([
            'krs.*',
        ])->join('dosen_wali', 'krs.nim', '=', 'dosen_wali.nim')
            ->where('dosen_wali.nidn', $dosen)
            ->get();

        return view('dosen.dosen_wali.list', compact('krs'));
    }

    /**
     * Display a listing of the detail krs.
     *
     * @return \Illuminate\Http\Response
     */
    public function detail_krs($nim, $id)
    {
        $krs = Krs::where('id_krs', $id)->firstOrFail();
        $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->get();

        return view('dosen.dosen_wali.detailkrs', compact('detail_krs', 'krs'));
    }

    //approved matakuliah
    public function approvedMatakuliah(Request $request, $nim, $id)
    {
        $krs = Krs::where('id_krs', $id)->firstOrFail();

        for ($i = 0; $i < count($request->matakuliah); $i++) {
            $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)
                ->where('kode_mk', $request->matakuliah[$i])
                ->first();

            $detail_krs->update([
                'status' => 1
            ]);

        }

        return redirect()->back()->withSuccess('create');
    }

    //approved krs
    public function approved($nim, $id)
    {
        $krs = Krs::where('id_krs', $id)->first();
        $krs->update([
            'status' => 1
        ]);

        return redirect()->back()->withSuccess('create');
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
