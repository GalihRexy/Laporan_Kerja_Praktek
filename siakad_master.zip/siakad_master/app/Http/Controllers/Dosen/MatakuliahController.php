<?php

namespace App\Http\Controllers\dosen;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Dosen;
use App\Model\DetailKrs;
use App\Model\Krs;
use App\Model\JadwalKuliah;
use App\Model\Matakuliah;
use App\Model\LearningOutcomes;
use App\Model\Mahasiswa;
use App\Model\Assessment;
use App\Model\Nilai;
use Auth;

class MatakuliahController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function home()
    {
        $dosen = Auth::user()->nidn;
        $jadwal_kuliah = JadwalKuliah::where('nidn', $dosen)->get();

        return view('dosen.matakuliah.home', compact('jadwal_kuliah'));
    }

    public function index($id)
    {
        $detail_krs = DetailKrs::where('kode_mk', $id)->get();
        $matakuliah = Matakuliah::find($id);

        return view('dosen.matakuliah.list', compact('detail_krs', 'matakuliah'));
    }

    public function nilai(Request $request, $id)
    {   
        $pilih_lo = $request->lo ? LearningOutcomes::find($request->lo) :null;
        $pilih_assessment = $request->assessment ? Assessment::find($request->assessment) :null;

        if($pilih_lo != null && $pilih_assessment == null){   
            $nilai = Nilai::select('nilai.*', 'assessment.metode', 'learning_outcomes.id_lo', 'matakuliah.kode_mk')
                            ->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
                            ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
                            ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
                            ->where('learning_outcomes.kode_mk', $id)
                            ->where('learning_outcomes.id_lo', $request->lo)
                            ->get();

            $assessment = Assessment::where('id_lo', $request->lo)->get();                
        }elseif($pilih_lo == null && $pilih_assessment != null){
            return redirect('dosen/matakuliah/'.$id.'nilai');
        }elseif($pilih_assessment != null){
            $nilai = Nilai::select('nilai.*', 'assessment.metode', 'learning_outcomes.id_lo')
                            ->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
                            ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
                            ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
                            ->where('learning_outcomes.kode_mk', $id)
                            ->where('assessment.id_assessment', $request->assessment)
                            ->get();

            $assessment = Assessment::where('id_lo', $request->lo)->get();                     
        }
        else{
            $nilai = Nilai::select('nilai.*', 'assessment.metode', 'learning_outcomes.id_lo')
                      ->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
                      ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
                      ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
                      ->where('learning_outcomes.kode_mk', $id)
                      ->get();
        }

        $matakuliah = Matakuliah::find($id);
        $detail_krs = DetailKrs::where('kode_mk', $id)->get();
        $learning_outcomes = LearningOutcomes::where('kode_mk', $id)->select('id_lo', 'deskripsi_lo', 'total_bobot','kode_mk')->get();

        return view('dosen.matakuliah.nilai', compact('nilai', 'matakuliah', 'learning_outcomes', 'assessment', 'pilih_lo', 'pilih_assessment', 'detail_krs'));
    }

    public function detailNilai($kode_mk, $nim)
    {
        $matakuliah = Matakuliah::find($kode_mk);
        $learning_outcomes = LearningOutcomes::where('kode_mk', $kode_mk)->select('id_lo', 'deskripsi_lo', 'total_bobot','kode_mk')->get();

        $mahasiswa = Mahasiswa::find($nim);
        $nilai = Nilai::select([
                'nilai.*',
                'assessment.id_assessment',
                'assessment.id_lo',
        ])->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
          ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
          ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
          ->orderBy('assessment.id_lo')->where('nim', $nim)->where('learning_outcomes.kode_mk', $kode_mk)->get();

        return view('dosen.matakuliah.detail', compact('learning_outcomes', 'mahasiswa', 'matakuliah', 'nilai'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function formNilai($kode_mk, $nim)
    {
        $matakuliah = Matakuliah::find($kode_mk);
        $learning_outcomes = LearningOutcomes::where('kode_mk', $kode_mk)->select('id_lo', 'deskripsi_lo', 'total_bobot','kode_mk')->get();

        $mahasiswa = Mahasiswa::find($nim);
        $nilai = Nilai::select([
                'nilai.*',
                'assessment.id_assessment',
                'assessment.id_lo',
        ])->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
          ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
          ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
          ->orderBy('assessment.id_lo')->where('nim', $nim)->where('learning_outcomes.kode_mk', $kode_mk)->get();

        return view('dosen.matakuliah.nilai', compact('learning_outcomes', 'mahasiswa', 'matakuliah', 'nilai'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */

    public function storeNilai(Request $request, $id)
    {
        $this->validate($request, [
            'id_lo' => 'required',
            'id_assessment' => 'required',
            'mahasiswa' => 'required|string',
            'nilai' => 'required|integer'
        ]);

        $assessment = Assessment::find($request->id_assessment);

        $nilai = Nilai::create([
            'id_assessment' => $request->id_assessment,
            'nim' => $request->mahasiswa,
            'nilai' => $request->nilai,
            'tgl_assessment' => '2019-01-10',
        ]);


        // jumlah nilai
        $this->storeSumNilai($request->mahasiswa, $id);
        

        return redirect()->back()->withSuccess('create');

    }

    public function storeSumNilai($nim, $kode_mk)
    {
        $nilai = Nilai::select([
            'nilai.*',
            'assessment.id_assessment',
            'assessment.id_lo',
        ])->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
          ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
          ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
          ->orderBy('assessment.id_lo')->where('nim', $nim)->where('learning_outcomes.kode_mk', $kode_mk)->get();
        
        $jumlah = 0;
        foreach($nilai as $n){
            $hasil = $n->nilai*$n->assessment->bobot;
            $jumlah = $jumlah + $hasil;
        }

        $krs = Krs::where('nim', $nim)->firstOrFail();
        $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->where('kode_mk', $kode_mk)->firstOrFail();
        $detail_krs->nilai = $jumlah;
        $detail_krs->save();
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function formEditNilai(Request $request, $kode_mk, $nim, $id)
    {
        $matakuliah = Matakuliah::find($kode_mk);
        $learning_outcomes = LearningOutcomes::where('kode_mk', $kode_mk)->select('id_lo', 'deskripsi_lo', 'total_bobot','kode_mk')->get();

        $nilai = Nilai::select([
            'nilai.*',
            'assessment.id_assessment',
            'assessment.id_lo',
        ])->join('assessment', 'nilai.id_assessment', '=', 'assessment.id_assessment')
          ->join('learning_outcomes', 'assessment.id_lo', '=', 'learning_outcomes.id_lo')
          ->join('matakuliah', 'learning_outcomes.kode_mk', '=', 'matakuliah.kode_mk')
          ->orderBy('assessment.id_lo')->where('id_nilai', $id)->firstOrFail();

        return view('dosen.matakuliah.edit', compact('nilai', 'matakuliah', 'learning_outcomes'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function storeEditNilai(Request $request, $kode_mk, $nim, $id)
    {
        $this->validate($request, [
            'nilai' => 'required'
        ]);

        $nilai = Nilai::find($id);

        $nilai->update([
            'nilai' => $request->nilai,
        ]);

        // hitung jumlah nilai
        $this->storeSumNilai($nim, $kode_mk);
        
        return redirect('dosen/matakuliah/'.$kode_mk)->withSuccess('edit');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    
    public function profileMahasiswa($nim)
    {
        $mahasiswa = Mahasiswa::find($nim);

        return view('dosen.matakuliah.profile', compact('mahasiswa'));
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function deleteNilai(Request $request, $kode_mk, $nim, $id)
    {
        $nilai = Nilai::where('id_nilai', $id)
                      ->where('nim', $nim)
                      ->firstOrFail();
        $nilai->delete(); 

        $this->storeSumNilai($nim, $kode_mk);
    
        return redirect()->back()->withSuccess('delete');
    }

}
