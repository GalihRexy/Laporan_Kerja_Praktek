<?php

namespace App\Http\Controllers\Mahasiswa;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Model\Matakuliah;
use App\Model\Mahasiswa;
use App\Model\Krs;
use App\Model\DetailKrs;
use App\Model\MatakuliahKurikulum;
use App\Model\Khs;
use App\Model\DetailKhs;
use App\Model\TahunAkademik;
use Auth;

class KrsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function isi()
    {
        $auth = Auth::user()->nim;
        $tahun_akademik = TahunAkademik::orderBy('kode_thn_akademik', 'decs')->first();
        $cek_krs = Krs::where('kode_thn_akademik', $tahun_akademik->kode_thn_akademik)->get();
        //Cek apakah kode thn akademik terbaru sudah ada pada tabel krs
        if (count($cek_krs) == 1) {
            return redirect('\mahasiswa\home');
        }

        
    }

    public function index()
    {
        $auth = Auth::user()->nim;
        $krs = Krs::where('nim', $auth)->where('status', 1)->get();

        if (count($krs) == 0) {
            $cek = null;
        } else {
            $krs = Krs::where('nim', $auth)->where('status', 1)->FirstOrFail();
            $cek = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 1)->get();
        }

        if (count($cek) == 0) {
            return view('mahasiswa.krs.index', compact('cek'));
        } else {
            $krs = Krs::where('nim', $auth)->FirstOrFail();
            $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 1)->get();
            $i = 0;
            $a = 0;
            $b = 0;
            $c = 0;
            $d = 0;
            $e = 0;
            $f = 0;
            $g = 0;
            $h = 0;
            foreach ($detail_krs as $detail) {
                $data1[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 1)->First();
                if (count($data1[$i]) == 1) {
                    $matakuliah_semester1[$a] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 1)->First();
                    $a = $a + 1;
                }

                $data2[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 2)->First();
                if (count($data2[$i]) == 1) {
                    $matakuliah_semester2[$b] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 2)->First();
                    $b = $b + 1;
                }
                if (!isset($matakuliah_semester2)) {
                    $matakuliah_semester2 = null;
                }

                $data3[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 3)->First();
                if (count($data3[$i]) == 1) {
                    $matakuliah_semester3[$c] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 3)->First();
                    $c = $c + 1;
                }
                if (!isset($matakuliah_semester3)) {
                    $matakuliah_semester3 = null;
                }

                $data4[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 4)->First();
                if (count($data4[$i]) == 1) {
                    $matakuliah_semester4[$d] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 4)->First();
                    $d = $d + 1;
                }
                if (!isset($matakuliah_semester4)) {
                    $matakuliah_semester4 = null;
                }

                $data5[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 5)->First();
                if (count($data5[$i]) == 1) {
                    $matakuliah_semester5[$e] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 5)->First();
                    $e = $e + 1;
                }
                if (!isset($matakuliah_semester5)) {
                    $matakuliah_semester5 = null;
                }

                $data6[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 6)->First();
                if (count($data6[$i]) == 1) {
                    $matakuliah_semester6[$f] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 6)->First();
                    $f = $f + 1;
                }
                if (!isset($matakuliah_semester6)) {
                    $matakuliah_semester6 = null;
                }

                $data7[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 7)->First();
                if (count($data7[$i]) == 1) {
                    $matakuliah_semester7[$g] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 7)->First();
                    $g = $g + 1;
                }
                if (!isset($matakuliah_semester7)) {
                    $matakuliah_semester7 = null;
                }

                $data8[$i] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 8)->First();
                if (count($data8[$i]) == 1) {
                    $matakuliah_semester8[$h] = MatakuliahKurikulum::where('kode_mk', $detail->kode_mk)->where('semester', 8)->First();
                    $h = $h + 1;
                }
                if (!isset($matakuliah_semester8)) {
                    $matakuliah_semester8 = null;
                }

                $i = $i + 1;
            }


            return view('mahasiswa.krs.index', compact('matakuliah_semester1', 'matakuliah_semester2', 'matakuliah_semester3', 'matakuliah_semester4', 'matakuliah_semester5', 'matakuliah_semester6', 'matakuliah_semester7', 'matakuliah_semester8', 'cek'));
        }
    }


    public function n_approve()
    {
        $auth = Auth::user()->nim;
        $krs = Krs::where('nim', $auth)->First();
        if (count($krs) == 0) {
            $cek = null;
        } else {
            $krs = Krs::where('nim', $auth)->where('status', 1)->FirstOrFail();
            $cek = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 0)->get();
        }

        if (count($cek) == 0) {
            return view('mahasiswa.krs.n_approve', compact('cek'));
        } else {
            $krs = Krs::where('nim', $auth)->FirstOrFail();
            $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 0)->get();
            $i = 0;
            foreach ($detail_krs as $detail) {
                $matakuliah[$i] = Matakuliah::where('kode_mk', $detail->kode_mk)->FirstOrFail();
                $i = $i + 1;
            }


            return view('mahasiswa.krs.n_approve', compact('matakuliah', 'cek'));
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function create(request $request)
    {
        $i = 0;
        if ($request->has('cari')) {
            $matakuliah = Matakuliah::where('nama', 'LIKE', '%' . $request->cari . '%')->get();
            foreach ($matakuliah as $mk) {
                $matakuliah_kurikulum[$i] = MatakuliahKurikulum::where('kode_mk', $mk->kode_mk)->First();
            }
        } else {
            $matakuliah_kurikulum = MatakuliahKurikulum::all();
        }

        return view('mahasiswa.krs.create', compact('matakuliah_kurikulum'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $auth = Auth::user()->nim;
        $data = Krs::where('nim', $auth)->First();

        //KRS
        if (count($data) == 0) {
            $krs = new Krs;
            $krs->kode_thn_akademik = '1';
            $krs->nim = $auth;
            $krs->tgl_perwalian = '2019-08-23';
            $krs->total_sks = 1;
            $krs->total_biaya = 2000;
            $krs->status = 0;
            $krs->save();
        }

        $data = Krs::where('nim', $auth)->FirstOrFail();

        //Detail KRS
        for ($i = 0; $i < count($request->kode_mk); $i++) {

            $detail_krs = new DetailKrs;
            $detail_krs->id_krs = $data->id_krs;
            $detail_krs->kode_jadwal_kuliah = '1';
            $detail_krs->nilai = 0;
            $detail_krs->kode_mk = $request->kode_mk[$i];
            $detail_krs->save();
        }

        $total_sks = 0;
        $total_biaya = 0;
        $detail_krs = DetailKrs::where('id_krs', $data->id_krs)->get();
        foreach ($detail_krs as $detail) {
            $matakuliah = Matakuliah::where('kode_mk', $detail->kode_mk)->FirstOrFail();
            $total_sks = $total_sks + $matakuliah->sks;
            $total_biaya = $total_biaya + $matakuliah->biaya_per_sks;
        }

        $krs = Krs::where('nim', $auth)->FirstOrFail();
        $krs->total_sks = $total_sks;
        $krs->total_biaya = $total_biaya;
        $krs->update();

        //Table KHS
        $matakuliah = Matakuliah::all();
        $tahun = getdate();
        $total_sks = 0;
        foreach ($matakuliah as $makul) {
            $total_sks = $total_sks + $makul->sks;
        }

        $khs = Khs::where('nim', $auth)->first();
        if (count($khs) == 0) {
            $khs = new Khs;
            $khs->kode_khs = $auth . '_khs';
            $khs->nim = $auth;
            $khs->tahun_semester = $tahun['year'];
            $khs->total_sks_sdh_diambil = $krs->total_sks;
            $khs->total_sks_blm_diambil = $total_sks - $krs->total_sks;
            $khs->tmt = $tahun['year'];
            $khs->tst = $tahun['year'] + 4;
            $khs->save();
        }



        return redirect('/mahasiswa/krs/n_approve');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(request $request)
    {
        if ($request->has('cari')) {
            $mk = Matakuliah::where('nama', 'LIKE', '%' . $request->cari . '%')->get();
        } else {
            $mk = Matakuliah::all();
        }



        $matakuliah_kurikulum = MatakuliahKurikulum::all();



        return view('mahasiswa.krs.edit', compact('matakuliah_kurikulum'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {

        $auth = Auth::user()->nim;
        $krs = Krs::where('nim', $auth)->FirstOrFail();
        $hapus = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 0)->get();
        foreach ($hapus as $hap) {
            $hap->delete();
        }

        for ($i = 0; $i < count($request->kode_mk); $i++) {

            $detail_krs = new DetailKrs;
            $detail_krs->id_krs = $krs->id_krs;
            $detail_krs->kode_jadwal_kuliah = '1';
            $detail_krs->nilai = 0;
            $detail_krs->kode_mk = $request->kode_mk[$i];
            $detail_krs->save();
        }

        $total_sks = 0;
        $total_biaya = 0;
        $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->get();
        foreach ($detail_krs as $detail) {
            $matakuliah = Matakuliah::where('kode_mk', $detail->kode_mk)->FirstOrFail();
            $total_sks = $total_sks + $matakuliah->sks;
            $total_biaya = $total_biaya + $matakuliah->biaya_per_sks;
        }

        $krs = Krs::where('nim', $auth)->FirstOrFail();
        $krs->total_sks = $total_sks;
        $krs->total_biaya = $total_biaya;
        $krs->update();

        return redirect('/mahasiswa/krs/n_approve');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function hapus()
    {
        $auth = Auth::user()->nim;
        $krs = Krs::where('nim', $auth)->FirstOrFail();
        $hapus = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 0)->get();
        $total_sks = 0;
        $total_biaya = 0;
        foreach ($hapus as $hap) {
            $matakuliah = Matakuliah::where('kode_mk', $hap->kode_mk)->FirstOrFail();
            $total_sks = $total_sks + $matakuliah->sks;
            $total_biaya = $total_biaya + $matakuliah->biaya_per_sks;
            $hap->delete();
        }
        $krs->total_sks = $krs->total_sks - $total_sks;
        $krs->total_biaya = $krs->total_biaya - $total_biaya;
        $krs->update();

        $cek = null;

        return view('mahasiswa.krs.n_approve', compact('cek'));
    }

    public function filter(request $request)
    {

        $matakuliah_kurikulum = MatakuliahKurikulum::where('ganjil', $request->gnjl)->get();

        return view('mahasiswa.krs.create', compact('matakuliah_kurikulum'));
    }

    public function filter_edit(request $request)
    {

        $matakuliah_kurikulum = MatakuliahKurikulum::where('ganjil', $request->gnjl)->get();

        return view('mahasiswa.krs.edit', compact('matakuliah_kurikulum'));
    }

    public function export()
    {
        echo 'Berhasil';
    }

    public function approve(request $request)
    {
        $auth = Auth::user()->nim;
        $krs = Krs::where('nim', $auth)->FirstOrFail();

        for ($i = 0; $i < count($request->kode_mk); $i++) {
            $detail_krs = DetailKrs::where('kode_mk', $request->kode_mk[$i])->FirstOrFail();
            $detail_krs->status = 1;
            $detail_krs->update();
        }

        $khs = Khs::where('nim', $auth)->FirstOrFail();

        for ($i = 0; $i < count($request->kode_mk); $i++) {
            $matakuliah_kurikulum = MatakuliahKurikulum::where('kode_mk', $request->kode_mk[$i])->FirstOrFail();

            $detail_khs = new DetailKhs;
            $detail_khs->kode_khs = $khs->kode_khs;
            $detail_khs->kode_mk = $request->kode_mk[$i];
            $detail_khs->nilai = 0;
            $detail_khs->sks = 0;
            $detail_khs->nilai_mutu = 0;
            $detail_khs->status = 1;
            $detail_khs->ambil_ke = $i;
            $detail_khs->tahun = 2019;
            $detail_khs->semester = $matakuliah_kurikulum->semester;
            $detail_khs->pre_lulus = 2019;
            $detail_khs->pre_tahun = 2019;
            $detail_khs->keterangan = 'reguler';
            $detail_khs->save();
        }


        if (count($detail_krs) == 1) {
            $cek = 1;
        } else {
            $cek = 0;
        }


        return redirect('/mahasiswa/krs');
    }

    public function page()
    {
        return view('/mahasiswa.krs.page');
    }

    public function repire(){
        return view('/mahasiswa.krs.repire');
    }
}
