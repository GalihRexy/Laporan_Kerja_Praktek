<?php

namespace App\Http\Controllers\Mahasiswa;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use App\Http\Controllers\Controller;
use App\Model\Mahasiswa;
use App\Model\Krs;
use App\Model\DetailKrs;
use App\Model\Prodi;

use Auth;

class ProfilController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @param int $id
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        $auth = Auth::user()->nim;
        $mahasiswa = Mahasiswa::find($auth);
        $prodi = Prodi::where('kode_prodi', $mahasiswa->kode_prodi)->First();
        $krs = Krs::where('nim', $auth)->where('status', 1)->First();
        $detail_krs = DetailKrs::where('id_krs', $krs->id_krs)->where('status', 1)->get();

        return view('mahasiswa/profil/index', compact('mahasiswa', 'detail_krs', 'prodi'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit()
    {
        $auth = Auth::user()->nim;
        $mahasiswa = Mahasiswa::where('nim', $auth)->First();

        return view('/mahasiswa/profil/edit', compact('mahasiswa'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $auth = Auth::user()->nim;
        $mahasiswa =Mahasiswa::where('nim', $auth)->first();
        
        $mahasiswa->nama = $request->nama;
        $mahasiswa->nim = $request->nim;
        $mahasiswa->nik = $request->nik;
        $mahasiswa->jenis_kelamin = $request->jenis_kelamin;
        $mahasiswa->tempat_lahir = $request->tempat_lahir;
        $mahasiswa->tgl_lahir = $request->tgl_lahir;
        $mahasiswa->alamat = $request->alamat;
        $mahasiswa->provinsi = $request->provinsi;
        $mahasiswa->kota = $request->kota;
        $mahasiswa->kecamatan = $request->kecamatan;
        $mahasiswa->desa = $request->desa;
        $mahasiswa->kodepos = $request->kodepos;

        if(count($request->handphone)==1){
            $mahasiswa->handphone = $request->handphone;
        }

        if(count($request->email)==1){
            $mahasiswa->email = $request->email;
        }

        $mahasiswa->update();

        if($request->hasfile('foto')){
            if(File::exists(public_path('img/'.$mahasiswa->foto))){
                File::delete(public_path('img/'.$mahasiswa->foto));
            }

            $request->file('foto')->move('img/', $request->file('foto')->getClientOriginalName());
            $mahasiswa->foto = $request->file('foto')->getClientOriginalName();
            $mahasiswa->save();
        }


        return redirect('/mahasiswa/profil')->with('sukses', 'Data Berhasil Diupdate');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    
}
