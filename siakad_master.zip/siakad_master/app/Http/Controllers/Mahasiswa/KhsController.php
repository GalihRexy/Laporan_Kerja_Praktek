<?php

namespace App\Http\Controllers\Mahasiswa;

use Illuminate\Http\Request;
use \PDF;
use Dompdf\Dompdf;
use App\Http\Controllers\Controller;
use Auth;
use App\Model\Mahasiswa;
use App\Model\Khs;
use App\Model\DetailKhs;

class KhsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        return view('mahasiswa.khs.menu');
    }

    public function khs()
    {
        return view('mahasiswa.khs.index');
    }

    public function lo()
    {
        return view('mahasiswa.khs.lo');
    }

    public function lo_detail()
    {
        return view('mahasiswa.khs.lo-detail');
    }

    public function skpi()
    {
        return view('mahasiswa.khs.skpi');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function view($id)
    {
        $auth = Auth::user()->nim;
        $khs = Khs::where('nim', $auth)->FirstOrFail();
        $detail_khs = DetailKhs::where('kode_khs', $khs->kode_khs)->where('semester', $id)->get();
        $mahasiswa = Mahasiswa::where('nim', $auth)->first();

        $pdf = PDF::loadView('mahasiswa.khs.view', compact('mahasiswa', 'detail_khs'));
        return $pdf->stream();
    }

    public function download($id)
    {
        $auth = Auth::user()->nim;
        $khs = Khs::where('nim', $auth)->FirstOrFail();
        $detail_khs = DetailKhs::where('kode_khs', $khs->kode_khs)->where('semester', $id)->get();
        $mahasiswa = Mahasiswa::where('nim', $auth)->first();
        
        $pdf = PDF::loadView('mahasiswa.khs.view', compact('mahasiswa', 'detail_khs'));
        return $pdf->download($auth.'-'.$mahasiswa->nama.'.pdf');
    }

}
