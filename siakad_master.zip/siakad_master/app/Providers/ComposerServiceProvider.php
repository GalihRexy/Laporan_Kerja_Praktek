<?php

namespace App\Providers;

use App\Model\Universitas as Universitas;
use App\Model\Modul as Modul;
use App\Model\ModulGroup as ModulGroup;
use Illuminate\Support\ServiceProvider;

class ComposerServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //Get data from database for view component
        view()->composer('*', function($view) {
            $layoutData = Universitas::find('data');
            $layoutModul = Modul::all();
            $layoutModulGroup = ModulGroup::all();
            $view->layoutData = $layoutData;
            $view->layoutModul = $layoutModul;
            $view->layoutModulGroup = $layoutModulGroup;
        });
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
