<?php

namespace App\Http\Helpers\Karyawan;

use App\Model\Dosen as Dosen;
use App\Model\Fakultas as Fakultas;
use App\Model\Prodi as Prodi;
use App\Model\Level as Level;
use App\Model\Jabatan as Jabatan;

class KaryawanHelpers
{
	//code
}