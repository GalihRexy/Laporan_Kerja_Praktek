<?php

use App\Model\Level as Level;
use App\Model\Modul as Modul;

/**
 * Checked If File Exist
 *
 * @param $oldFile
 * @param $newFile
 * @param $fileName
 */
function checkFile($oldFile, $newFile, $disk, $fileName)
{
	/**
	 * --- For Example With Random Name File ---
	 *
	 * $md5Name = md5_file($request->file('logo')->getRealPath());
	 * $nameExtension = $request->file('logo')->guessExtension();
	 * $file = $request->file('logo')->storeAs('public/universitas',$md5Name.'.'.$nameExtension);
	 */
	if ($newFile != null) {
		$nameExtension = $newFile->getClientOriginalExtension();
		$oldfileexists = Storage::disk($disk)->exists($oldFile);

		if ($oldfileexists) {
			Storage::disk($disk)->delete($oldFile);
		}

		$file = $newFile->storeAs('', $fileName . '.' . $nameExtension, $disk);
		$data = $fileName . '.' . $nameExtension;
	} else {
		$data = $oldFile;
	}

	return $data;
}

function deleteFile($fileName, $disk)
{
	$oldfileexists = Storage::disk($disk)->exists($fileName);
	if ($oldfileexists) {
		if (Storage::disk($disk)->delete($fileName)) {
			return true;
		} else {
			return false;
		}
	}
	return true;
}

function copyFile($oldPath, $newPath)
{
	$copy = \File::copy($oldPath, $newPath);
	if ($copy) {
		return true;
	}
	return false;
}

function copyRegistrasi($fileName)
{
	$oldPath = '../../' . env('PATH_IMAGE_REGISTRASI', 'null') . $fileName;
	$newPath = Storage::disk('profil')->getAdapter()->getPathPrefix() . $fileName;
	$status = copyFile($oldPath, $newPath);

	if (!$status) {
		$fileName = 'error';
	}

	return $fileName;
}

function hakAkses($data)
{
	$hak_akses = '';
	foreach ($data as $key => $value) {
		$hak_akses .= $value . '-';
	}
	return $hak_akses;
}

function cekHakAkses($super = null, $data, $modul)
{
	$akses = false;

	if ($super == null) {
		$level = Level::find($data);
		if ($level->tingkat == 0) {
			$akses = true;
		} else {
			foreach (explode('-', $level->hak_akses) as $hak_akses) {
				if ($hak_akses == $modul) {
					$akses = true;
				}
			}
		}
	} elseif ($super != null) {
		$akses = true;
	}
	return $akses;
}

function treeView($data, $userLevel)
{
	$akses = false;
	$modul = Modul::where('id_group_mdl', '=', $data)->get();
	$level = Level::find($userLevel);
	foreach ($modul as $dataModul) {
		if ($level->tingkat == 0) {
			$akses = true;
		} else {
			foreach (explode('-', $level->hak_akses) as $hak_akses) {
				if ($hak_akses == $dataModul->id_modul) {
					$akses = true;
				}
			}
		}
	}

	return $akses;
}

function sidebar()
{
	$sidebar = '';
	if (Session::has('sidebar')) {
		if (Session::get('sidebar') == 'true') {
			$sidebar = 'sidebar-collapse';
		}
	} else {
		Session::put('sidebar', 'false');
	}

	return $sidebar;
}

function sidebarMenu($data)
{
	$sidebarMenu = '';
	if (Session::has('sidebar')) {
		if (Session::get('sidebar') == 'false') {
			if (Session::has('sidebarMenu')) {
				if (Session::get('sidebarMenu') == $data) {
					$sidebarMenu = 'active';
				}
			} else {
				Session::put('sidebar', 'false');
			}
		}
	}

	return $sidebarMenu;
}

function numberOnPaging($data)
{
	$no = ($data->currentpage() - 1) * $data->perpage() + 1;
	return $no;
}

/**
 * Function for Information Data
 */
function statusAktif($status)
{
	if ($status == '1') {
		$data = 'Sudah diapproved';
	} else {
		$data = 'Belum diapproved';
	}

	return $data;
}

function boolAktif($bool)
{
	if ($bool == '1') {
		$data = 'Aktif';
	} else {
		$data = 'Tidak Aktif';
	}

	return $data;
}

function boolYa($bool)
{
	if ($bool == '1') {
		$data = 'Ya';
	} else {
		$data = 'Tidak';
	}

	return $data;
}

function diffForHumansNull($data)
{
	if ($data != null) {
		return $data->diffForHumans();
	} else {
		return '-';
	}
}

function jenisKelamin($data)
{
	if ($data == 'L') {
		return 'Laki-laki';
	} elseif ($data == 'P') {
		return 'Perempuan';
	}
}

function statusWNI($data)
{
	if ($data == '1') {
		return 'WNI (Warga Negara Indonesia)';
	} elseif ($data == '0') {
		return 'WNA (Warga Negara Asing)';
	}
}

function tingkatAkses($data)
{
	switch ($data) {
		case '0':
			return 'Administrator';
			break;
		case '1':
			return 'Universitas';
			break;
		case '2':
			return 'Fakultas';
			break;
		case '3':
			return 'Prodi';
			break;

		default:
			return 'Unknown';
			break;
	}
}

/**
 * Function for Form
 */

function checkedRadio($value, $data)
{
	$check = '';
	if ($value == $data) {
		$check = 'checked = "checked"';
	}

	return $check;
}

function selectedSelect($value, $data)
{
	$check = '';
	if ($value == $data) {
		$check = 'selected = "selected"';
	}

	return $check;
}

function defaultRadio($value, $data)
{
	$check = '';
	if ($data == null || empty($data) || !isset($data)) {
		$check = 'selected = "selected"';
	}

	return $check;
}

function checkboxArray($value, $array)
{
	$check = '';
	foreach ($array as $data) {
		if ($data == $value) {
			$check .= 'checked="checked"';
		}
	}
	return $check;
}

function set_active($uri, $output = 'active')
{
 if( is_array($uri) ) {
   foreach ($uri as $u) {
     if (Route::is($u)) {
       return $output;
     }
   }
 } else {
   if (Route::is($uri)){
     return $output;
   }
 }
}