<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DosenWali extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dosen_wali', function (Blueprint $table) {
            $table->increments('id_dosen_wali');
            $table->string('nidn');
            $table->string('nim')->unique();
            $table->integer('id_sk_dosen_wali', $autoIncrement = false)->unsigned();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dosen_wali');
    }
}
