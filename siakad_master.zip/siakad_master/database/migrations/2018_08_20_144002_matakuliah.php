<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Matakuliah extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('matakuliah', function (Blueprint $table) {
            $table->string('kode_mk')->primary()->unique();
            $table->string('nama');
            $table->integer('sks', $autoIncrement = false);
            $table->string('kode_prodi');
            $table->string('kode_jenis_mk');
            $table->string('kode_kurikulum');
            $table->string('rumpun')->nullable();
            $table->date('tgl_revisi');
            $table->string('pengembangan_rps')->nullable();
            $table->string('nidn_pengembang_rps')->nullable();
            $table->string('nidn_ketua_kk')->nullable();
            $table->text('deskripsi')->nullable();
            $table->string('pustaka_utama')->nullable();
            $table->string('pustaka_pendukung')->nullable();
            $table->string('media_pembelajaran_sw')->nullable();
            $table->string('media_pembelajaran_hw')->nullable();
            $table->integer('biaya_per_sks', $autoIncrement = false)->nullable();
            $table->boolean('aktif');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('matakuliah');
    }
}
