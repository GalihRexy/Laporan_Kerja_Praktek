<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Karyawan extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('karyawan', function (Blueprint $table) {
            $table->string('nik')->primary()->unique();
            $table->string('username');
            $table->string('password');
            $table->string('nama');
            $table->integer('id_jabatan', $autoIncrement = false)->unsigned();
            $table->string('alamat');
            $table->string('desa');
            $table->string('kecamatan');
            $table->string('kota');
            $table->string('provinsi');
            $table->string('kodepos');
            $table->boolean('wni');
            $table->string('handphone')->unique()->nullable();
            $table->string('email')->unique()->nullable();
            $table->integer('id_level', $autoIncrement = false)->unsigned();
            $table->string('kode_prodi');
            $table->string('foto')->nullable();
            $table->boolean('aktif')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('karyawan');
    }
}
