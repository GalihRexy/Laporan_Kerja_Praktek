<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ForeignKey extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('prodi', function (Blueprint $table) {
            $table->foreign('kode_fakultas')
                    ->references('kode_fakultas')
                    ->on('fakultas')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('ruang', function (Blueprint $table) {
            $table->foreign('kode_kampus')
                    ->references('kode_kampus')
                    ->on('kampus')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('matakuliah', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_jenis_mk')
                    ->references('kode_jenis_mk')
                    ->on('jenis_matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_kurikulum')
                    ->references('kode_kurikulum')
                    ->on('kurikulum')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nidn_pengembang_rps')
                    ->references('nidn')
                    ->on('dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nidn_ketua_kk')
                    ->references('nidn')
                    ->on('dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('kurikulum', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('tahun_akademik', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('jadwal_kuliah', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_thn_akademik')
                    ->references('kode_thn_akademik')
                    ->on('tahun_akademik')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nidn')
                    ->references('nidn')
                    ->on('dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_ruang')
                    ->references('kode_ruang')
                    ->on('ruang')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('krs', function (Blueprint $table) {
            $table->foreign('kode_thn_akademik')
                    ->references('kode_thn_akademik')
                    ->on('tahun_akademik')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nim')
                    ->references('nim')
                    ->on('mahasiswa')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('detail_krs', function (Blueprint $table) {
            $table->foreign('id_krs')
                    ->references('id_krs')
                    ->on('krs')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_jadwal_kuliah')
                    ->references('kode_jadwal_kuliah')
                    ->on('jadwal_kuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('range_nilai', function (Blueprint $table) {
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nidn')
                    ->references('nidn')
                    ->on('dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('khs', function (Blueprint $table) {
            $table->foreign('nim')
                    ->references('nim')
                    ->on('mahasiswa')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('detail_khs', function (Blueprint $table) {
            $table->foreign('kode_khs')
                    ->references('kode_khs')
                    ->on('khs')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('nilai', function (Blueprint $table) {
            $table->foreign('id_assessment')
                    ->references('id_assessment')
                    ->on('assessment')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nim')
                    ->references('nim')
                    ->on('mahasiswa')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('assessment', function (Blueprint $table) {
            $table->foreign('id_lo')
                    ->references('id_lo')
                    ->on('learning_outcomes')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('learning_outcomes', function (Blueprint $table) {
            $table->foreign('kode_so')
                    ->references('kode_so')
                    ->on('study_outcomes')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('study_outcomes', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_skpi')
                    ->references('kode_skpi')
                    ->on('skpi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('jenis_matakuliah', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('prasyarat_matakuliah', function (Blueprint $table) {
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk_prasyarat')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('karyawan', function (Blueprint $table) {
            $table->foreign('id_jabatan')
                    ->references('id_jabatan')
                    ->on('jabatan')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('id_level')
                    ->references('id_level')
                    ->on('level')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('dosen', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('id_jabatan')
                    ->references('id_jabatan')
                    ->on('jabatan')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('id_klasifikasi_dosen')
                    ->references('id_klasifikasi_dosen')
                    ->on('klasifikasi_dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('mahasiswa', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('modul', function (Blueprint $table) {
            $table->foreign('id_group_mdl')
                    ->references('id_group_mdl')
                    ->on('modul_group')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('matakuliah_kurikulum', function (Blueprint $table) {
            $table->foreign('kode_kurikulum')
                    ->references('kode_kurikulum')
                    ->on('kurikulum')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('nilai_so', function (Blueprint $table) {
            $table->foreign('kode_so')
                    ->references('kode_so')
                    ->on('study_outcomes')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nim')
                    ->references('nim')
                    ->on('mahasiswa')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('dosen_wali', function (Blueprint $table) {
            $table->foreign('nidn')
                    ->references('nidn')
                    ->on('dosen')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('nim')
                    ->references('nim')
                    ->on('mahasiswa')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
            $table->foreign('id_sk_dosen_wali')
                    ->references('id_sk_dosen_wali')
                    ->on('sk_dosen_wali')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('sk_dosen_wali', function (Blueprint $table) {
            $table->foreign('kode_prodi')
                    ->references('kode_prodi')
                    ->on('prodi')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });

        Schema::table('default_range_nilai', function (Blueprint $table) {
            $table->foreign('kode_mk')
                    ->references('kode_mk')
                    ->on('matakuliah')
                    ->onDelete('restrict')
                    ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('prodi', function (Blueprint $table) {
            $table->dropForeign('prodi_kode_fakultas_foreign');
        });

        Schema::table('ruang', function (Blueprint $table) {
            $table->dropForeign('ruang_kode_kampus_foreign');
            $table->dropForeign('ruang_kode_prodi_foreign');
        });

        Schema::table('matakuliah', function (Blueprint $table) {
            $table->dropForeign('matakuliah_kode_prodi_foreign');
            $table->dropForeign('matakuliah_kode_jenis_mk_foreign');
            $table->dropForeign('matakuliah_kode_kurikulum_foreign');
            $table->dropForeign('matakuliah_nidn_pengembang_rps_foreign');
            $table->dropForeign('matakuliah_nidn_ketua_kk_foreign');
        });

        Schema::table('kurikulum', function (Blueprint $table) {
            $table->dropForeign('kurikulum_kode_prodi_foreign');
        });

        Schema::table('tahun_akademik', function (Blueprint $table) {
            $table->dropForeign('tahun_akademik_kode_prodi_foreign');
        });

        Schema::table('jadwal_kuliah', function (Blueprint $table) {
            $table->dropForeign('jadwal_kuliah_kode_prodi_foreign');
            $table->dropForeign('jadwal_kuliah_kode_thn_akademik_foreign');
            $table->dropForeign('jadwal_kuliah_nidn_foreign');
            $table->dropForeign('jadwal_kuliah_kode_mk_foreign');
            $table->dropForeign('jadwal_kuliah_kode_ruang_foreign');
        });

        Schema::table('krs', function (Blueprint $table) {
            $table->dropForeign('krs_kode_thn_akademik_foreign');
            $table->dropForeign('krs_nim_foreign');
        });

        Schema::table('detail_krs', function (Blueprint $table) {
            $table->dropForeign('detail_krs_id_krs_foreign');
            $table->dropForeign('detail_krs_kode_jadwal_kuliah_foreign');
            $table->dropForeign('detail_krs_kode_mk_foreign');
        });

        Schema::table('range_nilai', function (Blueprint $table) {
            $table->dropForeign('range_nilai_kode_mk_foreign');
            $table->dropForeign('range_nilai_nidn_foreign');
        });

        Schema::table('khs', function (Blueprint $table) {
            $table->dropForeign('khs_nim_foreign');
        });

        Schema::table('detail_khs', function (Blueprint $table) {
            $table->dropForeign('detail_khs_kode_khs_foreign');
            $table->dropForeign('detail_khs_kode_mk_foreign');
        });

        Schema::table('nilai', function (Blueprint $table) {
            $table->dropForeign('nilai_id_assessment_foreign');
            $table->dropForeign('nilai_nim_foreign');
        });

        Schema::table('assessment', function (Blueprint $table) {
            $table->dropForeign('assessment_id_lo_foreign');
        });

        Schema::table('learning_outcomes', function (Blueprint $table) {
            $table->dropForeign('learning_outcomes_kode_so_foreign');
            $table->dropForeign('learning_outcomes_kode_mk_foreign');
        });

        Schema::table('study_outcomes', function (Blueprint $table) {
            $table->dropForeign('study_outcomes_kode_prodi_foreign');
            $table->dropForeign('study_outcomes_kode_skpi_foreign');
        });

        Schema::table('jenis_matakuliah', function (Blueprint $table) {
            $table->dropForeign('jenis_matakuliah_kode_prodi_foreign');
        });

        Schema::table('prasyarat_matakuliah', function (Blueprint $table) {
            $table->dropForeign('prasyarat_matakuliah_kode_mk_foreign');
            $table->dropForeign('prasyarat_matakuliah_kode_mk_prasyarat_foreign');
        });

        Schema::table('karyawan', function (Blueprint $table) {
            $table->dropForeign('karyawan_id_jabatan_foreign');
            $table->dropForeign('karyawan_id_level_foreign');
            $table->dropForeign('karyawan_kode_prodi_foreign');
        });

        Schema::table('dosen', function (Blueprint $table) {
            $table->dropForeign('dosen_kode_prodi_foreign');
            $table->dropForeign('dosen_id_jabatan_foreign');
            $table->dropForeign('dosen_id_klasifikasi_dosen_foreign');
        });

        Schema::table('mahasiswa', function (Blueprint $table) {
            $table->dropForeign('mahasiswa_kode_prodi_foreign');
        });
        
        Schema::table('modul', function (Blueprint $table) {
            $table->dropForeign('modul_id_group_mdl_foreign');
        });
        
        Schema::table('matakuliah_kurikulum', function (Blueprint $table) {
            $table->dropForeign('matakuliah_kurikulum_kode_kurikulum_foreign');
            $table->dropForeign('matakuliah_kurikulum_kode_mk_foreign');
        });
        
        Schema::table('nilai_so', function (Blueprint $table) {
            $table->dropForeign('nilai_so_kode_so_foreign');
            $table->dropForeign('nilai_so_nim_foreign');
        });
        
        Schema::table('dosen_wali', function (Blueprint $table) {
            $table->dropForeign('dosen_wali_nidn_foreign');
            $table->dropForeign('dosen_wali_nim_foreign');
            $table->dropForeign('dosen_wali_id_sk_dosen_wali_foreign');
        });
        
        Schema::table('sk_dosen_wali', function (Blueprint $table) {
            $table->dropForeign('sk_dosen_wali_kode_prodi_foreign');
        });
        
        Schema::table('default_range_nilai', function (Blueprint $table) {
            $table->dropForeign('default_range_nilai_kode_mk_foreign');
        });
    }
}
