<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class PrasyaratMatakuliah extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('prasyarat_matakuliah', function (Blueprint $table) {
            $table->string('kode_prasyarat_mk')->primary()->unique();
            $table->string('kode_mk');
            $table->string('kode_mk_prasyarat');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prasyarat_matakuliah');
    }
}
