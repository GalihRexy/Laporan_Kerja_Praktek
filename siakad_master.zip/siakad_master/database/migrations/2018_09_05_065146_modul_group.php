<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ModulGroup extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modul_group', function (Blueprint $table) {
            $table->increments('id_group_mdl');
            $table->string('nama');
            $table->string('icon')->nullable();
            $table->string('logo')->nullable();
            $table->string('link')->nullable();
            $table->string('keterangan')->nullable();
            $table->boolean('super_only');
            $table->boolean('default');
            $table->boolean('aktif')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modul_group');
    }
}
