<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Assessment extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assessment', function (Blueprint $table) {
            $table->increments('id_assessment');
            $table->integer('id_lo', $autoIncrement = false)->unsigned();
            $table->string('metode');
            $table->string('bobot');
            $table->string('kriteria_nilai');
            $table->date('waktu_pelaksanaan');
            $table->string('target_pencapaian');
            $table->string('base_line');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assessment');
    }
}
