<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class StudyOutcomes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('study_outcomes', function (Blueprint $table) {
            $table->string('kode_so')->primary()->unique();
            $table->string('kode_prodi');
            $table->string('kode_skpi');
            $table->text('deskripsi_so');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('study_outcomes');
    }
}
