<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Ruang extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ruang', function (Blueprint $table) {
            $table->string('kode_ruang')->primary()->unique();
            $table->string('kode_kampus');
            $table->string('kode_prodi');
            $table->string('nama');
            $table->string('lantai')->nullable();
            $table->integer('kapasitas', $autoIncrement = false)->nullable();
            $table->integer('kapasitas_ujian', $autoIncrement = false)->nullable();
            $table->integer('kolom_meja', $autoIncrement = false)->nullable();
            $table->text('keterangan')->nullable();
            $table->boolean('ruang_kuliah');
            $table->boolean('ruang_usm');
            $table->boolean('aktif');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ruang');
    }
}
