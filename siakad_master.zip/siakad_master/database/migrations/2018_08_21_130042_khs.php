<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Khs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('khs', function (Blueprint $table) {
            $table->string('kode_khs')->primary()->unique();
            $table->string('nim');
            $table->string('tahun_semester');
            $table->integer('total_sks_sdh_diambil', $autoIncrement = false);
            $table->integer('total_sks_blm_diambil', $autoIncrement = false);
            $table->string('tmt');
            $table->string('tst');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('khs');
    }
}
