<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Prodi extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('prodi', function (Blueprint $table) {
            $table->string('kode_prodi')->primary()->unique();
            $table->string('kode_fakultas');
            $table->string('nama');
            $table->string('jenjang')->nullable();
            $table->string('gelar')->nullable();
            $table->string('akreditasi')->nullable();
            $table->string('sk_dikti')->nullable();
            $table->date('tgl_sk_dikti')->nullable();
            $table->string('sk_ban')->nullable();
            $table->date('tgl_sk_ban')->nullable();
            $table->string('ketua_prodi', 50)->nullable();
            $table->text('keterangan')->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prodi');
    }
}
