<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SkDosenWali extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sk_dosen_wali', function (Blueprint $table) {
            $table->increments('id_sk_dosen_wali');
            $table->string('nomor_sk_dosen_wali')->unique();
            $table->date('tanggal_sk');
            $table->string('kode_prodi');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sk_dosen_wali');
    }
}
