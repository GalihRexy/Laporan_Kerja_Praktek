<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DetailKhs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detail_khs', function (Blueprint $table) {
            $table->increments('id_detail_khs');
            $table->string('kode_khs');
            $table->string('kode_mk');
            $table->string('nilai');
            $table->integer('sks', $autoIncrement = false);
            $table->string('nilai_mutu');
            $table->string('status');
            $table->string('ambil_ke');
            $table->year('tahun');
            $table->integer('semester', $autoIncrement = false);
            $table->string('pre_lulus');
            $table->string('pre_tahun');
            $table->text('keterangan');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detail_khs');
    }
}
