<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DetailKrs extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detail_krs', function (Blueprint $table) {
            $table->increments('id_detail_krs');
            $table->integer('id_krs', $autoIncrement = false)->unsigned();
            $table->string('kode_jadwal_kuliah');
            $table->string('nilai');
            $table->string('kode_mk');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detail_krs');
    }
}
