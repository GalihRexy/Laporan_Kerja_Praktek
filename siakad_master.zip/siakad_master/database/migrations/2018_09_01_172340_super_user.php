<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class SuperUser extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('super_table', function (Blueprint $table) {
            $table->string('username')->primary()->unique();
            $table->string('password');
            $table->string('nama');
            $table->boolean('super_user');
            $table->string('handphone')->unique()->nullable();
            $table->string('email')->unique()->nullable();
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('super_table');
    }
}
