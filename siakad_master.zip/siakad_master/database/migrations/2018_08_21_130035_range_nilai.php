<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RangeNilai extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('range_nilai', function (Blueprint $table) {
            $table->increments('id_range');
            $table->string('kode_mk');
            $table->string('nidn');
            $table->integer('range_a', $autoIncrement = false);
            $table->integer('range_ab', $autoIncrement = false);
            $table->integer('range_b', $autoIncrement = false);
            $table->integer('range_bc', $autoIncrement = false);
            $table->integer('range_c', $autoIncrement = false);
            $table->integer('range_d', $autoIncrement = false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('range_nilai');
    }
}
