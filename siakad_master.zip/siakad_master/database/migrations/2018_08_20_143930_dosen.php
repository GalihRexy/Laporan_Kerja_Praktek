<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Dosen extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('dosen', function (Blueprint $table) {
            $table->string('nidn')->primary()->unique();
            $table->string('username')->unique();
            $table->string('password');
            $table->string('nip_pns')->nullable();
            $table->string('nik');
            $table->string('nama');
            $table->string('tempat_lahir');
            $table->date('tgl_lahir');
            $table->enum('jenis_kelamin', ['L', 'P']);
            $table->string('alamat');
            $table->string('desa');
            $table->string('kecamatan');
            $table->string('kota');
            $table->string('provinsi');
            $table->string('kodepos');
            $table->boolean('wni');
            $table->string('handphone')->unique()->nullable();
            $table->string('email')->unique()->nullable();
            $table->string('gelar')->nullable();
            $table->string('jenjang')->nullable();
            $table->string('keilmuan')->nullable();
            $table->string('lulusan_pt')->nullable();
            $table->string('institusi_induk')->nullable();
            $table->string('kode_prodi');
            $table->integer('id_jabatan', $autoIncrement = false)->unsigned();
            $table->integer('id_klasifikasi_dosen', $autoIncrement = false)->unsigned();
            $table->string('no_rek')->nullable();
            $table->string('foto')->nullable();
            $table->boolean('aktif')->default(true);
            $table->rememberToken();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dosen');
    }
}
