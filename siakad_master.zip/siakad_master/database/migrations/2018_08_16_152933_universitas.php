<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Universitas extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('universitas', function (Blueprint $table) {
            $table->string('id')->primary()->unique();
            $table->string('id_univ');
            $table->string('nama');
            $table->string('alamat');
            $table->string('kota');
            $table->string('provinsi');
            $table->string('kodepos');
            $table->string('telepon')->unique()->nullable();
            $table->string('fax')->unique()->nullable();
            $table->string('email')->unique()->nullable();
            $table->string('website')->unique();
            $table->string('akta')->nullable();
            $table->date('tgl_akta');
            $table->string('pengesahan')->nullable();
            $table->date('tgl_pengesahan');
            $table->string('logo')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('universitas');
    }
}
