<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Modul extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modul', function (Blueprint $table) {
            $table->increments('id_modul');
            $table->integer('id_group_mdl', $autoIncrement = false)->unsigned();
            $table->string('nama');
            $table->string('icon')->nullable();
            $table->string('logo')->nullable();
            $table->string('link')->nullable();
            $table->string('keterangan')->nullable();
            $table->integer('order', $autoIncrement = false)->unsigned()->nullable();
            $table->boolean('aktif')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modul');
    }
}
