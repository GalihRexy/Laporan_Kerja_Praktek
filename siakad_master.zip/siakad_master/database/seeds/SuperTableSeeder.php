<?php

use Illuminate\Database\Seeder;

class SuperTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('super_table')->insert([
        	'username' => 'admin',
            'password' => bcrypt('admin'),
            'nama' => 'Super User',
            'super_user' => '1',
            'handphone' => '08989667664',
            'email' => 'hendra_eddy@ymail.com',
        ]);
    }
}
