<?php

use Illuminate\Database\Seeder;

class RuangTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('ruang')->insert([
        	'kode_ruang' => '1',
        	'kode_kampus' => 'FTBDG',
        	'kode_prodi' => 'TI',
        	'nama' => 'A',
            'lantai' => '2',
            'kapasitas' => '20',
            'kapasitas_ujian' => '15',
            'kolom_meja' => '15',
            'keterangan' => 'default',
            'ruang_kuliah' => '1',
            'ruang_usm' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('ruang')->insert([
        	'kode_ruang' => '2',
        	'kode_kampus' => 'FTBDG',
        	'kode_prodi' => 'IK',
        	'nama' => 'B',
            'lantai' => '2',
            'kapasitas' => '20',
            'kapasitas_ujian' => '15',
            'kolom_meja' => '15',
            'keterangan' => 'default',
            'ruang_kuliah' => '1',
            'ruang_usm' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('ruang')->insert([
        	'kode_ruang' => '3',
        	'kode_kampus' => 'FTCMH',
        	'kode_prodi' => 'KU',
        	'nama' => 'C',
            'lantai' => '2',
            'kapasitas' => '20',
            'kapasitas_ujian' => '15',
            'kolom_meja' => '15',
            'keterangan' => 'default',
            'ruang_kuliah' => '1',
            'ruang_usm' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('ruang')->insert([
        	'kode_ruang' => '4',
        	'kode_kampus' => 'FTBDG',
        	'kode_prodi' => 'MA',
        	'nama' => 'D',
            'lantai' => '2',
            'kapasitas' => '20',
            'kapasitas_ujian' => '15',
            'kolom_meja' => '15',
            'keterangan' => 'default',
            'ruang_kuliah' => '1',
            'ruang_usm' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('ruang')->insert([
        	'kode_ruang' => '5',
        	'kode_kampus' => 'FTCMH',
        	'kode_prodi' => 'PS',
        	'nama' => 'E',
            'lantai' => '2',
            'kapasitas' => '20',
            'kapasitas_ujian' => '15',
            'kolom_meja' => '15',
            'keterangan' => 'default',
            'ruang_kuliah' => '1',
            'ruang_usm' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
