<?php

use Illuminate\Database\Seeder;

class UniversitasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('universitas')->insert([
            'id' => 'data',
        	'id_univ' => 'UNJANI',
            'nama' => 'Universitas Jendral Achmad Yani',
            'alamat' => 'Jl. Terusan Jendral Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'kodepos' => '40533',
            'provinsi' => 'Jawa Barat',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'humas@unjani.ac.id',
            'website' => 'http://unjani.ac.id',
            'akta' => '027/YKEP/1990',
            'tgl_akta' => '1990-05-20',
            'pengesahan' => '0512/0/1990',
            'tgl_pengesahan' => '1990-08-09',
            'logo' => 'universitas.png',
        ]);
    }
}
 