<?php

use Illuminate\Database\Seeder;

class ProdiTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('prodi')->insert([
        	'kode_prodi' => 'TI',
        	'kode_fakultas' => 'FT',
            'nama' => 'Teknik Industri',
            'jenjang' => 'S1',
            'gelar' => 'S.T',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'TM',
            'kode_fakultas' => 'FT',
            'nama' => 'Teknik Mesin',
            'jenjang' => 'S1',
            'gelar' => 'S.T',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'TE',
            'kode_fakultas' => 'FT',
            'nama' => 'Teknik Elektro',
            'jenjang' => 'S1',
            'gelar' => 'S.T',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'TS',
            'kode_fakultas' => 'FT',
            'nama' => 'Teknik Sipil',
            'jenjang' => 'S1',
            'gelar' => 'S.T',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'IK',
            'kode_fakultas' => 'FMIPA',
            'nama' => 'Ilmu Komputer',
            'jenjang' => 'S1',
            'gelar' => 'S.Kom',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'KI',
            'kode_fakultas' => 'FMIPA',
            'nama' => 'Kimia',
            'jenjang' => 'S1',
            'gelar' => 'S.Si',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'FI',
            'kode_fakultas' => 'FMIPA',
            'nama' => 'Fisika',
            'jenjang' => 'S1',
            'gelar' => 'S.Si',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'KU',
            'kode_fakultas' => 'FK',
            'nama' => 'Kedokteran Umum',
            'jenjang' => 'S1',
            'gelar' => 'S.Ked',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'KG',
            'kode_fakultas' => 'FK',
            'nama' => 'Kedokteran Gigi',
            'jenjang' => 'S1',
            'gelar' => 'S.p',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'MA',
            'kode_fakultas' => 'FE',
            'nama' => 'Manajemen',
            'jenjang' => 'S1',
            'gelar' => 'S.E',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'AK',
            'kode_fakultas' => 'FE',
            'nama' => 'Akutansi',
            'jenjang' => 'S1',
            'gelar' => 'S.E',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('prodi')->insert([
            'kode_prodi' => 'PS',
            'kode_fakultas' => 'FP',
            'nama' => 'Psikologi',
            'jenjang' => 'S1',
            'gelar' => 'S.Psi',
            'akreditasi' => 'B',
            'sk_dikti' => 'NO/31/KPT-III/TAR-SM/1974',
            'tgl_sk_dikti' => date("Y-m-d"),
            'sk_ban' => 'No.027/BAN-PT/Akred/S/I/2015',
            'tgl_sk_ban' => date("Y-m-d"),
            'ketua_prodi' => 'Ketua Prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
