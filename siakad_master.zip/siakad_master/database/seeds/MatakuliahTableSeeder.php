<?php

use Illuminate\Database\Seeder;

class MatakuliahTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('matakuliah')->insert([
        	'kode_mk' => '1',
        	'nama' => 'Algoritma',
        	'sks' => '3',
        	'kode_prodi' => 'IK',
            'kode_jenis_mk' => '2',
            'kode_kurikulum' => '1',
            'rumpun' => 'default',
            'tgl_revisi' => date("Y-m-d"),
            'pengembangan_rps' => 'default',
            'deskripsi' => 'default',
            'pustaka_utama' => 'default',
            'pustaka_pendukung' => 'default',
            'media_pembelajaran_sw' => 'default',
            'media_pembelajaran_hw' => 'default',
            'biaya_per_sks' => '20000',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('matakuliah')->insert([
        	'kode_mk' => '2',
        	'nama' => 'Akutansi',
        	'sks' => '3',
        	'kode_prodi' => 'MA',
            'kode_jenis_mk' => '4',
            'kode_kurikulum' => '2',
            'rumpun' => 'default',
            'tgl_revisi' => date("Y-m-d"),
            'pengembangan_rps' => 'default',
            'deskripsi' => 'default',
            'pustaka_utama' => 'default',
            'pustaka_pendukung' => 'default',
            'media_pembelajaran_sw' => 'default',
            'media_pembelajaran_hw' => 'default',
            'biaya_per_sks' => '20000',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('matakuliah')->insert([
        	'kode_mk' => '3',
        	'nama' => 'Genetika',
        	'sks' => '3',
        	'kode_prodi' => 'KU',
            'kode_jenis_mk' => '5',
            'kode_kurikulum' => '3',
            'rumpun' => 'default',
            'tgl_revisi' => date("Y-m-d"),
            'pengembangan_rps' => 'default',
            'deskripsi' => 'default',
            'pustaka_utama' => 'default',
            'pustaka_pendukung' => 'default',
            'media_pembelajaran_sw' => 'default',
            'media_pembelajaran_hw' => 'default',
            'biaya_per_sks' => '20000',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('matakuliah')->insert([
        	'kode_mk' => '4',
        	'nama' => 'Kalkulus',
        	'sks' => '3',
        	'kode_prodi' => 'TI',
            'kode_jenis_mk' => '1',
            'kode_kurikulum' => '4',
            'rumpun' => 'default',
            'tgl_revisi' => date("Y-m-d"),
            'pengembangan_rps' => 'default',
            'deskripsi' => 'default',
            'pustaka_utama' => 'default',
            'pustaka_pendukung' => 'default',
            'media_pembelajaran_sw' => 'default',
            'media_pembelajaran_hw' => 'default',
            'biaya_per_sks' => '20000',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('matakuliah')->insert([
        	'kode_mk' => '5',
        	'nama' => 'Logika',
        	'sks' => '3',
        	'kode_prodi' => 'PS',
            'kode_jenis_mk' => '3',
            'kode_kurikulum' => '5',
            'rumpun' => 'default',
            'tgl_revisi' => date("Y-m-d"),
            'pengembangan_rps' => 'default',
            'deskripsi' => 'default',
            'pustaka_utama' => 'default',
            'pustaka_pendukung' => 'default',
            'media_pembelajaran_sw' => 'default',
            'media_pembelajaran_hw' => 'default',
            'biaya_per_sks' => '20000',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
