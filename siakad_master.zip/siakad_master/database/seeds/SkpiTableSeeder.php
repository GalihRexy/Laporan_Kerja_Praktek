<?php

use Illuminate\Database\Seeder;

class SkpiTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('skpi')->insert([
            'kode_skpi' => 'SKPI01',
        	'deskripsi_skpi' => 'Web Developer',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
