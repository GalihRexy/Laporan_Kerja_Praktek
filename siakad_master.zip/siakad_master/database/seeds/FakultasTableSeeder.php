<?php

use Illuminate\Database\Seeder;

class FakultasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('fakultas')->insert([
        	'kode_fakultas' => 'FT',
            'nama' => 'Teknik',
            'alamat' => 'Jl. Terusan Jenderal Gatot Subroto PO. Box 807',
            'kota' => 'Kota Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40284',
            'telepon' => '(022) 7312321',
            'fax' => '(022) 7323433',
            'email' => 'teknikindustriunjani@gmail.com',
            'website' => 'http://teknikindustriunjani.net/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FMIPA',
            'nama' => 'MIPA',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'fmipaunjani@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FK',
            'nama' => 'Kedokteran',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'kedokteran@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FE',
            'nama' => 'Ekonomi',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'fekonomiunjani@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FP',
            'nama' => 'Psikologi',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'fpsikologiunjani@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FISIP',
            'nama' => 'ISIP',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'fisipunjani@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('fakultas')->insert([
            'kode_fakultas' => 'FF',
            'nama' => 'Farmasi',
            'alamat' => 'Jl. Terusan Jenderal Sudirman PO. Box 148',
            'kota' => 'Kota Cimahi',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40533',
            'telepon' => '(022) 6656190',
            'fax' => '(022) 6652069',
            'email' => 'ffarmasipunjani@gmail.com',
            'website' => 'http://unjani.ac.id/',
            'logo' => 'FT.png',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
