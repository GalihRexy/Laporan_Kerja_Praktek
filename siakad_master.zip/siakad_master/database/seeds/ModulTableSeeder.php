<?php

use Illuminate\Database\Seeder;

class ModulTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('modul')->insert([
            'id_modul' => '1',
            'id_group_mdl' => '1',
            'nama' => 'Universitas',
            'icon' => 'fa fa-university',
            'logo' => 'modul_Universitas.png',
            'link' => 'admin/universitas',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '2',
            'id_group_mdl' => '1',
            'nama' => 'Fakultas',
            'icon' => 'fa fa-suitcase',
            'logo' => 'modul_Fakultas.png',
            'link' => 'admin/fakultas',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '3',
            'id_group_mdl' => '1',
            'nama' => 'Program Studi',
            'icon' => 'fa fa-book',
            'logo' => 'modul_Program Studi.png',
            'link' => 'admin/prodi',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '4',
            'id_group_mdl' => '1',
            'nama' => 'Kampus',
            'icon' => 'fa fa-building-o',
            'logo' => 'modul_Kampus.png',
            'link' => 'admin/kampus',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '5',
            'id_group_mdl' => '1',
            'nama' => 'Ruang',
            'icon' => 'fa fa-sitemap',
            'logo' => 'modul_Ruang.png',
            'link' => 'admin/ruang',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '6',
            'id_group_mdl' => '1',
            'nama' => 'Dosen',
            'icon' => 'fa fa-graduation-cap',
            'logo' => 'modul_Dosen.png',
            'link' => 'admin/dosen',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '7',
            'id_group_mdl' => '1',
            'nama' => 'Mahasiswa',
            'icon' => 'fa fa-users',
            'logo' => 'modul_Mahasiswa.png',
            'link' => 'admin/mahasiswa',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '8',
            'id_group_mdl' => '2',
            'nama' => 'Karyawan',
            'icon' => 'fa fa-users',
            'logo' => 'modul_Karyawan.png',
            'link' => 'admin/karyawan',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '9',
            'id_group_mdl' => '2',
            'nama' => 'Level',
            'icon' => 'fa fa-cubes',
            'logo' => 'modul_Level.png',
            'link' => 'admin/level',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '10',
            'id_group_mdl' => '2',
            'nama' => 'Jabatan',
            'icon' => 'fa fa-line-chart',
            'logo' => 'modul_Jabatan.png',
            'link' => 'admin/jabatan',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '11',
            'id_group_mdl' => '5',
            'nama' => 'Modul',
            'icon' => 'fa fa-briefcase',
            'logo' => 'modul_Modul.png',
            'link' => 'admin/modul',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '12',
            'id_group_mdl' => '3',
            'nama' => 'Kurikulum',
            'icon' => 'fa fa-qrcode',
            'logo' => 'modul_Kurikulum.png',
            'link' => 'admin/kurikulum',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '13',
            'id_group_mdl' => '3',
            'nama' => 'Matakuliah',
            'icon' => 'fa fa-archive',
            'logo' => 'modul_Matakuliah.png',
            'link' => 'admin/matakuliah',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '14',
            'id_group_mdl' => '3',
            'nama' => 'Prasyarat Matakuliah',
            'icon' => 'fa fa-newspaper-o',
            'logo' => 'modul_Prasyarat Matakuliah.png',
            'link' => 'admin/prasyaratmatakuliah',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '15',
            'id_group_mdl' => '3',
            'nama' => 'Jenis Matakuliah',
            'icon' => 'fa fa-qrcode',
            'logo' => 'modul_Jenis Matakuliah.png',
            'link' => 'admin/jenis_matakuliah',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '16',
            'id_group_mdl' => '3',
            'nama' => 'Study Outcomes',
            'icon' => 'fa fa-book',
            'logo' => 'modul_Study Outcomes.png',
            'link' => 'admin/study_outcomes',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '17',
            'id_group_mdl' => '3',
            'nama' => 'Learning Outcomes',
            'icon' => 'fa fa-trophy',
            'logo' => 'modul_Learning Outcomes.png',
            'link' => 'admin/learning_outcomes',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '18',
            'id_group_mdl' => '3',
            'nama' => 'Assessment',
            'icon' => 'fa fa-sliders',
            'logo' => 'modul_Assessment.png',
            'link' => 'admin/assessment',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '19',
            'id_group_mdl' => '4',
            'nama' => 'Tahun Akademik',
            'icon' => 'fa fa-building-o',
            'logo' => 'modul_Tahun Akademik.png',
            'link' => 'admin/tahunakademik',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '20',
            'id_group_mdl' => '4',
            'nama' => 'Jadwal Kuliah',
            'icon' => 'fa fa-sitemap',
            'logo' => 'modul_Jadwal Kuliah.png',
            'link' => 'admin/jadwalkuliah',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '21',
            'id_group_mdl' => '4',
            'nama' => 'KRS',
            'icon' => 'fa fa-calendar-o',
            'logo' => 'modul_KRS.png',
            'link' => 'admin/krs',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '22',
            'id_group_mdl' => '4',
            'nama' => 'Detail KRS',
            'icon' => 'fa fa-archive',
            'logo' => 'modul_Detail KRS.png',
            'link' => 'admin/krs_detail',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '23',
            'id_group_mdl' => '4',
            'nama' => 'KHS',
            'icon' => 'fa fa-bar-chart',
            'logo' => 'modul_KHS.png',
            'link' => 'admin/khs',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '24',
            'id_group_mdl' => '4',
            'nama' => 'Detail KHS',
            'icon' => 'fa fa-language',
            'logo' => 'modul_Detail KHS.png',
            'link' => 'admin/khs_detail',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '25',
            'id_group_mdl' => '4',
            'nama' => 'Nilai',
            'icon' => 'fa fa-sort-numeric-desc',
            'logo' => 'modul_Nilai.png',
            'link' => 'admin/nilai',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '26',
            'id_group_mdl' => '5',
            'nama' => 'Group Modul',
            'icon' => 'fa fa-briefcase',
            'logo' => 'modul_Group Modul.png',
            'link' => 'admin/group_modul',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '27',
            'id_group_mdl' => '2',
            'nama' => 'Klasifikasi Dosen',
            'icon' => 'fa fa-briefcase',
            'logo' => 'modul_Klasifikasi Dosen.png',
            'link' => 'admin/klasifikasi_dosen',
            'keterangan' => '',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
        DB::table('modul')->insert([
            'id_modul' => '28',
            'id_group_mdl' => '1',
            'nama' => 'Registrasi Mahasiswa',
            'icon' => 'fa fa-calendar-o',
            'logo' => 'modul_Registrasi Mahasiswa.png',
            'link' => 'admin/registrasi',
            'keterangan' => 'Aplikasi untuk registrasi mahasiswa',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}