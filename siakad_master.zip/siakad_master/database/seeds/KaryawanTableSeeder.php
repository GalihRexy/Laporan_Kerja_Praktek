<?php

use Illuminate\Database\Seeder;

class KaryawanTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('karyawan')->insert([
            'nik' => rand(),
            'username' => 'admin',
            'password' => bcrypt('admin'),
            'nama' => 'Administrator',
            'id_jabatan' => '1',
            'alamat' => 'Bale endah',
            'desa' => 'Baleendah',
            'kecamatan' => 'Baleendah',
            'kota' => 'Kab. Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '4000',
            'wni' => '1',
            'handphone' => '082'.rand(),
            'email' => str_random(10).'@gmail.com',
            'id_level' => '1',
            'kode_prodi' => 'TI',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('karyawan')->insert([
            'nik' => rand(),
        	'username' => 'admin1',
            'password' => bcrypt('admin1'),
            'nama' => 'Admin Teknik Industri',
            'id_jabatan' => '1',
            'alamat' => 'Bale endah',
            'desa' => 'Baleendah',
            'kecamatan' => 'Baleendah',
            'kota' => 'Kab. Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '4000',
            'wni' => '1',
            'handphone' => '082'.rand(),
            'email' => str_random(10).'@gmail.com',
            'id_level' => '1',
            'kode_prodi' => 'TI',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('karyawan')->insert([
            'nik' => rand(),
            'username' => 'admin2',
            'password' => bcrypt('admin2'),
            'nama' => 'Admin Kedokteran Umum',
            'id_jabatan' => '1',
            'alamat' => 'Bale endah',
            'desa' => 'Baleendah',
            'kecamatan' => 'Baleendah',
            'kota' => 'Kab. Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '4000',
            'wni' => '1',
            'handphone' => '082'.rand(),
            'email' => str_random(10).'@gmail.com',
            'id_level' => '1',
            'kode_prodi' => 'KU',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('karyawan')->insert([
            'nik' => rand(),
            'username' => 'admin3',
            'password' => bcrypt('admin3'),
            'nama' => 'Admin Ilmu Komputer',
            'id_jabatan' => '1',
            'alamat' => 'Bale endah',
            'desa' => 'Baleendah',
            'kecamatan' => 'Baleendah',
            'kota' => 'Kab. Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '4000',
            'wni' => '1',
            'handphone' => '082'.rand(),
            'email' => str_random(10).'@gmail.com',
            'id_level' => '1',
            'kode_prodi' => 'IK',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
