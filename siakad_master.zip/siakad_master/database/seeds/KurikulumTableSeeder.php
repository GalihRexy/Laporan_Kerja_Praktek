<?php

use Illuminate\Database\Seeder;

class KurikulumTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('kurikulum')->insert([
        	'kode_kurikulum' => '1',
        	'kode_prodi' => 'TI',
        	'tahun' => '18',
            'nama' => 'Default1',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('kurikulum')->insert([
        	'kode_kurikulum' => '2',
        	'kode_prodi' => 'IK',
        	'tahun' => '18',
            'nama' => 'Default2',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('kurikulum')->insert([
        	'kode_kurikulum' => '3',
        	'kode_prodi' => 'KU',
        	'tahun' => '18',
            'nama' => 'Default3',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('kurikulum')->insert([
        	'kode_kurikulum' => '4',
        	'kode_prodi' => 'MA',
        	'tahun' => '18',
            'nama' => 'Default4',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('kurikulum')->insert([
        	'kode_kurikulum' => '5',
        	'kode_prodi' => 'PS',
        	'tahun' => '18',
            'nama' => 'Default5',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
