<?php

use Illuminate\Database\Seeder;

class JenisMatakuliahTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('jenis_matakuliah')->insert([
            'kode_jenis_mk' => '1',
            'nama' => 'Matakuliah keahlian',
            'wajib' => '1',
            'kode_prodi' => 'TI',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('jenis_matakuliah')->insert([
            'kode_jenis_mk' => '2',
            'nama' => 'Matakuliah keilmuan',
            'wajib' => '1',
            'kode_prodi' => 'TI',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('jenis_matakuliah')->insert([
            'kode_jenis_mk' => '3',
            'nama' => 'Matakuliah pengembangan kepribadian',
            'wajib' => '1',
            'kode_prodi' => 'TI',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('jenis_matakuliah')->insert([
            'kode_jenis_mk' => '4',
            'nama' => 'Matakuliah perilaku',
            'wajib' => '0',
            'kode_prodi' => 'TI',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('jenis_matakuliah')->insert([
            'kode_jenis_mk' => '5',
            'nama' => 'Matakuliah pilihan',
            'wajib' => '0',
            'kode_prodi' => 'TI',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
