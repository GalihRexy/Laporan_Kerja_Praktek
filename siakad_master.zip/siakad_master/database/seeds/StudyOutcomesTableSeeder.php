<?php

use Illuminate\Database\Seeder;

class StudyOutcomesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('study_outcomes')->insert([
            'kode_so' => 'SO01',
            'kode_prodi' => 'TI',
            'kode_skpi' => 'SKPI01',
        	'deskripsi_so' => 'contoh',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
