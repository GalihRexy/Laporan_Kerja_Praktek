<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // $this->call(UsersTableSeeder::class);
        $this->call(SuperTableSeeder::class);
        $this->call(GroupModulTableSeeder::class);
        $this->call(ModulTableSeeder::class);
        $this->call(UniversitasTableSeeder::class);
        $this->call(FakultasTableSeeder::class);
        $this->call(ProdiTableSeeder::class);
        $this->call(JabatanTableSeeder::class);
        $this->call(KlasifikasiDosenTableSeeder::class);
        $this->call(LevelTableSeeder::class);
        $this->call(KaryawanTableSeeder::class);
        $this->call(DosenTableSeeder::class);
        $this->call(KampusTableSeeder::class);
        $this->call(RuangTableSeeder::class);
        $this->call(KurikulumTableSeeder::class);
        $this->call(JenisMatakuliahTableSeeder::class);
        $this->call(MatakuliahTableSeeder::class);
        $this->call(SkpiTableSeeder::class);
        $this->call(StudyOutcomesTableSeeder::class);
        $this->call(LearningOutcomesTableSeeder::class);
    }
}
