<?php

use Illuminate\Database\Seeder;

class KlasifikasiDosenTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('klasifikasi_dosen')->insert([
        	'id_klasifikasi_dosen' => '1',
            'nama' => 'Dosen Tetap',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('klasifikasi_dosen')->insert([
            'id_klasifikasi_dosen' => '2',
            'nama' => 'Dosen LB',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('klasifikasi_dosen')->insert([
            'id_klasifikasi_dosen' => '3',
            'nama' => 'Dosen Kontrak',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
