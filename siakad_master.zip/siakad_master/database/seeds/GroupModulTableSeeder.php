<?php

use Illuminate\Database\Seeder;

class GroupModulTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('modul_group')->insert([
        	'id_group_mdl' => '1',
            'nama' => 'Master Akademik',
            'icon'  => 'fa fa-university',
            'logo'	=> 'group_Master Akademik.png',
            'link' => 'default',
            'keterangan' => '',
            'super_only' => '0',
            'default' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('modul_group')->insert([
            'id_group_mdl' => '2',
            'nama' => 'Master Umum',
            'icon'  => 'fa fa-newspaper-o',
            'logo'  => 'group_Master Umum.png',
            'link' => 'default',
            'keterangan' => '',
            'super_only' => '0',
            'default' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('modul_group')->insert([
            'id_group_mdl' => '3',
            'nama' => 'Kurikulum',
            'icon'  => 'fa fa-language',
            'logo'  => 'group_Kurikulum.png',
            'link' => 'default',
            'keterangan' => '',
            'super_only' => '0',
            'default' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('modul_group')->insert([
            'id_group_mdl' => '4',
            'nama' => 'Akademik',
            'icon'  => 'fa fa-graduation-cap',
            'logo'  => 'group_Akademik.png',
            'link' => 'default',
            'keterangan' => '',
            'super_only' => '0',
            'default' => '0',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('modul_group')->insert([
            'id_group_mdl' => '5',
            'nama' => 'System',
            'icon'  => 'fa fa-cog',
            'logo'  => 'group_System.png',
            'link' => 'default',
            'keterangan' => '',
            'super_only' => '1',
            'default' => '1',
            'aktif' => '1',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
