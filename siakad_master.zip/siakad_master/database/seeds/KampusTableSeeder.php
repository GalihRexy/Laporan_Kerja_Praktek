<?php

use Illuminate\Database\Seeder;

class KampusTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('kampus')->insert([
        	'kode_kampus' => 'FTBDG',
            'nama' => 'Kampus Bandung',
            'alamat' => 'Jl. Terusan Jenderal Gatot Subroto PO. Box 807',
            'kota' => 'Kota Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40284',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('kampus')->insert([
            'kode_kampus' => 'FTCMH',
            'nama' => 'Kampus Cimahi',
            'alamat' => 'Jl. Terusan Cimahi PO. Box 807',
            'kota' => 'Kota Bandung',
            'provinsi' => 'Jawa Barat',
            'kodepos' => '40284',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
