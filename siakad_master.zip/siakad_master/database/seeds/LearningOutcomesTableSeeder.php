<?php

use Illuminate\Database\Seeder;

class LearningOutcomesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Quiz1',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.02',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Quiz2',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.02',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Quiz3',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.03',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Quiz4',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.03',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'UTS',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.15',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'UTS',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.15',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Tugas',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.05',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Tugas',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.05',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Tugas',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.25',
            'created_at' => date("Y-m-d H:i:s"),
        ]);

        DB::table('learning_outcomes')->insert([
            'kode_so' => 'SO01',
        	'kode_mk' => '4',
            'deskripsi_lo' => 'Tugas',
            'materi' => 'materi',
            'metode_pembelajaran' => 'metode_pembelajaran',
            'total_bobot' => '0.25',
            'created_at' => date("Y-m-d H:i:s"),
        ]);
    }
}
