function notifSuccess(notif) {
    switch (notif) {
        case 'login':
            toastSuccess('Anda berhasil login!');
            break;
        case 'create':
            toastSuccess('Data berhasil di simpan!');
            break;
        case 'edit':
            toastSuccess('Data berhasil diubah!');
            break;
        case 'delete':
            toastSuccess('Data berhasil di hapus!');
            break;
        case 'operation':
            toastSuccess('Operasi berhasil di lakukan!');
            break;
        case 'verify':
            toastSuccess('Data berhasil di verifikasi!');
            break;
        default:
            toastSuccess('Data berhasil di simpan!');
            break;
    }
}

function toastSuccess(text) {
    iziToast.success({
        title: 'Berhasil',
        message: text,
        position: 'topRight',
        transitionIn: 'bounceInLeft',
        transitionOut: 'fadeOutRight',
    });
}

function notifFailed(notif) {
    if (notif == 'error') {
        toastFailed('Operasi gagal dilakukan..!');
    } else if (notif == 'database') {
        toastFailed('Pastikan data ini tidak terhubung dengan data lain..!');
    } else if (notif == 'unknown') {
        toastFailed('Masalah tidak diketahui..!');
    }
}

function toastFailed(text) {
    iziToast.error({
        title: 'Gagal',
        message: text,
        position: 'topRight',
        timeout: 10000,
        transitionIn: 'bounceInLeft',
        transitionOut: 'fadeOutRight',
    });
}

function deleteNotif(url) {
    iziToast.warning({
        title: 'Perhatian!',
        message: 'Anda yakin akan menghapus data ini?',
        position: 'center',
        buttons: [
            ['<button>Ya</button>', function (instance, toast) {
                window.location.replace(url);
            }, true],
            ['<button>Tidak</button>', function (instance, toast) {
                instance.hide({
                    transitionOut: 'fadeOutUp'
                }, toast);
            }]
        ],
        timeout: 10000,
        displayMode: 1,
        overlay: true,
        close: false
    });
}