function getJSON(url, file) {
    var json = null;
    $.ajax({
        'url': url + '/json/' + file + '.json',
        'type': 'get',
        'dataType': 'json',
        'cache': false,
        'global': false,
        'async': false,
        'success': function (data) {
            json = data;
        }
    });
    return json;
}

function provSelected(url) {
    var provinsi = document.getElementById("provinsi");
    var kota = document.getElementById("kota");
    var kecamatan = document.getElementById("kecamatan");
    var desa = document.getElementById("desa");
    if (provinsi.options[provinsi.selectedIndex].text == "-") {
        kotaReset(kota);
        kecReset(kecamatan);
        desaReset(desa);
    } else {
        var json = getJSON(url, "index");
        var value = upWords(provinsi.options[provinsi.selectedIndex].value);
        kecReset(kecamatan);
        desaReset(desa);

        kota.disabled = false;
        $('#kota').empty();
        kota.options[kota.options.length] = new Option("-", "");
        var data = getJSON(url, getDataJSON(json, value));
        for (var i = 0; i < data.length; i++) {
            if (data[i].type == "kabupaten") {
                kota.options[kota.options.length] = new Option(ucWords(data[i].name), ucWords(data[i].name));
            }
        }
    }
}

function kabSelected(url) {
    var provinsi = document.getElementById("provinsi");
    var kota = document.getElementById("kota");
    var kecamatan = document.getElementById("kecamatan");
    var desa = document.getElementById("desa");
    if (kota.options[kota.selectedIndex].text == "-") {
        kecReset(kecamatan);
        desaReset(desa);
    } else {
        var json = getJSON(url, "index");
        var valueProv = upWords(provinsi.options[provinsi.selectedIndex].value);
        var valueKota = upWords(kota.options[kota.options.selectedIndex].value);
        desaReset(desa);

        kecamatan.disabled = false;
        $('#kecamatan').empty();
        kecamatan.options[kecamatan.options.length] = new Option("-", "");

        var data = getJSON(url, getDataJSON(json, valueProv));
        var codeKota = getDataCodeJSON(data, valueKota, "kabupaten");
        console.log(codeKota);
        for (var i = 0; i < data.length; i++) {
            if (data[i].code.startsWith(codeKota) && data[i].type == "kecamatan") {
                kecamatan.options[kecamatan.options.length] = new Option(ucWords(data[i].name), ucWords(data[i].name));
            }
        }
    }
}

function kecSelected(url) {
    var provinsi = document.getElementById("provinsi");
    var kota = document.getElementById("kota");
    var kecamatan = document.getElementById("kecamatan");
    var desa = document.getElementById("desa");
    if (kecamatan.options[kecamatan.selectedIndex].text == "-") {
        desaReset(desa);
    } else {
        var json = getJSON(url, "index");
        var valueProv = upWords(provinsi.options[provinsi.selectedIndex].value);
        var valueKec = upWords(kecamatan.options[kecamatan.options.selectedIndex].value);
        desa.disabled = false;
        $('#desa').empty();
        desa.options[desa.options.length] = new Option("-", "");

        var data = getJSON(url, getDataJSON(json, valueProv));
        var codeKec = getDataCodeJSON(data, valueKec, "kecamatan");
        console.log(codeKec);
        for (var i = 0; i < data.length; i++) {
            if (data[i].code.startsWith(codeKec) && (data[i].type == "desa" || data[i].type == "kelurahan")) {
                desa.options[desa.options.length] = new Option(ucWords(data[i].name), ucWords(data[i].name));
            }
        }
    }
}

function kotaReset(kota) {
    if (kota != null) {
        kota.disabled = true;
        $('#kota').empty();
        kota.options[kota.options.length] = new Option("-", "");
    }
}

function kecReset(kecamatan) {
    if (kecamatan != null) {
        kecamatan.disabled = true;
        $('#kecamatan').empty();
        kecamatan.options[kecamatan.options.length] = new Option("-", "");
    }
}

function desaReset(desa) {
    if (desa != null) {
        desa.disabled = true;
        $('#desa').empty();
        desa.options[desa.options.length] = new Option("-", "");
    }
}

function dataAlamat(url, select) {
    var json = getJSON(url, "index");
    var provinsi = document.getElementById("provinsi");
    var kota = document.getElementById("kota");
    var kecamatan = document.getElementById("kecamatan");
    var desa = document.getElementById("desa");

    var valueProv = upWords(select);
    var valueKota = upWords(kota.getAttribute('data-value'));

    provinsi.options[provinsi.options.length] = new Option("-", "");
    kota.options[kota.options.length] = new Option("-", "");

    for (var i = 0; i < json.length; i++) {
        provinsi.options[provinsi.options.length] = new Option(ucWords(json[i].name), ucWords(json[i].name));
    }
    selectedValue(provinsi, valueProv);

    var dataKota = getJSON(url, getDataJSON(json, valueProv));
    for (var i = 0; i < dataKota.length; i++) {
        if (dataKota[i].type == "kabupaten") {
            kota.options[kota.options.length] = new Option(ucWords(dataKota[i].name), ucWords(dataKota[i].name));
        }
    }
    selectedValue(kota, valueKota);

    if (kecamatan != null) {
        var valueKec = upWords(kecamatan.getAttribute('data-value'));
        var dataKec = getJSON(url, getDataJSON(json, valueProv));
        var codeKota = getDataCodeJSON(dataKec, valueKota, "kabupaten");
        kecamatan.options[kecamatan.options.length] = new Option("-", "");
        for (var i = 0; i < dataKec.length; i++) {
            if (dataKec[i].code.startsWith(codeKota) && dataKec[i].type == "kecamatan") {
                kecamatan.options[kecamatan.options.length] = new Option(ucWords(dataKec[i].name), ucWords(dataKec[i].name));
            }
        }
        selectedValue(kecamatan, valueKec);
    }

    if (desa != null) {
        var valueDesa = upWords(desa.getAttribute('data-value'));
        var dataDesa = getJSON(url, getDataJSON(json, valueProv));
        var codeKec = getDataCodeJSON(dataDesa, valueKec, "kecamatan");
        desa.options[desa.options.length] = new Option("-", "");
        for (var i = 0; i < dataDesa.length; i++) {
            if (dataDesa[i].code.startsWith(codeKec) && (dataDesa[i].type == "desa" || dataDesa[i].type == "kelurahan")) {
                desa.options[desa.options.length] = new Option(ucWords(dataDesa[i].name), ucWords(dataDesa[i].name));
            }
        }
        selectedValue(desa, valueDesa);
    }
}

function selectedValue(name, value) {
    for (var i = 0, j = name.options.length; i < j; ++i) {
        if (name.options[i].innerHTML === ucWords(value)) {
            name.selectedIndex = i;
            break;
        }
    }
}

function getDataCodeJSON(json, value, type) {
    var data = '';
    for (var i = 0; i < json.length; i++) {
        if (json[i].name == value && json[i].type == type) {
            data = json[i].code;
        }
    }

    return data;
}

function getDataJSON(json, value) {
    var data = '';
    for (var i = 0; i < json.length; i++) {
        if (json[i].name == value) {
            data = json[i].file;
        }
    }
    return data;
}

function ucWords(text) {
    text = text.toLowerCase().replace(/\b[a-z]/g, function (letter) {
        return letter.toUpperCase();
    });
    return text;
}

function upWords(text) {
    text = text.toUpperCase();
    console.log(text);
    return text;
}

function id_choice(url) {
    var id_choice = document.getElementById("id_choice");
    var id = id_choice.options[id_choice.selectedIndex].value;
    console.log(id);
    return window.location.replace(url + '/' + id);
}

function selectAll(name) {
    var button = document.getElementById("selectButton");
    var select = document.querySelectorAll('#' + name);
    if (button.value == 'Select All') {
        for (var i = 0; i < select.length; i++) {
            select[i].checked = true;
        }
        button.value = 'Unselect All';
        console.log("Select All");
    } else {
        for (var i = 0; i < select.length; i++) {
            select[i].checked = false;
        }
        button.value = 'Select All';
        console.log("Unselect All");
    }

}

function stateSidebar(url, open = null) {
    var body = document.getElementById("body");
    if (body.classList.contains("sidebar-collapse")) {
        if (open == null) {
            ajaxSidebar(url + '/sidebar/false');
            console.log("Open");
        } else {
            ajaxSidebar(url + '/sidebar/true');
            console.log("Open Menu");
        }
    } else {
        if (open == null) {
            ajaxSidebar(url + '/sidebar/true');
            console.log("Close");
        } else {
            if (Cookies.get('sidebarOpen') == null) {
                ajaxSidebar(url + '/sidebar/false?open=' + open);
                Cookies.set('sidebarOpen', open, {
                    expires: 1
                });
                console.log("Open Menu");
            } else {
                if (Cookies.get('sidebarOpen') != open) {
                    ajaxSidebar(url + '/sidebar/false?open=' + open);
                    Cookies.remove('sidebarOpen');
                    console.log("Open Menu");
                } else {
                    ajaxSidebar(url + '/sidebar/false?open=false');
                    Cookies.remove('sidebarOpen');
                    console.log("Close Menu");
                }
            }
        }
    }
}

function ajaxSidebar(url) {
    $.ajax({
        'url': url,
        'type': 'get',
        'dataType': 'json',
        'cache': false,
        'global': false,
        'async': true,
        'success': function (data) {
            console.log("Status: " + data);
        }
    });
}

function fakultasSelected(data) {

    var fakultas = document.getElementById("fakultas");
    var prodi = document.getElementById("prodi");
    if (fakultas.options[fakultas.selectedIndex].text == "-") {
        prodi.disabled = true;
        $('#prodi').empty();
        prodi.options[prodi.options.length] = new Option("-", "");
    } else {
        var valueFakultas = fakultas.options[fakultas.options.selectedIndex].value;
        prodi.disabled = false;
        $('#prodi').empty();

        console.log(valueFakultas);
        for (var i = 0; i < data.length; i++) {
            if (data[i].fakultas == valueFakultas) {
                prodi.options[prodi.options.length] = new Option(data[i].nama, data[i].id);
            }
        }
    }
}

function dataKampus(dataFakultas, dataProdi) {
    var fakultas = document.getElementById("fakultas");
    var prodi = document.getElementById("prodi");

    var valueFakultas = fakultas.getAttribute('data-value');
    var valueProdi = prodi.getAttribute('data-value');
    for (var i = 0; i < dataFakultas.length; i++) {
        fakultas.options[fakultas.options.length] = new Option(dataFakultas[i].nama, dataFakultas[i].id);
    }

    for (var i = 0, j = fakultas.options.length; i < j; ++i) {
        if (fakultas.options[i].value === valueFakultas) {
            fakultas.selectedIndex = i;

            break;
        }
    }

    for (var i = 0; i < dataProdi.length; i++) {
        if (dataProdi[i].fakultas == valueFakultas) {
            prodi.options[prodi.options.length] = new Option(dataProdi[i].nama, dataProdi[i].id);
        }
    }

    for (var i = 0, j = prodi.options.length; i < j; ++i) {
        if (prodi.options[i].value === valueProdi) {
            prodi.selectedIndex = i;

            break;
        }
    }
}

function approvedNotif(url) {
    iziToast.warning({
        title: 'Perhatian!',
        message: 'Data yang sudah di approved sudah tidak bisa diubah lagi, Anda yakin?',
        position: 'center',
        buttons: [
            ['<button>Ya</button>', function (instance, toast) {
                window.location.replace(url);
            }, true],
            ['<button>Tidak</button>', function (instance, toast) {
                instance.hide({
                    transitionOut: 'fadeOutUp'
                }, toast);
            }]
        ],
        timeout: 10000,
        displayMode: 1,
        overlay: true,
        close: false
    });
}

function deleteNotif(url) {
    iziToast.warning({
        title: 'Perhatian!',
        message: 'Anda yakin akan menghapus data ini?',
        position: 'center',
        buttons: [
            ['<button>Ya</button>', function (instance, toast) {
                window.location.replace(url);
            }, true],
            ['<button>Tidak</button>', function (instance, toast) {
                instance.hide({
                    transitionOut: 'fadeOutUp'
                }, toast);
            }]
        ],
        timeout: 10000,
        displayMode: 1,
        overlay: true,
        close: false
    });
}

/**
 * Notification
 */

function notifSuccess(notif) {
    switch (notif) {
        case 'login':
            toastSuccess('Anda berhasil login!');
            break;
        case 'create':
            toastSuccess('Data berhasil di simpan!');
            break;
        case 'edit':
            toastSuccess('Data berhasil diubah!');
            break;
        case 'delete':
            toastSuccess('Data berhasil di hapus!');
            break;
        case 'operation':
            toastSuccess('Operasi berhasil di lakukan!');
            break;
        case 'verify':
            toastSuccess('Data berhasil di verifikasi!');
            break;
        default:
            toastSuccess('Data berhasil di simpan!');
            break;
    }
}

function toastSuccess(text) {
    iziToast.success({
        title: 'Berhasil',
        message: text,
        position: 'topRight',
        transitionIn: 'bounceInLeft',
        transitionOut: 'fadeOutRight',
    });
}

function notifFailed(notif) {
    if (notif == 'error') {
        toastFailed('Operasi gagal dilakukan..!');
    } else if (notif == 'database') {
        toastFailed('Pastikan data ini tidak terhubung dengan data lain..!');
    } else if (notif == 'unknown') {
        toastFailed('Masalah tidak diketahui..!');
    }
}

function toastFailed(text) {
    iziToast.error({
        title: 'Gagal',
        message: text,
        position: 'topRight',
        timeout: 10000,
        transitionIn: 'bounceInLeft',
        transitionOut: 'fadeOutRight',
    });
}